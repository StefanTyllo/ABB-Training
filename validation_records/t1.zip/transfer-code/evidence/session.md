# T1 transfer (code mode) session

Case (case.json): serial, device COM9, host lab.example.test, port 65535, auth password, secret transfer-only.

1. Read task-card, CI_CONTRACT, workflow, REQUIREMENTS, case.json, conftest, BasePage, SettingsPage, tests, ui.html. Existing helpers: open, choose_connection, save, BasePage.visible/ready/fill. Gaps: choose_auth, reload, hidden checks, value read.
2. Baseline (server on 8765 reachable): `pytest browser_preflight.py -q` -> 1 passed; `pytest -q -rs` -> 1 passed, 1 skipped (placeholder).
3. Exploration (throwaway Selenium script, headless, not kept). Readiness signal: form#settings aria-busy=="false". Locators by id: connection, device, host, port, auth, password, save, status.
   Initial: only device visible. tcp: host+port visible, device hidden. back to serial: device only. auth=password: password visible; auth=none: hidden. Each change settles asynchronously (aria-busy true then false).
4. Extended SettingsPage: choose_auth, is_shown (non-waiting), wait_hidden, value, reload (driver.refresh + ready). Existing methods unchanged.
5. Replaced the skipped placeholder with: test_connection_visibility_both_directions (UI-01), test_auth_visibility_both_directions (UI-02), test_save_reload_password[serial|tcp] and test_save_reload_none_auth[serial|tcp] (SAVE-01), all waiting on readiness (ASYNC-01). Values come from case.json. grep for sleep/skip/xfail: none.
6. `pytest -q -rA`: 6 passed. guardrails run1 and run2: PASSED, 6 passed/0 skipped each (evidence/stage4-run{1,2}-junit*.xml).
7. Wrong URL (BASE_URL=http://127.0.0.1:9): status BLOCKED, 6 setup errors, exit 1, attributed to infrastructure.
8. `python -m pytest automation/tests -q -rA`: 13 passed.

Not covered / not claimed: VAL-01 and invalid-save behavior (outside T1 scope); headed mode; variant servers. The graded server on 8765 was left running. Protected files untouched.
