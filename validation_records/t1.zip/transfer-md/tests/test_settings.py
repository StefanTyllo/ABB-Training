import pytest


def fill_connection(page, case, mode):
    page.choose_connection(mode)
    if mode == "serial":
        page.fill("device", case["device"])
    else:
        page.fill("host", case["host"])
        page.fill("port", case["port"])


def assert_connection_restored(page, case, mode):
    assert page.value("connection") == mode
    if mode == "serial":
        assert page.visible("device").is_displayed()
        assert page.value("device") == case["device"]
        assert not page.is_visible("host") and not page.is_visible("port")
    else:
        assert page.visible("host").is_displayed()
        assert page.value("host") == case["host"]
        assert page.value("port") == case["port"]
        assert not page.is_visible("device")


@pytest.mark.requirement("UI-01")
@pytest.mark.requirement("ASYNC-01")
def test_connection_visibility_both_directions(page):
    assert page.is_visible("device")
    assert not page.is_visible("host") and not page.is_visible("port")
    page.choose_connection("tcp")
    assert page.visible("host").is_displayed() and page.visible("port").is_displayed()
    page.wait_hidden("device")
    page.choose_connection("serial")
    assert page.visible("device").is_displayed()
    page.wait_hidden("host")
    page.wait_hidden("port")


@pytest.mark.requirement("UI-02")
@pytest.mark.requirement("ASYNC-01")
def test_auth_visibility_both_directions(page):
    assert not page.is_visible("password")
    page.choose_auth("password")
    assert page.visible("password").is_displayed()
    page.choose_auth("none")
    page.wait_hidden("password")
    assert not page.is_visible("password")


@pytest.mark.requirement("SAVE-01")
@pytest.mark.requirement("ASYNC-01")
@pytest.mark.parametrize("mode", ["serial", "tcp"])
def test_save_reload_password(page, case, mode):
    fill_connection(page, case, mode)
    page.choose_auth(case["auth"])
    page.fill("password", case["password"])
    assert page.save() == "Saved"

    page.reload()
    assert_connection_restored(page, case, mode)
    assert page.value("auth") == case["auth"]
    assert page.visible("password").is_displayed()
    assert page.value("password") == case["password"]


@pytest.mark.requirement("SAVE-01")
@pytest.mark.parametrize("mode", ["serial", "tcp"])
def test_save_reload_auth_none(page, case, mode):
    fill_connection(page, case, mode)
    page.choose_auth("none")
    assert page.save() == "Saved"

    page.reload()
    assert_connection_restored(page, case, mode)
    assert page.value("auth") == "none"
    page.wait_hidden("password")
