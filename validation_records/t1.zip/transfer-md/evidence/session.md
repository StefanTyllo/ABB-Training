# T1 transfer (Markdown-only) session

## Inputs
- WORKSPACE: runs/t1/transfer-md; BASE_URL default http://127.0.0.1:8765 (root-owned server, not touched).
- Oracle: REQUIREMENTS.md; case.json (serial, device COM9, host lab.example.test, port 65535, auth password, password transfer-only).
- Editable: pages/settings_page.py, tests/test_settings.py, evidence/. Protected files unchanged.

## Step 1: existing helpers
BasePage: visible, ready (aria-busy=false), fill. SettingsPage: open, choose_connection, save (returns status text).
Gaps: auth selection, reload, non-waiting visibility, wait-hidden, value read.

## Step 2: baseline
- `python -m pytest browser_preflight.py -q` -> 1 passed.
- `python -m pytest -q -rs` -> 1 passed, 1 skipped (placeholder skip).

## Steps 3-4: exploration (from ui.html and the preflight; no separate exploratory script was run)
- Locators are element ids: connection, device, host, port, auth, password, save, status; readiness is `#settings[aria-busy]`.
- Serial shows device / hides host+port; TCP the reverse; Password shows `#password`. Changes settle asynchronously.
- Limitation: I did not run a separate interactive Selenium exploration; the toggles were exercised by the tests below.

## Step 5: POM additions
choose_auth, reload (driver.refresh + ready + form visible), is_visible (non-waiting), wait_hidden, value (and a `selected` alias).

## Steps 6-8: tests and runs
tests/test_settings.py: connection_visibility, auth_visibility, save_reload_password[serial|tcp], save_reload_auth_none[serial|tcp]. Placeholder removed.
Run 1: 6 passed in ~18 s. Run 2: 6 passed in ~18 s. No skips. Grep for sleep/skip/xfail in POM/tests found nothing.

## Step 9: negative check
`BASE_URL=http://127.0.0.1:59999 pytest -x` -> ERROR (URLError, Connection refused) in the fixture: infrastructure failure => BLOCKED, not a pass.

## Untested / not claimed
Invalid-input rules (VAL-01) and invalid-save non-overwrite, alternate variants, headed mode, and missing-element screenshot capture were not exercised (out of T1 scope here).
