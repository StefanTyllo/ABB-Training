# Stage 1 session log (T1 demo, scripted CI rehearsal)

Each step: rationale → command → observation. Server at http://127.0.0.1:8765 was already running and was left untouched.

1. **Read contract/inputs.** Rationale: requirements are the oracle. Read task-card.md, CI_CONTRACT.md, REQUIREMENTS.md, case.json, conftest.py, pages/*.py, tests, ui.html.
   Existing helpers: `BasePage.visible/ready/fill`; `SettingsPage.open/choose_connection/save`. Missing: auth selection, reload, non-waiting visibility checks, value reads.
   case.json: tcp, lab.example.test, 1502, password, practice-only, device COM7.
2. **Baseline.** `python -m pytest browser_preflight.py -q` → 1 passed (Chrome 154 headless). `python -m pytest -q -rs` → 1 passed, 1 skipped (placeholder). Browser creation works, so proceed.
3. **Explore.** Ad-hoc Selenium script (/tmp, not kept). Observed: Serial default shows device, hides host/port/password; `aria-busy` is "true" immediately after a change and returns to "false" (readiness signal `#settings[aria-busy]`). Locators are plain IDs: connection, device, host, port, auth, password, save, status.
4. **Switch both ways.** Serial→TCP: host/port shown, device hidden. TCP→Serial: reversed. None→Password: password shown. Password→None: hidden. All after `ready()`.
5. **Extend POM** (rationale: only demonstrated interactions): added `choose_auth`, `reload`, `is_shown`, `wait_hidden`, `value`. Assertions stay in tests.
6. **Tests.** Replaced placeholder with: connection_visibility, auth_visibility, save_reload (parametrized tcp/serial, using case.json values, UI save then `driver.refresh`, exact restored values), and save_reload_none_auth. No sleeps, no skips, no HTTP.
7. **Run.** `python -m pytest -q -rs` three times → 5 passed each (~16 s), stable.
8. **Failure check.** `BASE_URL=http://127.0.0.1:9 python -m pytest -q -x` → ConnectionRefusedError in fixture reset: an infrastructure/blocked result, not a pass. `grep sleep|skip pages tests` → none.

Result: UI-01, UI-02, SAVE-01, ASYNC-01 covered by real assertions; all executed, none skipped.
Not done (later stages): automation helpers, variant runs. No screenshots were captured since no UI failure occurred.
