# Workflow: explore a dynamic web form, extend its Page Object, and test save/reload

Reusable for any form whose dependent fields and save completion settle asynchronously.

## Named inputs (validate before starting)
| Input | Meaning | Default | If missing/invalid |
|---|---|---|---|
| WORKSPACE | Directory containing app adapter, Page Objects, tests | cwd | Stop; report BLOCKED |
| BASE_URL | Running app URL | task default | Unreachable → BLOCKED (never a pass) |
| REQUIREMENTS_PATH | Independent requirements (the oracle) | `REQUIREMENTS.md` | Stop; do not invent expectations |
| CASE_PATH | Case data: mode, host, port, secret mode, secret, device | `case.json` | Stop; tests must not hardcode values |
| PROTECTED_PATHS | App source, BasePage, conftest, case data, requirements, pytest config | per task card | Treat all non-listed files as protected |
| EDITABLE_PATHS | Page Object, test module, workflow/evidence files | per task card | Stop if unclear; do not edit elsewhere |
| TARGET_MODES / AUTH_MODES | Connection modes and auth modes to cover (both directions) | from case data + requirements | Derive from requirements only |
| EVIDENCE_DIR | Destination for logs, screenshots, session notes | `evidence/` | Create it |
| BROWSER_BINARY / DRIVER | Chrome/driver overrides | auto-discovery | Needed only if discovery fails |

Case values are inputs. Never embed them in the Page Object, and never derive expected values from app source or observed output.

## Invariants
- Requirements and case data are the oracle; the app source is not.
- Protected files stay unchanged; preserve existing Page Object methods and supplied adapters.
- Waits use observable state (readiness attribute, visibility/invisibility, status text). No fixed sleeps.
- Drive the real browser through the UI; no HTTP substitutes, fake DOM, skips, or xfails.
- Assertions live in tests; the Page Object holds locators, interactions, readiness waits.
- Assert only values of the active connection mode; hidden fields need not be cleared.
- Do not stop servers you do not own. Use separate ports for variants.
- Infrastructure failure (no browser, unreachable app) is BLOCKED, distinct from an assertion failure. Report both as-is.
- A skipped required test is incomplete work, not coverage. A requirement marker is traceability, not proof.

## Steps
1. **Read** requirements, case data, BasePage, Page Object, existing tests. List existing helpers and gaps.
2. **Baseline**: run browser preflight, then the full suite with `-rs`. Record counts.
   - Browser creation fails → stop, record BLOCKED.
   - Unexpected baseline result → record it and investigate before editing.
3. **Explore** with a throwaway Selenium script (not kept). Record locators, which fields are visible in each state, and the readiness signal. Use headed mode only if a display exists.
4. **Toggle each dependent control in both directions** (each connection mode and back; each auth mode and back). After each change wait for readiness, then record visibility.
5. **Extend the Page Object** only for demonstrated interactions: select connection, select auth, reload (real refresh, then wait for form), non-waiting visibility check, wait-for-hidden, read field value. Keep existing methods usable.
6. **Write tests** from requirements and CASE_PATH:
   - visibility of connection fields, both directions;
   - visibility of the secret field per auth mode, both directions;
   - save/reload parameterized over every connection mode: fill via UI, save, assert the success status, reload the browser, assert exact active values, connection mode, auth mode and secret;
   - a persistence case for the no-secret auth mode.
7. **Remove placeholders** only after step 6 coverage exists.
8. **Run** the suite at least twice for async stability; scan for sleeps/skips/xfails.
9. **Negative check**: point BASE_URL at an unused address; confirm the result is a connection error reported as BLOCKED, not a pass.
10. **Record** commands, observations, rationale, counts in EVIDENCE_DIR/session.md. Report only executed results.

## Failure handling
- Element missing/timeout: capture screenshot and DOM visibility, check the readiness signal, fix the wait (never add a sleep).
- Flaky result: rerun and fix the wait on observable state.
- Server unreachable: BLOCKED; no HTTP masking, no skips.
- Expected engineering failures must remain visible in the report.

## Untested branches (not exercised so far; verify before relying on them)
- Invalid-input rules (port boundaries, empty host/device/secret) and "invalid save must not overwrite last valid state".
- Screenshot/log capture on UI failure (no failure occurred).
- Headed mode, non-default BASE_URL with a live app, and alternate app variants (e.g. non-persisting or boundary-faulty).
- Missing-element failure evidence and browser-startup-vs-assertion separation beyond the unreachable-URL check.
- Using a different case (other mode, device, or secret) than the one explored.

## Completion criteria
Every requirement ID in scope has real assertions that ran; both directions of each switch pass; saved values survive reload; zero skips/xfails; no fixed sleeps; protected files unchanged; workflow documented before any automation helper; untested branches stated, not claimed.
