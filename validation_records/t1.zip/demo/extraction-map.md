# Extraction map: dynamic form exploration, Page Object extension, save/reload test

Source: `workflow.md` steps 1–10, task-card Stage 3 boundary, CI_CONTRACT.md. Stage 3 is design only: no reusable automation has been implemented. Existing Stage 1 code (`pages/settings_page.py`, `tests/test_settings.py`) is unchanged.

Dispositions: **DET** = deterministic code; **MODEL** = model judgment; **HUMAN** = human decision.
Priority order follows the task: collection, parsing, calculation, comparison, validation, reporting.

## Workflow step review

| # | Step | Purpose | Inputs | Operation | Expected output | Failure condition | Disposition |
|---|---|---|---|---|---|---|---|
| 1 | Read inputs | Establish the oracle and existing helpers | REQUIREMENTS_PATH, CASE_PATH, BasePage, Page Object, tests | **Collection**: read files. **Parsing**: load case JSON, verify required keys. Then list helpers and gaps | Parsed case dict; list of existing methods | Missing/unparseable file or missing key → BLOCKED, no invented expectations | Collect/parse: **DET** (`load_case`, `list_page_methods`). Judging gaps vs requirements: **MODEL** |
| 2a | Environment readiness | Know if the app and browser are usable before testing | BASE_URL, CHROME_BINARY, CHROMEDRIVER | **Collection**: probe URL reachability; start Chrome headless and record the browser identity and the page title | Readiness record: url, reachable, browser name/version, title | Unreachable URL or browser start error → BLOCKED (infrastructure), never FAIL or pass | **DET** (`check_app_ready`, `start_browser`) |
| 2b | Baseline run | Record the starting state | WORKSPACE, pytest command | **Collection**: run preflight then the full suite with `-rs`, save JUnit + log. **Parsing**: counts | Counts: collected/passed/failed/skipped/errors | Nonzero/unexpected counts are recorded, not hidden | Run and parse: **DET** (`run_pytest`, `parse_junit`). Deciding whether the baseline is acceptable: **MODEL** |
| 3 | Explore | Discover locators, visible fields per state, readiness signal | Live UI | Throwaway Selenium inspection | Locator table, visibility matrix, readiness signal | Unfamiliar behavior not understood | **MODEL** for discovery and interpretation. Dumping visibility state once chosen: **DET** (`snapshot_visibility`) |
| 4 | Toggle controls both ways | Show dependent fields change asynchronously in both directions | Connection and auth values from requirements | Select value, wait for readiness, record visibility | Visibility record per state | Wait times out; wrong field visible | Repeatable action: **DET** (POM `choose_connection`, `choose_auth`). Deciding what the matrix must show: **MODEL** |
| 5 | Extend Page Object | Hold locators, actions, readiness waits | Demonstrated interactions | Add `choose_auth`, `reload`, `is_shown`, `wait_hidden`, `value`; no assertions in the POM | POM methods that keep the old ones usable | Existing method broken; assertion placed in POM; fixed sleep | Code: **DET**. Choosing which interactions belong: **MODEL** |
| 6 | Write tests | Turn requirements into assertions | Requirements, case values, POM | Visibility both directions; save/reload over every mode; none-auth persistence | Executed pytest cases with real assertions | Values hardcoded; expectation copied from observed output or `server.py`; marker without assertion | Deciding what must be asserted and covering UI-01/02, SAVE-01, ASYNC-01: **MODEL**, with **HUMAN** sign-off on requirement interpretation. Case-driven loops: **DET** |
| 7 | Remove placeholder | Avoid unfinished work counted as coverage | Test file, skip markers | Delete the skip only after step 6 coverage exists | Zero skips | Skip or xfail remains | Scan: **DET** (`scan_forbidden`). Timing of removal: **MODEL** |
| 8 | Stability runs | Detect async flakiness | pytest, repeat count ≥2 | Repeat the suite; compare counts across runs. **Calculation**: tallies | Identical pass counts per run | Different outcomes across runs | Run, compare: **DET** (`run_pytest`, `compare_runs`). Root-causing a flake: **MODEL** |
| 9 | Negative check | Prove infrastructure failure is not a pass | Unused BASE_URL | Run with unreachable URL; classify the error | Result BLOCKED with connection error | Reported as pass or assertion failure | **DET** (`classify_outcome`) |
| 10 | Failure evidence | Make failures diagnosable | Active driver, failing test | Capture screenshot, URL, DOM visibility, `aria-busy` value | Files in EVIDENCE_DIR | Evidence missing or driver already closed | **DET** (`capture_failure_evidence`); reading it: **MODEL** |
| 11 | Report | State only executed results | JUnit, logs, scan results, classification | **Reporting**: write session notes/summary JSON; list untested branches | `evidence/session.md` + machine-readable summary | Claiming unexecuted results; skip counted as coverage; hiding expected failures | Rendering: **DET** (`write_summary`). Coverage review and "not tested" statements: **MODEL**. Final acceptance: **HUMAN** |
| 12 | Protected-file check | Show immutable files are untouched | PROTECTED_PATHS | **Comparison**: hash before/after | Empty diff list | Any protected file changed | **DET** (`verify_protected`) |

## Proposed functions (contracts)

All take explicit arguments (no module-level case values); none embed case data. Python, module `automation/` (to be created in stage 4, not now).

| Function | Input | Output | Failure behavior |
|---|---|---|---|
| `load_case(path)` | `path`: str/Path to JSON | `dict` with keys `connection, host, port, auth, password, device` (strings) | Raises `CaseError` naming missing key/file; caller reports BLOCKED |
| `check_app_ready(base_url, timeout_s=10)` | URL str, finite timeout | `{"ready": bool, "url": str, "detail": str}`; polls, no fixed sleeps beyond bounded retry interval | Never raises on connection errors; `ready=False` with detail |
| `start_browser(headed=False, binary=None, driver_path=None)` | Env/arguments (HEADED, CHROME_BINARY, CHROMEDRIVER) | `(driver, {"browser": name, "version": str})` | Raises `BrowserStartupError` (distinct class from assertion errors) |
| `run_pytest(workspace, junit_path, base_url=None, timeout_s=600, extra_args=())` | Resolved workspace, JUnit destination, optional BASE_URL | `RunResult(returncode, stdout_path, junit_path, timed_out)`; uses an argument list, cwd=workspace, creates JUnit parent, inherits BASE_URL | Timeout → `timed_out=True`; JUnit never fabricated |
| `parse_junit(path)` | JUnit XML path | `{"collected","passed","failed","skipped","errors", "cases":[{name,outcome,message}]}` | Missing/invalid file → raises `ReportError`; counts are not guessed |
| `classify_outcome(run_result, counts, log_text)` | Above outputs | One of `PASSED`, `FAILED` (assertion), `BLOCKED` (unreachable app, browser/driver startup, timeout), `INCOMPLETE` (skips, zero collected or required names missing) + reason | Ambiguous → `BLOCKED` with reason, never `PASSED` |
| `scan_forbidden(paths, patterns=("sleep(", "skip", "xfail"))` | Test/POM file paths | List of `{file, line, text}` hits | Empty list = clean; unreadable file raises |
| `required_names_present(counts, required=("connection_visibility","auth_visibility","save_reload"))` | `parse_junit` result, name fragments | `{fragment: executed_count}` | Any zero → `INCOMPLETE` |
| `compare_runs(counts_list)` | List of `parse_junit` results | `{"stable": bool, "differences": [...]}` | Differences listed |
| `capture_failure_evidence(driver, out_dir, label)` | Live driver, directory, label | Paths: `.png`, `.txt` (URL, title, aria-busy, visibility of each field id) | Capture errors are recorded in the text, never mask the original failure |
| `snapshot_visibility(driver, ids)` | Driver, locator ids | `{id: bool or None}` (None if absent); non-waiting | None for missing elements |
| `verify_protected(workspace, paths, baseline_hashes)` | Paths, SHA-256 map | List of changed paths | Nonempty list = failure |
| `write_summary(out_dir, outcome, counts, browser, url, artifacts)` | Results | `session.md` section and JSON with real values only | Cannot be called without counts → raises |

POM methods already present and to be kept (adapter-specific locators are legitimate): `open`, `choose_connection`, `choose_auth`, `save`, `reload`, `is_shown`, `wait_hidden`, `value`. Contracts: each interaction waits on `#settings[aria-busy="false"]`, or on visibility or invisibility of a specific id, within the 5 s BasePage timeout; they return the status text (`save`) or nothing; they contain no assertions.

## Boundary decisions

- **Stays model judgment:** discovering unfamiliar interactions, deciding what each assertion must establish, interpreting unexpected UI behavior, reviewing whether coverage matches UI-01, UI-02, VAL-01, SAVE-01, ASYNC-01.
- **Stays human decision:** accepting requirement interpretation (for example whether password-required validation should be tested for the demo), and sign-off on whether evidence suffices.
- **Not extracted:** expected values (they come from REQUIREMENTS.md and case.json) and test assertions.

## Known gaps / risks (stated, not claimed)

- VAL-01 validation rules and "invalid save keeps the last valid state" have no coverage in the current T1 suite. They are not in the T1 demo-complete list, but any extraction must not imply they are covered.
- Failure-evidence capture and browser-startup-versus-assertion separation are designed here, not yet exercised.
- Behavior with another case (different mode, device or secret), headed mode, and non-default BASE_URL with a live app is untested.
- Python-level `classify_outcome` pattern matching on the log is heuristic; ambiguous cases fall to BLOCKED.
