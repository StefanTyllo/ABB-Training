
# T1 Explore a dynamic form and extend Page Objects

**Task card.** Explore the running configuration form, explain its dynamic states, and extend the existing Selenium Page Object Model and tests. Cover visibility transitions and saving/reloading actual values.

**Prepare from the training root**
```bash
python materials/prepare_lab.py t1 demo work/t1-demo
cd work/t1-demo
python server.py --variant correct --port 8765 --state state.json
```
Keep this terminal running. Open terminal B at the training root, activate `.venv`, then:
```bash
cd work/t1-demo
python -m pytest browser_preflight.py -q
python -m pytest -q
```
**Initial expected result:** the preflight passes in a working browser environment; the starter suite has one passing smoke test and one skipped placeholder. That skip is unfinished work, not acceptance. Stop if browser creation fails.

**Allowed changes:** `pages/settings_page.py`, `tests/test_settings.py`, and common workflow/automation/evidence files. Preserve the server, BasePage, conftest.py, case.json, and REQUIREMENTS.md. The app has no login; no login helper is required. The fixture resets state before each test.

## Stage 1 Guided operations
1. Read REQUIREMENTS.md, case.json, BasePage, SettingsPage, and existing tests. Explain which helpers already exist.
2. Explore the actual page in the browser, using Selenium operations through the terminal. Record visible fields, locators, and readiness signals. Use `HEADED=1` when a desktop display is available; headless execution is acceptable evidence.
3. Switch Serial to TCP and back. Switch authentication None to Password and back. Observe asynchronous visibility changes.
4. Extend SettingsPage only as needed to represent the demonstrated interactions. Keep behavioral expectations in tests.
5. Save values from case.json, wait for completion, reload the browser, and assert exact restored active values. Do not replace the UI interaction with HTTP calls.
6. Run the tests and inspect actual failure evidence. Remove the skipped placeholder only after substantive coverage exists.

**Demonstration complete:** UI-01, UI-02, SAVE-01, and ASYNC-01 have real assertions; both switch directions work; saved values survive reload; no skips or fixed sleeps. Document the workflow before adding orchestration helpers.


# T1 Extract browser setup and evidence collection

## Stage 2 Abstraction focus
Parameterize base URL, case-data path, connection mode, values, and artifact destination. Preserve framework conventions and the requirement to wait on observable state. A locator tied to this application is a legitimate adapter detail; a demo-only field value is an input.

## Stage 3 Deterministic boundary
| Move into code | Retain as reasoning |
| --- | --- |
| Capture browser/application setup and check readiness | Discover unfamiliar interactions and identify meaningful behavior |
| Repeat demonstrated Page Object actions and condition-based waits | Decide what an assertion must establish |
| Collect screenshots/logs when operations fail | Interpret unexpected UI behavior |
| Run collected tests and summarize real results | Review whether the suite covers the requirement |

## Stage 4 Required implementation behavior
Create reusable execution/evidence helpers under automation/. Extend the existing Page Objects where an interaction belongs there; do not create a competing framework. Record actual collected tests, pass/fail/skip counts, browser identity, URL, and relevant failure artifacts.

The helper must treat a browser startup error separately from a failing UI assertion. A requirement marker is traceability, not proof of coverage. Keep assertions in tests; readiness checks may remain in Page Objects. [S1, S2]

**Required checks:** known-good interaction; wrong URL reports blocked; missing expected element produces useful failure evidence; no fixed sleep; a skipped required test cannot be presented as complete coverage.

**Transfer preparation, from the training root**
```bash
python materials/prepare_lab.py t1 transfer work/t1-transfer-md
python materials/prepare_lab.py t1 transfer work/t1-transfer-code
```
Stop the demo server with Ctrl-C. Start the correct variant in the chosen transfer workspace using the T1 server command. Run one workspace at a time on port 8765. Transfer uses a different device value and Serial/Password as its saved target; it must also test the reverse visibility transitions.

For MD-only, begin from the clean supplied Page Objects/tests plus the extracted Markdown. For code-assisted replay, copy only general reusable Page Object methods and automation helpers; do not copy completed demo test cases. Both runs must produce assertions for the new case.

**Acceptance:** real-browser execution, no required skips, exact saved/restored current case values, both switch directions, and reuse of the provided framework. Review screenshots/logs together with test assertions.

**Debrief:** what did the model still need to discover, and which repetitive browser mechanics became ordinary code?
