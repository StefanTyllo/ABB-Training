import pytest


@pytest.mark.requirement("UI-01")
def test_connection_visibility_both_directions(page):
    assert page.is_shown("device")
    assert not page.is_shown("host") and not page.is_shown("port")
    page.choose_connection("tcp")
    assert page.visible("host").is_displayed() and page.visible("port").is_displayed()
    page.wait_hidden("device")
    page.choose_connection("serial")
    assert page.visible("device").is_displayed()
    page.wait_hidden("host")
    page.wait_hidden("port")


@pytest.mark.requirement("UI-02")
def test_auth_visibility_both_directions(page):
    page.wait_hidden("password")
    page.choose_auth("password")
    assert page.visible("password").is_displayed()
    page.choose_auth("none")
    page.wait_hidden("password")


@pytest.mark.requirement("SAVE-01")
@pytest.mark.requirement("ASYNC-01")
@pytest.mark.parametrize("mode", ["tcp", "serial"])
def test_save_reload_restores_values(page, case, mode):
    page.choose_connection(mode)
    if mode == "tcp":
        page.fill("host", case["host"])
        page.fill("port", case["port"])
    else:
        page.fill("device", case["device"])
    page.choose_auth(case["auth"])
    page.fill("password", case["password"])
    assert page.save() == "Saved"

    page.reload()
    assert page.value("connection") == mode
    assert page.value("auth") == case["auth"]
    assert page.value("password") == case["password"]
    if mode == "tcp":
        assert page.value("host") == case["host"]
        assert page.value("port") == case["port"]
        page.wait_hidden("device")
    else:
        assert page.value("device") == case["device"]
        page.wait_hidden("host")
        page.wait_hidden("port")


@pytest.mark.requirement("SAVE-01")
def test_save_reload_none_auth(page, case):
    page.choose_connection("tcp")
    page.fill("host", case["host"])
    page.fill("port", case["port"])
    assert page.save() == "Saved"
    page.reload()
    assert page.value("auth") == "none"
    page.wait_hidden("password")
    assert page.value("host") == case["host"]
