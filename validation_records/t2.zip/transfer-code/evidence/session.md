# T2 transfer-code session

## Inputs
Workspace, REQUIREMENTS.md, case.json (tcp, lab.example.test, 65535, password, COM9), SERVER_CMD (`server.py --variant V --port P --state S`) all present. Root server on 8765 was not touched (HTTP 200 observed before work). Variant labels were used only to start owned servers; fault-switch code was not read.

## Baseline judgment (reasoning)
`test_weak_save_smoke` only asserts the status text "Saved" after one TCP save. It does not prove persistence (no reload), rejection of 0/65536/non-integer, acceptance of 1/65535, or that an invalid save preserves the baseline (SAVE-01, VAL-01).

## Requirement mapping
- SAVE-01: save, `page.reload()` (driver.refresh + wait for form and `aria-busy=false`), assert selected connection first, then host/port/auth/password.
- VAL-01: boundary ports 1, 65535 expect status "Saved"; 0, 65536, "abc" expect status != "Saved".
- ASYNC-01: every action waits on `aria-busy=false` / visibility; no sleeps.

## Commands and observations
1. `python -m pytest browser_preflight.py -q` -> 1 passed (exit 0).
2. `python -m pytest -q` (weak baseline, correct app 8765) -> 1 passed.
3. `python -m pytest automation/tests -q` -> 16 passed.
4. Weak baseline on own no-persist (free port, fresh state) -> 1 passed (exit 0); bad-boundary -> 1 passed (exit 0). Gap: neither defect is detected because the weak test never reloads and never uses the boundary values.
5. Failed tool attempt: an inline `kill $pid` shell loop was refused by the harness; used a Python helper using automation lib start/stop of owned children instead.
6. Strengthened `tests/test_settings.py` (12 cases) and added POM methods `choose_auth`, `reload`, `value`, `selected`, `is_shown`, `save_tcp` in `pages/settings_page.py`. Correct app (8765): `python -m pytest -q` -> 12 passed.
7. `python automation/evaluate_variants.py --workspace .` -> status passed, exit 0. Per-variant (JUnit/logs in `evidence/variants/<variant>/`):
   - correct: rc 0, 12 passed, 0 skipped/errors.
   - no-persist: rc 1, 4 passed, 8 failed.
   - bad-boundary: rc 1, 9 passed, 3 failed.

## Detection review
- no-persist: `test_save_reload_tcp_values_survive[*]`, `test_save_reload_case_with_password`: SAVE-01, after reload, expected connection 'tcp', observed 'serial' (assertion, not timeout). The invalid_save tests also fail on the missing baseline after reload.
- bad-boundary: `test_port_boundary_valid_accepted_and_restored[65535]`: VAL-01, before reload, expected status 'Saved', observed 'Port must be 1..65535'. Other 65535-related failures (e.g. save_reload with 65535) are the same defect.
- Human judgment still needed: that these are true requirement violations (both follow directly from SAVE-01 and VAL-01) and that the detecting assertions are appropriate.

## Deviations / not run
- Exploration servers used own ports (state in evidence/explore/); root 8765 server left running.
- Not run: external grader, T1 tests, headed browser, parallel runs, non-loopback servers.
- The exact invalid-save error text is not specified by requirements; tests assert only status != "Saved".
- `automation/guardrails.py` and `evaluate_variants.py` were supplied and used unmodified.

## Final status: passed
