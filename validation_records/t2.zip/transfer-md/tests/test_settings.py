import pytest

BASELINE = dict(host="baseline.example.test", port="1502", auth="password", password="baseline-pw")


@pytest.mark.requirement("SAVE-01")
def test_weak_save_smoke(page):
    page.choose_connection("tcp")
    page.fill("host", "lab.example.test")
    page.fill("port", "1502")
    assert page.save() == "Saved"


@pytest.mark.requirement("SAVE-01")
@pytest.mark.parametrize("config", [
    dict(host="lab.example.test", port="65535", auth="password", password="transfer-only"),
    dict(host="second.example.test", port="8080", auth="none", password=""),
], ids=["password-65535", "none-8080"])
def test_tcp_save_reload(page, config):
    page.configure_tcp(**config)
    assert page.save() == "Saved"
    page.reload()
    assert page.selected("connection") == "tcp"
    assert page.selected("auth") == config["auth"]
    assert page.value("host") == config["host"]
    assert page.value("port") == config["port"]
    if config["auth"] == "password":
        assert page.value("password") == config["password"]


@pytest.mark.requirement("VAL-01")
@pytest.mark.requirement("SAVE-01")
@pytest.mark.parametrize("port", ["1", "65535"])
def test_port_boundary_valid_accepted(page, port):
    page.configure_tcp("boundary.example.test", port)
    assert page.save() == "Saved"
    page.reload()
    assert page.selected("connection") == "tcp"
    assert page.value("port") == port


@pytest.mark.requirement("VAL-01")
@pytest.mark.parametrize("port", ["0", "65536", "abc"])
def test_port_boundary_invalid_rejected(page, port):
    page.configure_tcp("boundary.example.test", port)
    assert page.save() != "Saved"


@pytest.mark.requirement("SAVE-01")
@pytest.mark.requirement("VAL-01")
@pytest.mark.parametrize("bad_port", ["0", "65536", "abc"])
def test_invalid_save_preserves_baseline(page, bad_port):
    page.configure_tcp(**BASELINE)
    assert page.save() == "Saved"
    page.fill("port", bad_port)
    assert page.save() != "Saved"
    page.reload()
    assert page.selected("connection") == "tcp"
    assert page.selected("auth") == BASELINE["auth"]
    assert page.value("host") == BASELINE["host"]
    assert page.value("port") == BASELINE["port"]
    assert page.value("password") == BASELINE["password"]
