# T2 transfer-md session evidence

## Inputs
WORKSPACE, REQUIREMENTS.md, case.json (tcp, lab.example.test, 65535, password/transfer-only), evidence dir: valid. Server command from task card (`server.py --variant --port --state`). Required cases from task card/requirements. No assumptions needed. Read task-card.md, CI_CONTRACT.md, workflow.md; did not read server fault-switch code.

## Baseline judgment (reasoning)
`test_weak_save_smoke` only asserts status == "Saved" after a valid TCP save of 1502. A pass does not prove persistence after reload, rejection of invalid ports, boundaries 1/65535, or preserved baseline on invalid save.

## Requirement mapping
- SAVE-01: save, `driver.refresh()`, wait aria-busy=false (`ready`), then assert selected connection/auth first (precondition) then host/port/password. Invalid save: status != "Saved", then reload shows baseline.
- VAL-01: ports 1, 65535 -> "Saved" and persist; 0, 65536, "abc" -> status != "Saved". (Requirements do not give the rejection message text, so only "not Saved" is asserted.)
- ASYNC-01: all waits via BasePage.ready()/visibility waits; no sleeps.

## Commands and results
1. Server on 8765 (root-owned) answered 200 via urllib (curl was refused by harness; used python urllib). Not stopped.
2. `python -m pytest browser_preflight.py -q` -> 1 passed. Baseline `python -m pytest -q` on 8765 -> 1 passed.
3. Own server helper (/tmp/t2md/run_variant.py, outside workspace, free port, fresh state in /tmp/t2md, terminated in finally): weak baseline vs no-persist -> 1 passed (exit 0) = coverage gap (log: pytest-baseline-nopersist.log).
4. Added POM methods `choose_auth`, `reload`, `value`, `selected`, `configure_tcp`; rewrote tests (11 cases: save_reload x2, port_boundary valid x2 / invalid x3, invalid_save x3, plus original smoke).
5. Strengthened suite, each variant on own port/state/log (evidence/pytest-final-*.log, junit-final-*.xml, server-final-*.log):
| Variant | Exit | Result |
|---|---|---|
| correct | 0 | 11 passed, 0 skipped |
| no-persist | 1 | 7 failed, 4 passed |
| bad-boundary | 1 | 2 failed, 9 passed |

## Detection review
- no-persist: `assert 'serial' == 'tcp'` after reload in test_tcp_save_reload (both), port_boundary_valid_accepted (both), invalid_save_preserves_baseline (x3). SAVE-01: expected connection tcp restored, actual serial (after reload). Assertion failures, not timeouts. Rejection tests pass (not dependent on persistence).
- bad-boundary: `assert 'Port must be 1..65535' == 'Saved'` for port 65535 in test_tcp_save_reload[password-65535] and test_port_boundary_valid_accepted[65535]. VAL-01: expected Saved, actual rejection (before reload). Port 1, 0, 65536, abc behaved per requirements.
Human judgment still needed: confirming these are true requirement violations and that "not Saved" is the right rejection check.

## Cleanup / deviations / not run
- Owned servers terminated in finally; 8765 server still answered 200 and untouched.
- Deviation: variant helper lives in /tmp (not a workspace deliverable); MD-only mode needs no automation.
- Not run: grader, Serial-mode persistence, parallel runs, T1.
Final status: passed (correct passes; both defects detected by relevant assertions).
