
# T2 Test whether the suite detects defects

Stop the previous T1 or transfer server with Ctrl-C before starting this lab.

**Task card.** Improve a passing but weak suite so that it detects a persistence defect and validates the specified port boundaries. Demonstrate both correct-app success and relevant defective-app failure.

**Prepare from the training root**
```bash
python materials/prepare_lab.py t2 demo work/t2-demo
cd work/t2-demo
python server.py --variant correct --port 8765 --state state.json
```
Use terminal B in the same workspace with the training venv active. Run the browser preflight, then `python -m pytest -q`. The initial single smoke test is intentionally weak.

**Allowed changes:** the same Page Object and test files as T1, plus common artifacts. Preserve the application and independent requirements. Use requirements to determine expected behavior; inspecting the server's fault-switch implementation is not part of the diagnosis.

## Stage 1 Guided operations
1. Read the existing assertion and explain what a pass does and does not establish.
2. Read SAVE-01, VAL-01, and ASYNC-01 in REQUIREMENTS.md. Map each to observable browser behavior.
3. Show a valid save and browser reload on the correct app.
4. Stop terminal A with Ctrl-C. With the server stopped, reset the local state and launch the demonstration defect:
```bash
python -c "from pathlib import Path; Path('state.json').unlink(missing_ok=True)"
python server.py --variant no-persist --port 8765 --state state.json
```
5. Run the unchanged weak test. Explain why it passes despite the defect.
6. Add assertions for persistence and boundary handling. Use the existing framework and explicit waits.
7. Confirm the strengthened suite detects the demonstrated defect. Restart the correct variant with clean state and confirm the suite passes there.

**Required cases:** valid TCP ports 1 and 65535; invalid 0, 65536, and non-integer text; invalid save preserves the previous valid configuration; saved active values survive browser reload.

**Demonstration complete:** correct application passes; the no-persist variant fails because a saved value is not restored; evidence connects the failure to SAVE-01. A crash or unrelated timeout does not count as detecting the defect. Now document the process.


# T2 Extract repeatable test effectiveness evaluation

## Stage 2 Abstraction focus
Parameterize the test workspace, application command/variant, port, state path, case data, and evidence destination. Preserve the rule that the suite must pass a correct application before a defective-application failure earns credit.

## Stage 3 Deterministic boundary
| Move into code | Retain as reasoning |
| --- | --- |
| Start/stop the local app and reset owned test state | Judge whether a defect represents a requirement violation |
| Check server/browser health and run collected tests | Identify which missing assertion allowed the defect to survive |
| Record counts, exit codes, and failure details | Decide whether the failure is relevant rather than incidental |
| Compare correct and defective execution records | Improve the test's semantic coverage |

## Stage 4 Required implementation behavior
Implement a serial evaluation runner that owns only its child server process, waits for readiness, runs the test suite, and stops that process in a finally block. Never terminate unrelated processes merely because they occupy a port. Use separate state files or clean resets for each run.

Record the exact application variant, case, test files/digests, collected/skipped counts, browser startup outcome, and assertion details. A failed startup is blocked. A suite that fails the correct app cannot receive a successful detection score. Require review of the assertion that detected each defect.

**Required checks:** correct app passes; known persistence defect detected; required skips rejected; occupied port or failed startup reported as infrastructure failure; test failures preserved in the final result rather than swallowed.

**Transfer preparation, from the training root**
```bash
python materials/prepare_lab.py t2 transfer work/t2-transfer-md
python materials/prepare_lab.py t2 transfer work/t2-transfer-code
```
Start with the correct application and case.json. Transfer input includes the valid endpoint 65535. The facilitator then restarts with `--variant bad-boundary`, using the same clean-state procedure. The agent must detect the requirement violation from test evidence.

Transfer general runners/helpers, not a finished demo test file. Keep the variant label undisclosed until evaluation when feasible. The supplied source includes the variants for reproducibility; this is a classroom exercise, not an adversarially isolated benchmark.

**Acceptance:** the improved suite passes correct behavior and detects the invalid rejection of a valid boundary for the relevant reason. It also meets the full required-case list on the preceding page. The facilitator reviews the actual assertions, not only pytest exit status.

**Debrief:** how did executable feedback expose a misleading green test result, and which parts of that evaluation still need human judgment?
