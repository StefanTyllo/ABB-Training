# Extraction map: test-effectiveness evaluation (T2)

Stage 3 design only. No reusable automation is implemented here (stage 4).
Source: `workflow.md` steps 1-11, grounded in the Stage 1 run recorded in `evidence/session.md`.

Disposition: **DET** = deterministic code, **MJ** = model judgment, **HD** = human decision.
Priority: P1 = collection, parsing, calculation, comparison, validation, reporting (code first); P2 = other.

## Step review

| # | Step | Purpose | Inputs | Operation | Expected output | Failure condition | Disposition | Function |
|---|---|---|---|---|---|---|---|---|
| 1 | Validate inputs (P1 validation) | Refuse to start on a bad workspace or oracle | WORKSPACE, REQUIREMENTS_FILE, CASE_FILE, EVIDENCE_DIR | Check existence, readability, JSON validity, required case keys; create evidence dir | Validated config, or a list of problems | Missing or unreadable path, invalid JSON, evidence dir not creatable -> **blocked** | DET | `validate_inputs` |
| 1b | Choose behavior for missing REQUIRED_CASES or server command | Record assumption | Task card, requirements | Derive cases only from requirements; note that variants were not controlled if no server command | Recorded assumption | Case list not derivable from requirements | MJ (assumption), HD (task owner confirms) | none |
| 2 | Read task card, contract, requirements, case, POM, tests (P1 collection) | Gather the oracle and the artifacts under test | Files in the workspace | Read files, compute SHA-256 of test and POM files | Test/POM/immutable-file digest manifest | Unreadable file; immutable file digest differs from snapshot | DET (read and digest), MJ (understand requirements) | `collect_artifact_digests` |
| 3 | Judge the baseline test | State what a pass proves and does not prove | Baseline test source, requirements | Compare asserted claims with SAVE-01, VAL-01 | Statement: the pass shows only the "Saved" status. It does not prove persistence, rejection, preserved state or boundaries | Judgment not tied to a requirement ID | MJ | none |
| 4 | Map requirements to observable behavior and waits | Decide what to assert and the wait that makes it reliable | Requirement text | SAVE-01 -> reload then compare. VAL-01 -> status text. ASYNC-01 -> `ready()` or `visible()` waits | Requirement-to-assertion-to-wait table | Mapping uses fixed sleeps or unobservable state | MJ | none |
| 4b | Check the required-case matrix is present (P1 validation) | Make sure each required case exists in the suite | Collected pytest node ids, required-case list | Match names (`save_reload`, `port_boundary`, `invalid_save`) and parameters (1, 65535, 0, 65536, non-integer) | Matrix with present/missing flags | Any required case missing, or fewer tests than the minimum | DET | `check_case_coverage` |
| 5 | Browser preflight and baseline run (P1 collection) | Prove the environment can drive Chrome and run pytest | Preflight script, BASE_URL | Run subprocess with argument list and timeout; capture return code, stdout, JUnit | Run record (return code, counts, browser outcome) | Chrome or driver failure, timeout, no JUnit -> **blocked (infrastructure)** | DET | `run_pytest` |
| 6 | Defect run with the baseline (P1) | Show whether the weak test misses the defect | Defect variant, free port, fresh state | `start_server`, `wait_ready`, `run_pytest`, `stop_server` | Record. A pass shows a coverage gap | Port occupied or startup failure -> **blocked** | DET (run), MJ (explain why it passes) | `find_free_port`, `start_server`, `wait_ready`, `stop_server` |
| 7 | Strengthen the suite | Add assertions for persistence, boundaries and invalid-save | Gap analysis, case values | Write tests and POM methods | Tests that assert independent expected values | Expected values copied from actual output or server source | MJ (design), HD (review assertions) | none: semantic coverage stays with a person |
| 8 | Evaluate every variant serially (P1 collection) | Produce comparable records for correct and each defect | Variant list, free ports, new state paths | For each variant: `find_free_port`, new state, `start_server`, `wait_ready`, `run_pytest`, `parse_junit`, `stop_server` in a finally block | One record per variant (variant, port, state path, log, JUnit, return code, counts) | Port occupied, not ready, timeout, setup error -> **blocked**. Never kill the port occupant | DET | `evaluate_variant` |
| 8b | Parse results (P1 parsing) | Turn JUnit into structured counts and failures | JUnit XML | Count tests, failures, errors, skips. Pull test name, message, exception type | Counts and a list of failure records | Missing or malformed XML -> blocked. Never fabricate a report | DET | `parse_junit` |
| 8c | Classify each failure (P1 calculation) | Separate assertion failures from incidental errors | Failure records | Rule: `AssertionError` in a test whose name and requirement marker are known -> assertion. `TimeoutException`, `WebDriverException`, setup errors -> incidental | Failure records with a class (`assertion` or `incidental`) | An unrecognized exception type defaults to `incidental`, never to detection | DET (rule), MJ (relevance) | `classify_failures` |
| 9 | Compare correct vs defective (P1 comparison) | Decide if the defect was detected | Records for correct and defective runs | Gate: correct passed, 0 skips, 0 errors. Defect has at least one `assertion` failure in the expected test family | Provisional verdict (`detected`, `survived`, `not_credited`, `blocked`) | Correct failed -> `not_credited`. Defect passed -> `survived`. Only incidental failures -> not detection | DET (gate), MJ (relevance), HD (final accept) | `compare_runs` |
| 9b | Review each detecting assertion | Check it ties to a requirement ID, with expected value, actual value and phase (before or after reload) | Failure message, test source | Extract expected and actual from the message, record the phase. Judge whether it is the right assertion | Review sheet with the status "needs review" | Failure with no requirement tie or a vague message | DET (extract fields), MJ (relevance), HD (approval) | `summarize_detection` |
| 9c | Decide whether the defect is a true requirement violation | Calibrate the finding | Requirements, observed behavior | Compare the behavior with the requirement text | Violated (yes/no) and the requirement ID | Ambiguous requirement | HD | none |
| 10 | Cleanup | Leave no owned process and don't disturb others | Owned child handles | Terminate only owned PIDs in a finally block. Probe other servers for health | Stopped children; others still answer | Owned child still alive after timeout -> report | DET | `stop_server`, `probe_url` |
| 11 | Write evidence and result (P1 reporting) | Persist an honest, auditable result | All records, verdicts, deviations, not-run list | Write JSON and markdown. Preserve failures and blocked states | `variant-evaluation.json`, evidence index | Report hides a failure, or status is `passed` while any gate failed | DET (write), MJ (narrative), HD (sign-off) | `write_report` |

## Function contracts (all stdlib only; none touch tests, expected values, or app files)

| Function | Input | Output | Errors and invariants |
|---|---|---|---|
| `validate_inputs(workspace, requirements, case, evidence_dir)` | Paths as strings or `Path` | `{ok: bool, problems: [str], case: dict}` | Never raises on a bad path. Returns problems. `ok=False` means blocked. Creates only `evidence_dir`. |
| `collect_artifact_digests(workspace, relative_paths)` | Workspace path, list of relative paths | `{path: sha256 hex or null}` | A missing file maps to `null`. Read-only. |
| `check_case_coverage(junit_or_node_ids, required)` | List of test ids/names, required spec (name substrings and parameter values) | `{missing: [str], present: [str], executed_count: int}` | Matches by test name and parameter id. A missing item is data, not an exception. |
| `find_free_port(host="127.0.0.1")` | Host | `int` port | Binds port 0 and releases it. A caller must still handle a later bind failure. |
| `start_server(cmd_template, variant, port, state_path, log_path)` | Command as an argument list template, variant label, port, new state path, log path | `Popen` handle or a `StartResult(ok, pid, error)` | Refuses an existing `state_path`, or removes only a file it owns. Writes logs. Returns failure if the process exits at once. |
| `wait_ready(base_url, timeout_s, proc)` | URL, finite timeout, owned process | `{ready: bool, elapsed_s, error}` | Polls with `urllib`. Returns not ready if the process died or time ran out. Never sleeps unbounded. |
| `run_pytest(workspace, base_url, junit_path, timeout_s)` | Workspace, BASE_URL, JUnit path, timeout | `{returncode, stdout, junit_exists, timed_out, infra_error}` | Uses `[sys.executable, "-m", "pytest", "tests", "-q", "-ra", f"--junitxml={path}"]` with cwd. Passes `BASE_URL` through the env without printing the env. Keeps the real return code. `timed_out=True` means blocked. |
| `parse_junit(junit_path)` | Path to XML | `{tests, passed, failures, errors, skipped, cases: [{name, status, message, exc_type}]}` | Raises `JUnitUnavailable` for a missing or bad file. Never invents counts. |
| `classify_failures(cases, requirement_markers)` | Parsed cases, test-to-requirement map | Cases with `class` = `assertion` or `incidental`, and `requirement_id` | `AssertionError` = assertion. Timeout, WebDriver, setup, collection error = incidental. Unknown = incidental. |
| `evaluate_variant(workspace, variant, cfg)` | Workspace, variant label, config (command, timeouts, evidence dir) | Run record: `{variant, port, state_path, log_path, junit_path, status, pytest_returncode, counts, failures}` | `status` is `ok`, `blocked` or `error`. Stops its own child in a finally block. Never kills another process. |
| `compare_runs(correct_record, defect_record, expected_family)` | Two run records, expected test-name family for the defect | `{verdict: detected\|survived\|not_credited\|blocked, reasons: [str]}` | Rules: correct must pass with 0 skips and 0 errors, otherwise `not_credited`. Blocked on either side means `blocked`. At least one assertion failure in the family is needed for `detected`. The verdict remains provisional until human review. |
| `summarize_detection(failure)` | One classified failure | `{test, requirement_id, expected, actual, phase, needs_review: true}` | Extracts what it can from the message. Fields it cannot derive are `null`. |
| `probe_url(url, timeout_s)` | URL | `bool` | Read-only. Used to show that a root-owned server still answers. |
| `stop_server(proc, grace_s)` | Owned `Popen` | `{stopped: bool, forced: bool}` | Acts on that handle only. Terminate, then kill after the grace period. |
| `write_report(records, verdicts, deviations, not_run, out_path)` | Run records, verdicts, notes, not-run list | JSON file (`status`, `variants`, ...) | `status` is `passed` only when all gates pass. Otherwise it records the real `failed` or `blocked`. Writes a new file and never reuses stale content. |

## Items that stay out of code
- Whether a defect truly violates a requirement (9c): HD.
- Whether a detecting assertion is the right and sufficient one (9b): MJ with HD sign-off.
- Which missing assertion allowed the defect to survive, and the new tests that close the gap (7): MJ.
- Whether a failure is relevant or incidental when the rule does not decide it (8c, 9): MJ.
- Setting required cases when the task is silent (1b): HD.

## Deterministic boundary rules
1. The correct run must pass first. Otherwise `compare_runs` returns `not_credited`.
2. A timeout, startup failure, occupied port, driver error or setup error is `blocked`, never detection.
3. Each run has its own port, new state path, log and JUnit file.
4. Only the owned child process is terminated.
5. Failures and blocked outcomes are written to the report as they happened.

## Gaps and untested branches
- The `bad-boundary` variant has not been executed, so boundary detection is unproven. The runner can only verify it from the required cases.
- The extraction of expected and actual values from assertion messages depends on pytest's message format. This is unverified, so fields may be `null`.
- Not run in this stage: any automation, since stage 4 owns implementation.
