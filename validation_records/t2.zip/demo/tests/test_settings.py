import pytest


BASELINE = {"host": "baseline.example.test", "port": "502"}


def save_tcp(page, host, port, auth="none", password=None):
    page.choose_connection("tcp")
    page.fill("host", host)
    page.fill("port", port)
    page.choose_auth(auth)
    if password is not None:
        page.fill("password", password)
    return page.save()


@pytest.mark.requirement("SAVE-01")
def test_weak_save_smoke(page):
    assert save_tcp(page, "lab.example.test", "1502") == "Saved"


@pytest.mark.requirement("SAVE-01")
@pytest.mark.parametrize(
    "host,port,auth,password",
    [
        ("lab.example.test", "1502", "password", "practice-only"),
        ("other.example.test", "2000", "none", None),
    ],
)
def test_save_reload_restores_tcp_values(page, host, port, auth, password):
    assert save_tcp(page, host, port, auth, password) == "Saved"
    page.reload()
    assert page.selected("connection") == "tcp"
    assert page.value("host") == host
    assert page.value("port") == port
    assert page.selected("auth") == auth
    if auth == "password":
        assert page.value("password") == password


@pytest.mark.requirement("VAL-01")
@pytest.mark.parametrize("port", ["1", "65535"])
def test_port_boundary_accepts_valid(page, port):
    assert save_tcp(page, "lab.example.test", port) == "Saved"
    page.reload()
    assert page.selected("connection") == "tcp"
    assert page.value("port") == port


@pytest.mark.requirement("VAL-01")
@pytest.mark.parametrize("port", ["0", "65536", "abc"])
def test_port_boundary_rejects_invalid(page, port):
    assert save_tcp(page, "lab.example.test", port) != "Saved"


@pytest.mark.requirement("SAVE-01")
@pytest.mark.parametrize("port", ["0", "65536", "abc"])
def test_invalid_save_preserves_baseline(page, port):
    assert save_tcp(page, BASELINE["host"], BASELINE["port"]) == "Saved"
    assert save_tcp(page, "changed.example.test", port) != "Saved"
    page.reload()
    assert page.selected("connection") == "tcp"
    assert page.value("host") == BASELINE["host"]
    assert page.value("port") == BASELINE["port"]
