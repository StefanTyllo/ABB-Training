"""Checks for automation/guardrails.py using disposable fixtures (never edits real sources).

Run: python -m unittest discover -s automation/tests -v   (from the workspace root)
Each case builds a temporary workspace under automation/tests/_work/ from
fixtures/ (the seeded, defective original netlist plus the real sources are
copied) and mutates only the copy.
"""
import csv
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
REAL = HERE.parents[1]
GUARD = REAL / "automation" / "guardrails.py"
FIXTURES = HERE / "fixtures"
WORK = HERE / "_work"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class GuardrailCase(unittest.TestCase):
    def setUp(self):
        WORK.mkdir(exist_ok=True)
        self.ws = Path(tempfile.mkdtemp(dir=WORK))
        shutil.copytree(FIXTURES / "source", self.ws / "source")
        (self.ws / "derived").mkdir()
        (self.ws / "evidence").mkdir()
        shutil.copy(FIXTURES / "seeded_defective_netlist.json", self.ws / "derived" / "netlist.json")

    def tearDown(self):
        shutil.rmtree(self.ws, ignore_errors=True)
        try:
            WORK.rmdir()
        except OSError:
            pass

    def run_guard(self):
        proc = subprocess.run([sys.executable, str(GUARD), "--workspace", str(self.ws)], capture_output=True, text=True)
        return proc.returncode, proc.stdout + proc.stderr

    def edit_json(self, rel, fn):
        path = self.ws / rel
        doc = json.loads(path.read_text(encoding="utf-8"))
        fn(doc)
        path.write_text(json.dumps(doc, indent=2), encoding="utf-8")

    def edit_bom(self, fn):
        path = self.ws / "source" / "bom.csv"
        with open(path, newline="", encoding="utf-8") as h:
            rows = list(csv.DictReader(h))
        fn(rows)
        with open(path, "w", newline="", encoding="utf-8") as h:
            w = csv.DictWriter(h, fieldnames=["board_id", "source_revision", "ref", "kind", "value"])
            w.writeheader()
            w.writerows(rows)

    def report(self):
        return json.loads((self.ws / "report.json").read_text(encoding="utf-8"))

    def netlist(self):
        return json.loads((self.ws / "derived" / "netlist.json").read_text(encoding="utf-8"))

    def codes(self):
        return {(f["code"], f.get("ref")) for f in self.report()["findings"]}


class SeededDefects(GuardrailCase):
    def test_defects_corrected_and_equivalent_reported(self):
        src_hashes = {p.name: sha(p) for p in (self.ws / "source").iterdir()}
        rc, out = self.run_guard()
        self.assertEqual(rc, 0, out)
        rep = self.report()
        self.assertEqual(rep["status"], "pass")
        self.assertEqual(rep["changed_files"], ["derived/netlist.json"])
        self.assertEqual(self.codes(), {("value_mismatch", "R1"), ("pin_mapping_mismatch", "U1"), ("equivalent_notation", "C1")})
        net = {c["ref"]: c for c in self.netlist()["components"]}
        self.assertEqual(net["R1"]["value"], "4.7 kOhm")
        self.assertEqual(net["U1"]["pins"]["2"], "SENSE")
        self.assertEqual(net["C1"]["value"], "0.1 uF")  # equivalent notation preserved
        self.assertEqual([c["ref"] for c in self.netlist()["components"]], ["U1", "C1", "R1"])  # order preserved
        self.assertEqual(src_hashes, {p.name: sha(p) for p in (self.ws / "source").iterdir()})
        before = json.loads((self.ws / "evidence" / "stage4_before_record.json").read_text())
        self.assertEqual(next(c for c in before["netlist_before"]["components"] if c["ref"] == "R1")["value"], "10 kOhm")

    def test_idempotent_rerun_keeps_cumulative_audit(self):
        self.run_guard()
        first = (sha(self.ws / "report.json"), sha(self.ws / "derived" / "netlist.json"))
        rc, _ = self.run_guard()
        self.assertEqual(rc, 0)
        self.assertEqual(first, (sha(self.ws / "report.json"), sha(self.ws / "derived" / "netlist.json")))
        self.assertIn(("value_mismatch", "R1"), self.codes())

    def test_changed_sources_start_new_audit(self):
        self.run_guard()
        self.edit_bom(lambda rows: [r.update(value="2.2 kOhm") for r in rows if r["ref"] == "R1"])
        self.edit_json("source/schematic.json", lambda d: [c.update(value="2.2 kOhm") for c in d["components"] if c["ref"] == "R1"])
        rc, _ = self.run_guard()
        self.assertEqual(rc, 0)
        self.assertEqual(self.netlist()["components"][2]["value"], "2.2 kOhm")
        self.assertTrue(list((self.ws / "evidence").glob("stage4_before_record.*.json")))


class CleanAndEquivalent(GuardrailCase):
    def make_clean(self):
        self.run_guard()
        return sha(self.ws / "derived" / "netlist.json")

    def test_equivalent_100nF_and_0p1uF_only(self):
        self.make_clean()
        (self.ws / "report.json").unlink()
        (self.ws / "evidence" / "stage4_before_record.json").unlink()
        digest = sha(self.ws / "derived" / "netlist.json")
        rc, out = self.run_guard()
        self.assertEqual(rc, 0, out)
        self.assertEqual(self.codes(), {("equivalent_notation", "C1")})
        self.assertEqual(self.report()["changed_files"], [])
        self.assertEqual(digest, sha(self.ws / "derived" / "netlist.json"))

    def test_reordered_components_are_not_discrepancies(self):
        self.make_clean()
        (self.ws / "report.json").unlink()
        (self.ws / "evidence" / "stage4_before_record.json").unlink()
        self.edit_json("derived/netlist.json", lambda d: d["components"].reverse())
        rc, _ = self.run_guard()
        self.assertEqual(rc, 0)
        self.assertEqual(self.codes(), {("equivalent_notation", "C1")})

    def test_unrelated_clean_input_has_no_fabricated_findings(self):
        self.make_clean()
        (self.ws / "report.json").unlink()
        (self.ws / "evidence" / "stage4_before_record.json").unlink()
        self.edit_json("derived/netlist.json", lambda d: [c.update(value="100 nF") for c in d["components"] if c["ref"] == "C1"])
        rc, _ = self.run_guard()
        self.assertEqual(rc, 0)
        self.assertEqual(self.report()["findings"], [])


class FailureBranches(GuardrailCase):
    def test_missing_source_revision_blocks_and_leaves_netlist(self):
        self.edit_json("source/schematic.json", lambda d: d.pop("source_revision"))
        before = sha(self.ws / "derived" / "netlist.json")
        rc, out = self.run_guard()
        self.assertEqual(rc, 2, out)
        rep = self.report()
        self.assertEqual(rep["status"], "blocked")
        self.assertEqual(rep["changed_files"], [])
        self.assertIn("missing_source_revision", {f["code"] for f in rep["findings"]})
        self.assertEqual(before, sha(self.ws / "derived" / "netlist.json"))

    def test_blank_bom_row_revision_blocks(self):
        self.edit_bom(lambda rows: rows[1].update(source_revision=""))
        before = sha(self.ws / "derived" / "netlist.json")
        rc, _ = self.run_guard()
        self.assertEqual(rc, 2)
        self.assertEqual(before, sha(self.ws / "derived" / "netlist.json"))

    def test_wrong_revision_blocks(self):
        self.edit_json("source/schematic.json", lambda d: d.update(source_revision="R9"))
        rc, _ = self.run_guard()
        self.assertEqual(rc, 2)

    def test_missing_component_in_netlist_fails_without_edit(self):
        self.edit_json("derived/netlist.json", lambda d: d["components"].pop())
        before = sha(self.ws / "derived" / "netlist.json")
        rc, out = self.run_guard()
        self.assertEqual(rc, 1, out)
        self.assertIn(("missing_component", "R1"), self.codes())
        self.assertEqual(self.report()["changed_files"], [])
        self.assertEqual(before, sha(self.ws / "derived" / "netlist.json"))

    def test_unknown_unit_is_rejected(self):
        self.edit_bom(lambda rows: [r.update(value="4.7 MOhm") for r in rows if r["ref"] == "R1"])
        before = sha(self.ws / "derived" / "netlist.json")
        rc, _ = self.run_guard()
        self.assertEqual(rc, 2)
        self.assertEqual(before, sha(self.ws / "derived" / "netlist.json"))

    def test_bom_schematic_conflict_blocks(self):
        self.edit_json("source/schematic.json", lambda d: [c.update(value="1 kOhm") for c in d["components"] if c["ref"] == "R1"])
        before = sha(self.ws / "derived" / "netlist.json")
        rc, _ = self.run_guard()
        self.assertEqual(rc, 2)
        self.assertEqual(before, sha(self.ws / "derived" / "netlist.json"))

    def test_pin_set_mismatch_fails_without_edit(self):
        self.edit_json("derived/netlist.json", lambda d: [c["pins"].pop("4") for c in d["components"] if c["ref"] == "U1"])
        before = sha(self.ws / "derived" / "netlist.json")
        rc, _ = self.run_guard()
        self.assertEqual(rc, 1)
        self.assertEqual(before, sha(self.ws / "derived" / "netlist.json"))

    def test_missing_source_file_blocks(self):
        (self.ws / "source" / "bom.csv").unlink()
        rc, _ = self.run_guard()
        self.assertEqual(rc, 2)


class RealTransferInputs(unittest.TestCase):
    def test_real_package_blocks_on_missing_revision_and_keeps_netlist(self):
        WORK.mkdir(exist_ok=True)
        ws = Path(tempfile.mkdtemp(dir=WORK))
        try:
            shutil.copytree(REAL / "source", ws / "source")
            (ws / "derived").mkdir()
            (ws / "evidence").mkdir()
            shutil.copy(REAL / "derived" / "netlist.json", ws / "derived" / "netlist.json")
            before = sha(ws / "derived" / "netlist.json")
            proc = subprocess.run([sys.executable, str(GUARD), "--workspace", str(ws)], capture_output=True, text=True)
            self.assertEqual(proc.returncode, 2, proc.stdout + proc.stderr)
            rep = json.loads((ws / "report.json").read_text(encoding="utf-8"))
            self.assertEqual((rep["status"], rep["case"], rep["changed_files"]), ("blocked", "transfer", []))
            self.assertIn("missing_source_revision", {f["code"] for f in rep["findings"]})
            self.assertEqual(before, sha(ws / "derived" / "netlist.json"))
        finally:
            shutil.rmtree(ws, ignore_errors=True)
            try:
                WORK.rmdir()
            except OSError:
                pass


class UnitFunctions(unittest.TestCase):
    def test_parse_and_equal(self):
        sys.path.insert(0, str(REAL / "automation"))
        import board_checker as bc
        self.assertTrue(bc.quantities_equal(bc.parse_quantity("100 nF"), bc.parse_quantity("0.1 uF")))
        self.assertEqual(bc.parse_quantity("4.7 kOhm")["value"], 4700.0)
        self.assertFalse(bc.quantities_equal(bc.parse_quantity("1 kOhm"), bc.parse_quantity("1 uF")))
        with self.assertRaises(bc.UnitError):
            bc.parse_quantity("5 mH")


if __name__ == "__main__":
    unittest.main()
