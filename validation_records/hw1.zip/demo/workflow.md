# Workflow: reconcile a derived board netlist against approved sources

## Named inputs (all required; validate before use)
| Input | Meaning |
|---|---|
| `WORKSPACE` | Absolute root of the prepared package. Resolve every path below against it. |
| `APPROVAL_PATH` | Declares expected board ID, approved revision, approved source list. |
| `BOM_PATH` | Authority for component identity, kind, value. |
| `SCHEMATIC_PATH` | Authority for pin-to-net mapping; corroborates values. |
| `NETLIST_PATH` | Derived export under review; never an authority. |
| `REPORT_PATH`, `REPORT_CONTRACT_PATH` | Output report and its schema. |
| `EVIDENCE_DIR` | Where the session log is written. |
| `EXPECTED_BOARD`, `APPROVED_REVISION` | Read from `APPROVAL_PATH`; never hardcoded or taken from filenames/case labels. |

Values such as references, board IDs, revisions, pin names and numbers come from the data, never from this document.

## Missing-input behavior
- Any required path missing, unreadable, unparsable, or ambiguous: status `blocked`; do not edit `NETLIST_PATH`; `changed_files: []`; name the missing input and the authority who must supply it.
- Approval lacks the board, revision, or source list: `blocked`.
- Any approved source lacks its own board or revision declaration (including any single BOM row), or differs from approval: `blocked` with finding `missing_source_revision` naming the source and requesting an explicitly revisioned approved copy. The approval's expected revision is not evidence for a source that does not declare one. Invent no recovery evidence.
- Evidence capture unavailable (e.g. hashing denied): say so in the log and report; do not claim it was done.

## Steps
1. Read the task card and contracts. Fix the authority hierarchy above.
2. Inventory each source (parse JSON, read CSV). Record the inventory and the original netlist values in `EVIDENCE_DIR` before any change. Where permitted, record hashes of sources and the netlist; otherwise record that none were captured.
3. Provenance gate (before any edit): every approved source independently declares `EXPECTED_BOARD` and `APPROVED_REVISION`. Failure follows Missing-input behavior.
4. Match components by reference designator: reference sets must be equal with no duplicates or missing items. Match pins by pin number, never by file order. Compare identity/kind to the BOM.
5. Normalize quantities dimensionally: kOhm = 1000 ohm, Ohm = ohm, nF = 1e-9 F, uF = 1e-6 F, F = F. Compare normalized numbers (tolerant of float rounding). Reject any unit not listed. Treat IC part identifiers as literal strings.
6. Classify each difference: `equivalent_notation` (same physical value, different text; leave unchanged, report as informational), `value_mismatch`, `pin_mapping_mismatch`.
7. Before changing anything, state for each real discrepancy the exact source field(s) supporting the fix: BOM (and schematic corroboration) for values; schematic for pins. Correct only fully supported discrepancies. If sources conflict with each other, stop and escalate to the design authority; do not guess.
8. Edit only the offending fields in `NETLIST_PATH`; preserve order, unrelated data, and equivalent notation. Never edit source files or supplied tools.
9. Re-read and re-compare the corrected netlist against sources: zero unresolved discrepancies required. Confirm sources are unchanged using recorded hashes or file modification evidence. Do not rely on `git diff` if the files are untracked.
10. Write `REPORT_PATH` per `REPORT_CONTRACT_PATH`: findings (resolved ones and equivalent notation remain, each with a `ref` for component findings, exact source field and before/after values as evidence, and an explanation), nonempty assumptions, and `changed_files` listing only derived artifacts actually changed. Status follows the table.

| Outcome | Status | `changed_files` |
|---|---|---|
| All reconciled, or already equivalent | `pass` | changed derived artifacts (empty if none) |
| Provenance/input failure or unresolved authority conflict | `blocked` | `[]` |

## Automation (stage 4)
Steps 2–10 are executed by the helper; see `automation/README.md`.
```bash
python automation/guardrails.py --workspace /absolute/path/to/workspace
python -m unittest discover -s automation/tests -v
```
Exit code 0 = `pass`, 1 = `fail`, 2 = `blocked`; treat 1 and 2 as real results, not helper errors.
- Read the helper's expected/observed lines (also in `evidence/stage4_guardrails_log.jsonl`) and `evidence/stage4_check_result.json` (hashes, findings, residual count).
- A `provenance_gate` failure means step 3 blocked: the netlist is untouched; obtain an explicitly revisioned approved source from the design authority (human).
- `authority_conflict` (BOM vs schematic) stays a human/design-authority decision; the helper never guesses.
- `equivalent_notation` findings are informational. The helper writes `evidence/stage4_before_record.json` before editing and keeps earlier findings on rerun, so reruns are idempotent.
- Still judgment: wording of assumptions, any difference outside the known codes, and whether the source hierarchy fits the real project.

## Invariants
- Authority: BOM = identity/value; schematic = pins; netlist is output only.
- Provenance precedes comparison; comparison precedes edits.
- Expected blocked results stay visible; never convert them to pass.
- No edits to sources, supplied tools, or the contract.

## Untested branches (not exercised by the observed session; treat as unverified)
- Blocked/missing-revision path and its unchanged-netlist guarantee.
- Source-to-source conflicts, unknown units, duplicate or missing references, differing pin sets or pin counts, BOM row/kind mismatches.
- Float-rounding tolerance choice for equivalence.
- Source-immutability proof via hashes (not captured in the observed session).
- Rerun on an already-reconciled package, and reuse of a stale report.

## Recovery
- Wrong edit: restore the field from the recorded before value and redo steps 9–10.
- Denied command: retry in simpler form and note it in the log.

## Completion criteria
Provenance validated; supported discrepancies corrected and re-verified; equivalent notation reported but unchanged; sources unchanged; report matches the contract; changed_files contains only changed derived artifacts.
