# Session log (scripted CI rehearsal, HW1 demo)

Some bash commands (compound ones using tee/sha256sum/git status) were denied by the CI permission layer; they were retried in simpler form. Before/after hashes of the netlist were therefore not captured; the before values are recorded from the actual printed output below.

1. `cat task-card.md CI_CONTRACT.md REPORT_CONTRACT.md` — read the rules. Rationale: establish authority and report schema first.
2. `python -m json.tool source/approval.json`, `cat source/bom.csv`, `python -m json.tool source/schematic.json`, `python -m json.tool derived/netlist.json`
   - Inventory: approval (SENSE-ALPHA, R7, approves bom.csv + schematic.json); BOM (authoritative identity/value); schematic (authoritative pins); netlist (derived, under review).
   - Revision check: BOM rows all SENSE-ALPHA/R7; schematic SENSE-ALPHA/R7; both match approval. Proceed.
   - Observed netlist before: U1 pins 2=GND,3=SENSE; C1 '0.1 uF'; R1 '10 kOhm'; order U1,C1,R1 (differs from sources; matched by ref).
3. Decisions
   - C1: 0.1 uF = 1e-7 F = 100 nF -> equivalent, no change (finding equivalent_notation).
   - R1: 10 kOhm=10000 ohm vs BOM and schematic 4.7 kOhm=4700 ohm; two authorities agree -> correct value (value_mismatch).
   - U1: schematic pins 2=SENSE,3=GND vs netlist swapped; schematic authoritative -> correct (pin_mapping_mismatch).
4. Edited derived/netlist.json (two edits only: U1 pins 2/3, R1 value). Order and other data preserved.
5. Verification python script comparing refs, pins, values: ref sets equal; pins equal for R1, C1, U1; R1 value '4.7 kOhm' matches BOM; C1 '0.1 uF' vs '100 nF' equivalent. `git diff -- derived source` printed nothing (files apparently not tracked), so source immutability rests on having made no edits to source/.
6. Created report.json (status pass, changed_files derived/netlist.json) and workflow.md.
