"""Reusable board-package checker (HW1): provenance gate, comparison, correction.

Authority hierarchy (encoded once, here):
  approval.json  -> expected board / revision / approved source list
  bom.csv        -> component identity, kind, value
  schematic.json -> pin-to-net mapping; corroborates values
  netlist.json   -> derived output under review, never an authority

Provenance/inventory functions are deliberately separate from the comparison
functions; callers must not compare when the provenance gate has findings.
"""
import copy
import csv
import hashlib
import json
import math
import re
from pathlib import Path

REL_TOL = 1e-9  # float-rounding tolerance for normalized quantity equality

# Explicit unit table: unit -> (dimension, multiplier to base unit). Unknown units are rejected.
UNIT_TABLE = {
    "Ohm": ("resistance", 1.0),
    "kOhm": ("resistance", 1000.0),
    "nF": ("capacitance", 1e-9),
    "uF": ("capacitance", 1e-6),
    "F": ("capacitance", 1.0),
}
# Component kinds with a quantity value and the dimension it must have; "ic" is a literal string.
KIND_DIMENSION = {"resistor": "resistance", "capacitor": "capacitance"}
LITERAL_KINDS = {"ic"}
BOM_COLUMNS = ["board_id", "source_revision", "ref", "kind", "value"]
CORRECTION_CODES = {"value_mismatch", "pin_mapping_mismatch"}


class InputError(Exception):
    """Missing/invalid authority or input: the assessment is blocked."""


class UnitError(InputError):
    """A quantity has an unsupported unit or malformed number."""


class DuplicateRefError(InputError):
    """A reference designator appears more than once in one document."""

    def __init__(self, label, ref):
        super().__init__(f"duplicate reference '{ref}' in {label}")
        self.label, self.ref = label, ref


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def resolve_workspace(path):
    """Return the absolute workspace root; every other path resolves against it."""
    root = Path(path).expanduser().resolve()
    if not root.is_dir():
        raise InputError(f"workspace '{path}' is not a directory")
    return root


def detect_lab(root):
    """Infer the lab from source files; reject missing or ambiguous shapes."""
    hw1 = [root / "source" / n for n in ("approval.json", "bom.csv", "schematic.json")]
    has_hw1 = [p.is_file() for p in hw1]
    has_hw2 = (root / "source" / "circuit.json").is_file()
    if all(has_hw1) and not has_hw2:
        return "hw1"
    if any(has_hw1) and has_hw2:
        raise InputError("ambiguous workspace: both HW1 and HW2 source shapes present")
    if has_hw2 and not any(has_hw1):
        raise InputError("HW2 workspace is not supported by this HW1 checker")
    missing = [f"source/{p.name}" for p, ok in zip(hw1, has_hw1) if not ok]
    raise InputError("missing required HW1 source files: " + ", ".join(missing))


def inventory_sources(root, paths):
    """Return {role: {path, exists, bytes, sha256}}; hashing failure gives sha256 None + reason."""
    inventory = {}
    for role, rel in paths.items():
        entry = {"path": rel, "exists": False, "bytes": None, "sha256": None}
        target = root / rel
        if target.is_file():
            entry["exists"] = True
            try:
                data = target.read_bytes()
                entry["bytes"], entry["sha256"] = len(data), sha256_bytes(data)
            except OSError as exc:
                entry["reason"] = f"unreadable: {exc}"
        inventory[role] = entry
    return inventory


def _load_json(path, label):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError) as exc:
        raise InputError(f"{label} is unreadable or not valid JSON: {exc}")


def load_approval(path):
    """Parse approval.json into {board_id, revision, sources}."""
    doc = _load_json(path, "approval")
    if not isinstance(doc, dict):
        raise InputError("approval must be a JSON object")
    board, rev, sources = doc.get("board_id"), doc.get("approved_revision"), doc.get("approved_sources")
    if not (isinstance(board, str) and board.strip()):
        raise InputError("approval lacks board_id")
    if not (isinstance(rev, str) and rev.strip()):
        raise InputError("approval lacks approved_revision")
    if not (isinstance(sources, list) and sources and all(isinstance(s, str) for s in sources)):
        raise InputError("approval lacks approved_sources list")
    return {"board_id": board, "revision": rev, "sources": sources}


def load_bom(path):
    """Parse bom.csv keeping raw strings; a blank revision is retained so the gate can see it."""
    try:
        with open(path, "r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            if reader.fieldnames is None or any(c not in reader.fieldnames for c in BOM_COLUMNS):
                raise InputError(f"bom is missing required columns {BOM_COLUMNS}")
            rows = [{c: (row.get(c) or "") for c in BOM_COLUMNS} for row in reader]
    except (OSError, csv.Error, UnicodeDecodeError) as exc:
        raise InputError(f"bom is unreadable: {exc}")
    return rows


def load_component_doc(path, label):
    """Parse schematic/netlist JSON; absent board/revision stay None (never defaulted)."""
    doc = _load_json(path, label)
    if not isinstance(doc, dict) or not isinstance(doc.get("components"), list):
        raise InputError(f"{label} must be an object with a components list")
    return {"board_id": doc.get("board_id"), "revision": doc.get("source_revision"),
            "components": doc["components"], "raw": doc}


def _declared(value):
    return value if isinstance(value, str) and value.strip() else None


def check_provenance(approval, declarations):
    """Gate: every approved source must itself declare the expected board and revision.

    declarations: {source_relpath: [(board, revision), ...]} (one tuple per BOM row).
    The approval's revision is never used as a fallback for an absent declaration.
    """
    findings = []
    for rel in approval["sources"]:
        if rel not in declarations:
            findings.append({"code": "source_not_available", "source": rel,
                             "detail": f"approved source {rel} is not available for checking"})
    for rel, decls in declarations.items():
        if rel not in approval["sources"]:
            findings.append({"code": "source_not_approved", "source": rel,
                             "detail": f"{rel} is not in approval approved_sources"})
        if not decls:
            findings.append({"code": "missing_source_revision", "source": rel,
                             "detail": f"{rel} contains no records declaring board/revision"})
        for index, (board, rev) in enumerate(decls, 1):
            where = f"{rel} (record {index})"
            if _declared(rev) is None:
                findings.append({"code": "missing_source_revision", "source": rel,
                                 "detail": f"{where} declares no source_revision; "
                                           f"approved revision is {approval['revision']}"})
            elif rev != approval["revision"]:
                findings.append({"code": "source_revision_mismatch", "source": rel,
                                 "detail": f"{where} declares revision '{rev}', approval expects '{approval['revision']}'"})
            if _declared(board) is None:
                findings.append({"code": "missing_source_board", "source": rel,
                                 "detail": f"{where} declares no board_id; expected {approval['board_id']}"})
            elif board != approval["board_id"]:
                findings.append({"code": "source_board_mismatch", "source": rel,
                                 "detail": f"{where} declares board '{board}', approval expects '{approval['board_id']}'"})
    return findings


def index_components(items, label):
    """Index component dicts by reference designator; reject duplicates and malformed entries."""
    index = {}
    for item in items:
        ref = item.get("ref") if isinstance(item, dict) else None
        if not (isinstance(ref, str) and ref):
            raise InputError(f"{label} has a component without a string ref")
        if ref in index:
            raise DuplicateRefError(label, ref)
        index[ref] = item
    return index


def compare_ref_sets(bom_idx, sch_idx, net_idx):
    """Return refs missing from / extra in each document relative to the BOM identity set."""
    bom_refs = set(bom_idx)
    return {
        "schematic_missing": sorted(bom_refs - set(sch_idx)),
        "schematic_extra": sorted(set(sch_idx) - bom_refs),
        "netlist_missing": sorted(bom_refs - set(net_idx)),
        "netlist_extra": sorted(set(net_idx) - bom_refs),
    }


_QTY = re.compile(r"^\s*([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)\s*([A-Za-z]+)\s*$")


def parse_quantity(text):
    """Parse '4.7 kOhm' to {value (base units), dimension, raw}; reject unknown units."""
    match = _QTY.match(text) if isinstance(text, str) else None
    if not match:
        raise UnitError(f"malformed quantity {text!r}")
    number, unit = float(match.group(1)), match.group(2)
    if unit not in UNIT_TABLE:
        raise UnitError(f"unsupported unit '{unit}' in {text!r}; supported: {sorted(UNIT_TABLE)}")
    if not math.isfinite(number):
        raise UnitError(f"non-finite number in {text!r}")
    dimension, scale = UNIT_TABLE[unit]
    return {"value": number * scale, "dimension": dimension, "raw": text}


def quantities_equal(a, b, rel_tol=REL_TOL):
    """Equal when same dimension and equal within an explicit relative tolerance."""
    return a["dimension"] == b["dimension"] and math.isclose(a["value"], b["value"], rel_tol=rel_tol, abs_tol=0.0)


def compare_value(kind, bom_val, sch_val, net_val):
    """Classify a netlist value against BOM (authority) and schematic (corroboration).

    Statuses: match | equivalent_notation | value_mismatch | authority_conflict.
    """
    if kind in LITERAL_KINDS:
        if bom_val != sch_val:
            return {"status": "authority_conflict"}
        return {"status": "match" if net_val == bom_val else "value_mismatch"}
    if kind not in KIND_DIMENSION:
        raise InputError(f"unsupported component kind '{kind}'")
    bom_q, sch_q, net_q = (parse_quantity(v) for v in (bom_val, sch_val, net_val))
    for label, qty in (("BOM", bom_q), ("schematic", sch_q), ("netlist", net_q)):
        if qty["dimension"] != KIND_DIMENSION[kind]:
            raise UnitError(f"{label} value {qty['raw']!r} is {qty['dimension']}, expected {KIND_DIMENSION[kind]} for {kind}")
    normalized = {"bom": bom_q["value"], "schematic": sch_q["value"], "netlist": net_q["value"]}
    if not quantities_equal(bom_q, sch_q):
        return {"status": "authority_conflict", "normalized": normalized}
    if not quantities_equal(bom_q, net_q):
        return {"status": "value_mismatch", "normalized": normalized}
    status = "match" if net_val == bom_val else "equivalent_notation"
    return {"status": status, "normalized": normalized}


def compare_pins(sch_pins, net_pins):
    """Compare pin->net maps by pin number (string keys), ignoring order."""
    sch = {str(k): v for k, v in sch_pins.items()}
    net = {str(k): v for k, v in net_pins.items()}
    if set(sch) != set(net):
        return {"status": "pin_set_mismatch", "diffs": [],
                "missing": sorted(set(sch) - set(net)), "extra": sorted(set(net) - set(sch))}
    diffs = [{"pin": p, "expected": sch[p], "actual": net[p]} for p in sorted(sch) if sch[p] != net[p]]
    return {"status": "pin_mapping_mismatch" if diffs else "match", "diffs": diffs}


def compare_package(bom_idx, sch_idx, net_idx):
    """Compare every component; return records plus unresolved/conflict lists.

    Each record: {code, ref, field, before, after, bom, schematic, detail}.
    'conflicts' need the design authority; 'unresolved' are non-correctable export problems.
    """
    records, conflicts, unresolved = [], [], []
    sets = compare_ref_sets(bom_idx, sch_idx, net_idx)
    for ref in sets["schematic_missing"] + sets["schematic_extra"]:
        conflicts.append({"code": "component_set_conflict", "ref": ref,
                          "detail": f"BOM and schematic disagree about the presence of {ref}"})
    for ref in sets["netlist_missing"]:
        unresolved.append({"code": "missing_component", "ref": ref,
                           "detail": f"{ref} is in source/bom.csv but absent from derived/netlist.json"})
    for ref in sets["netlist_extra"]:
        unresolved.append({"code": "extra_component", "ref": ref,
                           "detail": f"{ref} is in derived/netlist.json but not in source/bom.csv"})
    if conflicts:
        return records, conflicts, unresolved
    for ref in sorted(set(bom_idx) & set(net_idx)):
        bom, sch, net = bom_idx[ref], sch_idx[ref], net_idx[ref]
        if sch.get("kind") != bom["kind"]:
            conflicts.append({"code": "authority_conflict", "ref": ref,
                              "detail": f"kind differs: bom '{bom['kind']}' vs schematic '{sch.get('kind')}'"})
            continue
        if net.get("kind") != bom["kind"]:
            unresolved.append({"code": "kind_mismatch", "ref": ref,
                               "detail": f"derived kind '{net.get('kind')}' differs from BOM '{bom['kind']}'"})
            continue
        result = compare_value(bom["kind"], bom["value"], sch.get("value"), net.get("value"))
        if result["status"] == "authority_conflict":
            conflicts.append({"code": "authority_conflict", "ref": ref,
                              "detail": f"BOM value '{bom['value']}' conflicts with schematic value '{sch.get('value')}'"})
        elif result["status"] in ("value_mismatch", "equivalent_notation"):
            records.append({"code": result["status"], "ref": ref, "field": "value",
                            "before": net.get("value"), "after": bom["value"],
                            "bom": bom["value"], "schematic": sch.get("value"),
                            "normalized": result.get("normalized")})
        pins = compare_pins(sch.get("pins") or {}, net.get("pins") or {})
        if pins["status"] == "pin_set_mismatch":
            unresolved.append({"code": "pin_set_mismatch", "ref": ref,
                               "detail": f"pin sets differ: missing {pins['missing']}, extra {pins['extra']}"})
        elif pins["status"] == "pin_mapping_mismatch":
            records.append({"code": "pin_mapping_mismatch", "ref": ref, "field": "pins",
                            "before": {d["pin"]: d["actual"] for d in pins["diffs"]},
                            "after": {d["pin"]: d["expected"] for d in pins["diffs"]},
                            "diffs": pins["diffs"]})
    return records, conflicts, unresolved


def build_discrepancy_plan(records, conflicts, unresolved):
    """Plan of edits (correctable records only); 'complete' is False if anything blocks editing."""
    actions = [r for r in records if r["code"] in CORRECTION_CODES]
    return {"actions": actions, "notes": [r for r in records if r["code"] not in CORRECTION_CODES],
            "complete": not conflicts and not unresolved}


def apply_plan(netlist_raw, plan):
    """Return a copy of the netlist with only planned fields changed; refuse incomplete plans."""
    if not plan["complete"]:
        raise InputError("refusing to edit: discrepancy plan is incomplete or unresolved")
    fixed = copy.deepcopy(netlist_raw)
    by_ref = {c["ref"]: c for c in fixed["components"]}
    for action in plan["actions"]:
        comp = by_ref[action["ref"]]
        if action["field"] == "value":
            comp["value"] = action["after"]
        else:
            for pin, net in action["after"].items():
                key = pin if pin in comp["pins"] else next(k for k in comp["pins"] if str(k) == pin)
                comp["pins"][key] = net
    return fixed


def render_finding(record):
    """Turn a comparison record into a report finding with field-linked before/after evidence."""
    ref, code = record["ref"], record["code"]
    if code == "value_mismatch":
        n = record.get("normalized") or {}
        return {"code": code, "ref": ref,
                "evidence": (f"derived/netlist.json:components[ref={ref}].value was '{record['before']}' "
                             f"({n.get('netlist', 'literal')}); source/bom.csv row {ref} value '{record['bom']}' and "
                             f"source/schematic.json:components[ref={ref}].value '{record['schematic']}' "
                             f"({n.get('bom', 'literal')}). After: '{record['after']}'."),
                "explanation": "BOM (authoritative for value) and schematic agree; the export differed after "
                               "normalization and was corrected to the BOM value."}
    if code == "pin_mapping_mismatch":
        before = ", ".join(f"pin {k}={v}" for k, v in record["before"].items())
        after = ", ".join(f"pin {k}={v}" for k, v in record["after"].items())
        return {"code": code, "ref": ref,
                "evidence": (f"derived/netlist.json:components[ref={ref}].pins had {before}; "
                             f"source/schematic.json:components[ref={ref}].pins has {after}. After: {after}."),
                "explanation": "Schematic is authoritative for pin-to-net mapping; differing pins were corrected by pin number."}
    n = record.get("normalized") or {}
    return {"code": "equivalent_notation", "ref": ref,
            "evidence": (f"derived/netlist.json:components[ref={ref}].value '{record['before']}' = {n.get('netlist')} "
                         f"base units; source/bom.csv row {ref} '{record['bom']}' and "
                         f"source/schematic.json:components[ref={ref}].value '{record['schematic']}' = {n.get('bom')}."),
            "explanation": "Physically equivalent after unit conversion; not an error, left unchanged."}


def build_report(lab, case, board_id, status, findings, changed_files, assumptions):
    """Assemble a contract-conformant report with stable key order and no timestamps."""
    for f in findings:
        if not f.get("code") or not f.get("evidence") or not f.get("explanation"):
            raise ValueError(f"finding {f.get('code')!r} lacks code/evidence/explanation")
    if any(p == "report.json" or p.startswith(("evidence/", "automation/")) or p.endswith(".md") for p in changed_files):
        raise ValueError("changed_files may list only derived artifacts")
    if not assumptions:
        raise ValueError("assumptions must be nonempty")
    return {"schema_version": 1, "lab": lab, "case": case, "board_id": board_id, "status": status,
            "findings": findings, "changed_files": changed_files, "assumptions": assumptions}


def dumps(doc):
    """Deterministic JSON text."""
    return json.dumps(doc, indent=2, ensure_ascii=False) + "\n"
