# HW1 automation

Standard library only (Python 3). Run from anywhere; paths resolve against `--workspace`.

## Files
- `guardrails.py` – entry point (inventory, provenance gate, comparison, correction, report).
- `board_checker.py` – reusable functions (`parse_quantity`, `compare_value`, `compare_pins`, `index_components`, `check_provenance`, `build_discrepancy_plan`, `apply_plan`, `build_report`).
- `tests/test_guardrails.py`, `tests/fixtures/` – checks using disposable workspaces under `automation/tests/_work/` (removed afterwards); real sources are never edited.

## Commands
```bash
# Assess/reconcile (from the workspace root; use the absolute path)
python automation/guardrails.py --workspace "$(pwd)"
# Checks: 100 nF vs 0.1 uF, wrong resistor, wrong pin map, reordered refs,
# missing source revision, missing component, unknown unit, authority conflict, idempotence
python -m unittest discover -s automation/tests -v
```

## Exit codes
`0` pass, `1` fail (complete assessment, discrepancy not correctable, e.g. missing component), `2` blocked (missing/invalid authority; netlist untouched, `changed_files: []`).

## Outputs
- `report.json`, `derived/netlist.json` (edited only after a complete plan and a before-record exist).
- `evidence/stage4_before_record.json` – original netlist/findings and source fingerprint (cumulative audit). If sources change, it is archived as `stage4_before_record.<fingerprint>.json` and a new audit starts.
- `evidence/stage4_check_result.json` – stable machine-readable result (hashes, findings, residuals).
- `evidence/stage4_guardrails_log.jsonl` – append-only expected/observed log per run.
- Stage 1–3 evidence is never overwritten.

## Notes
- Rerunning on reconciled data is idempotent; an equivalent existing report is not rewritten. A prior report is reused only after validation against current sources (`adopted_prior_report` mode records that the original netlist bytes were not captured by code).
- Units: Ohm, kOhm, nF, uF, F only; others are rejected (blocked). Relative tolerance 1e-9.
