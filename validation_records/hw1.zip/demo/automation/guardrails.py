#!/usr/bin/env python3
"""HW1 guardrails entry point: reconcile a derived netlist against approved sources.

Usage: python automation/guardrails.py --workspace /absolute/path/to/workspace

Exit codes: 0 pass, 1 fail (complete assessment, criteria not met), 2 blocked
(missing/invalid authority or input). Only report.json, evidence/ and
derived/netlist.json are ever written; sources are never modified.
"""
import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import board_checker as bc  # noqa: E402

EXIT = {"pass": 0, "fail": 1, "blocked": 2}
# Fixture bookkeeping only: sets the report's "case"; never selects engineering results.
CASE_BY_BOARD = {"SENSE-ALPHA": "demo", "SENSE-BETA": "transfer"}
PATHS = {"approval": "source/approval.json", "bom": "source/bom.csv",
         "schematic": "source/schematic.json", "netlist": "derived/netlist.json"}
SOURCE_ROLES = ("approval", "bom", "schematic")
REPORT = "report.json"
NETLIST = "derived/netlist.json"
BEFORE_RECORD = "evidence/stage4_before_record.json"
RESULT_EVIDENCE = "evidence/stage4_check_result.json"
RUN_LOG = "evidence/stage4_guardrails_log.jsonl"
CODE_ORDER = {"value_mismatch": 0, "pin_mapping_mismatch": 1, "equivalent_notation": 2}
KNOWN_PRIOR_CODES = set(CODE_ORDER)


def read_text_if_exists(path):
    return path.read_text(encoding="utf-8") if path.is_file() else None


def write_if_changed(path, text):
    """Write only when bytes differ, keeping stable artifacts byte-identical on reruns."""
    if path.is_file() and path.read_text(encoding="utf-8") == text:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return True


class RunLog:
    """Append-only expected/observed log; entries carry no timestamps or absolute paths."""

    def __init__(self, root):
        self.root, self.entries = root, []

    def step(self, name, expected, observed, ok):
        entry = {"step": name, "expected": expected, "observed": observed, "ok": ok}
        self.entries.append(entry)
        print(f"[{'ok' if ok else 'ATTENTION'}] {name}: expected {expected}; observed {observed}")

    def flush(self, status):
        try:
            path = self.root / RUN_LOG
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "a", encoding="utf-8") as handle:
                handle.write(json.dumps({"run": self.entries, "status": status}, sort_keys=True) + "\n")
        except OSError as exc:
            print(f"[ATTENTION] could not append run log: {exc}", file=sys.stderr)


def source_fingerprint(inventory):
    """Digest over the source files' content hashes (approval, BOM, schematic)."""
    parts = [f"{role}:{inventory[role]['sha256']}" for role in SOURCE_ROLES]
    return bc.sha256_bytes("\n".join(parts).encode("utf-8"))


def assumptions_for(board, revision):
    return [
        f"source/approval.json declares {board} revision {revision}; bom.csv and schematic.json each independently declare the same board and revision.",
        "BOM is authoritative for identity, kind and value; schematic is authoritative for pins and corroborates values.",
        "Components matched by reference designator and pins by pin number; IC identifiers compared as literal strings.",
        "derived/netlist.json is an output under review, not an authority.",
    ]


def finish(root, log, status, report, inventory, details):
    """Persist report (if any), machine-readable evidence and the log; return the exit code."""
    if report is not None:
        prior = read_text_if_exists(root / REPORT)
        try:
            same = prior is not None and json.loads(prior) == report
        except ValueError:
            same = False
        if same:
            log.step("report", "stable report preserved when content unchanged", "existing report.json equivalent; not rewritten", True)
        else:
            write_if_changed(root / REPORT, bc.dumps(report))
            log.step("report", "report.json written", f"status={status}, findings={len(report['findings'])}", True)
    evidence = {"status": status, "exit_code": EXIT[status], "inventory": inventory, **details}
    write_if_changed(root / RESULT_EVIDENCE, bc.dumps(evidence))
    log.flush(status)
    return EXIT[status]


def blocked_report(lab, case, board, revision, findings):
    """Report for a blocked assessment: no changed files, authority needed named per finding."""
    rendered = []
    for f in findings:
        if f["code"] == "missing_source_revision":
            expl = (f"{f['source']} does not independently declare the approved revision {revision}; the approval's "
                    f"expected revision is not evidence. An explicitly revisioned approved copy of {f['source']} "
                    "is required from the design authority. No recovery evidence was invented and the netlist was not modified.")
        else:
            expl = ("Assessment is blocked and derived/netlist.json was not modified; the design authority must "
                    "supply or resolve the authoritative evidence named in this finding.")
        rendered.append({"code": f["code"], "evidence": f["detail"], "explanation": expl,
                         **({"ref": f["ref"]} if "ref" in f else {})})
    assumptions = [
        f"source/approval.json declares expected board {board} and revision {revision}; the approval is not evidence for a source's own revision.",
        "BOM is authoritative for identity, kind and value; schematic is authoritative for pins and corroborates values.",
        "derived/netlist.json is an output under review, not an authority; it was left byte-for-byte unchanged.",
    ]
    return bc.build_report(lab, case, board, "blocked", rendered, [], assumptions)


def valid_prior_findings(prior_text, board, bom_idx):
    """Return prior report findings only if they are well-formed and match current identity."""
    try:
        prior = json.loads(prior_text)
        ok = (prior["lab"] == "hw1" and prior["board_id"] == board and prior["status"] == "pass"
              and isinstance(prior["findings"], list))
        findings = prior["findings"]
        for f in findings:
            ok = ok and f["code"] in KNOWN_PRIOR_CODES and f["ref"] in bom_idx and f["evidence"] and f["explanation"]
        return findings if ok else None
    except (ValueError, KeyError, TypeError):
        return None


def run(root, log):
    inventory = bc.inventory_sources(root, PATHS)
    missing = [r["path"] for r in inventory.values() if not r["exists"] or r["sha256"] is None]
    log.step("inventory", "approval, bom, schematic and netlist readable", f"missing/unreadable: {missing or 'none'}", not missing)
    approval = None
    try:
        lab = bc.detect_lab(root)
        approval = bc.load_approval(root / PATHS["approval"])
    except bc.InputError as exc:
        log.step("approval", "valid approval and unambiguous HW1 workspace", str(exc), False)
        return finish(root, log, "blocked", None, inventory, {"reason": str(exc)})
    board, revision = approval["board_id"], approval["revision"]
    case = CASE_BY_BOARD.get(board, "transfer")
    if missing:
        rep = blocked_report(lab, case, board, revision, [{"code": "required_input_unavailable", "detail": "Required input unavailable: " + ", ".join(missing)}])
        return finish(root, log, "blocked", rep, inventory, {"reason": "missing inputs"})

    try:
        bom_rows = bc.load_bom(root / PATHS["bom"])
        schematic = bc.load_component_doc(root / PATHS["schematic"], "schematic")
        netlist = bc.load_component_doc(root / PATHS["netlist"], "netlist")
    except bc.InputError as exc:
        log.step("parse", "all sources parse", str(exc), False)
        rep = blocked_report(lab, case, board, revision, [{"code": "input_unparsable", "detail": str(exc)}])
        return finish(root, log, "blocked", rep, inventory, {"reason": str(exc)})

    declarations = {PATHS["bom"]: [(r["board_id"], r["source_revision"]) for r in bom_rows],
                    PATHS["schematic"]: [(schematic["board_id"], schematic["revision"])]}
    gate = bc.check_provenance(approval, declarations)
    log.step("provenance_gate", f"every approved source declares {board} {revision}",
             f"{len(gate)} provenance finding(s): {[g['detail'] for g in gate] or 'none'}", not gate)
    if gate:
        rep = blocked_report(lab, case, board, revision, gate)
        return finish(root, log, "blocked", rep, inventory, {"reason": "provenance", "provenance_findings": gate})

    try:
        bom_idx = bc.index_components([{**r} for r in bom_rows], "source/bom.csv")
        sch_idx = bc.index_components(schematic["components"], "source/schematic.json")
    except bc.InputError as exc:
        log.step("index_sources", "unique references in BOM and schematic", str(exc), False)
        rep = blocked_report(lab, case, board, revision, [{"code": "duplicate_reference", "detail": str(exc)}])
        return finish(root, log, "blocked", rep, inventory, {"reason": str(exc)})
    try:
        net_idx = bc.index_components(netlist["components"], "derived/netlist.json")
    except bc.InputError as exc:
        log.step("index_netlist", "unique references in netlist", str(exc), False)
        rep = bc.build_report(lab, case, board, "fail", [{"code": "duplicate_reference", "evidence": str(exc),
                              "explanation": "The export repeats a reference designator; this cannot be corrected without choosing between entries, so no edit was made."}],
                              [], assumptions_for(board, revision))
        return finish(root, log, "fail", rep, inventory, {"reason": str(exc)})

    try:
        records, conflicts, unresolved = bc.compare_package(bom_idx, sch_idx, net_idx)
    except bc.InputError as exc:
        log.step("compare", "supported kinds and units", str(exc), False)
        rep = blocked_report(lab, case, board, revision, [{"code": "unsupported_quantity", "detail": str(exc)}])
        return finish(root, log, "blocked", rep, inventory, {"reason": str(exc)})
    log.step("compare", "components matched by ref, pins by pin number",
             f"records={[(r['code'], r['ref']) for r in records]} conflicts={len(conflicts)} unresolved={len(unresolved)}", not conflicts and not unresolved)

    if conflicts:
        rep = blocked_report(lab, case, board, revision, [{"code": c["code"], "ref": c["ref"], "detail": c["detail"]} for c in conflicts])
        return finish(root, log, "blocked", rep, inventory, {"reason": "authority conflict", "conflicts": conflicts})
    if unresolved:
        findings = [{"code": u["code"], "ref": u["ref"], "evidence": u["detail"],
                     "explanation": "The export has a structural discrepancy that is not a simple field correction; no edit was made and the design authority must review it."}
                    for u in unresolved]
        rep = bc.build_report(lab, case, board, "fail", findings, [], assumptions_for(board, revision))
        return finish(root, log, "fail", rep, inventory, {"reason": "unresolved discrepancies", "unresolved": unresolved})

    fingerprint = source_fingerprint(inventory)
    history = load_history(root, fingerprint, log)
    current_findings = [bc.render_finding(r) for r in records]
    plan = bc.build_discrepancy_plan(records, conflicts, unresolved)
    netlist_changed_now = False
    if plan["actions"]:
        before_text = (root / PATHS["netlist"]).read_text(encoding="utf-8")
        if history is None:
            history = {"fingerprint": fingerprint, "mode": "captured", "netlist_before": netlist["raw"],
                       "netlist_before_sha256": inventory["netlist"]["sha256"], "findings": current_findings}
            write_if_changed(root / BEFORE_RECORD, bc.dumps(history))
            log.step("before_record", "original netlist values preserved before editing", f"wrote {BEFORE_RECORD}", True)
        fixed = bc.apply_plan(netlist["raw"], plan)
        (root / PATHS["netlist"]).write_text(bc.dumps(fixed), encoding="utf-8")
        netlist_changed_now = before_text != (root / PATHS["netlist"]).read_text(encoding="utf-8")
        log.step("apply_plan", "only planned fields edited",
                 f"{len(plan['actions'])} correction(s) applied: {[(a['code'], a['ref']) for a in plan['actions']]}", True)
        netlist = bc.load_component_doc(root / PATHS["netlist"], "netlist")
        net_idx = bc.index_components(netlist["components"], "derived/netlist.json")
        records, conflicts, unresolved = bc.compare_package(bom_idx, sch_idx, net_idx)

    residual = [r for r in records if r["code"] in bc.CORRECTION_CODES] + conflicts + unresolved
    after = bc.inventory_sources(root, {r: PATHS[r] for r in SOURCE_ROLES})
    sources_intact = all(after[r]["sha256"] == inventory[r]["sha256"] for r in SOURCE_ROLES)
    log.step("verify", "zero unresolved discrepancies and unchanged sources",
             f"residual={len(residual)}, sources_unchanged={sources_intact}", not residual and sources_intact)

    if history is None:
        prior_text = read_text_if_exists(root / REPORT)
        adopted = valid_prior_findings(prior_text, board, bom_idx) if prior_text else None
        if adopted is not None:
            history = {"fingerprint": fingerprint, "mode": "adopted_prior_report", "netlist_before": None,
                       "findings": adopted}
            write_if_changed(root / BEFORE_RECORD, bc.dumps(history))
            log.step("history", "prior report validated against current sources before reuse",
                     "adopted prior findings; original netlist bytes are not machine-reproducible (mode adopted_prior_report)", True)

    findings = list(history["findings"]) if history else []
    seen = {(f["code"], f.get("ref")) for f in findings}
    for f in sorted(current_findings, key=lambda f: (CODE_ORDER[f["code"]], f["ref"])):
        if (f["code"], f.get("ref")) not in seen:
            findings.append(f)
    changed = netlist_changed_now or any(f["code"] in bc.CORRECTION_CODES for f in findings)
    status = "pass" if not residual and sources_intact else "fail"
    report = bc.build_report(lab, case, board, status, findings, [NETLIST] if changed else [], assumptions_for(board, revision))
    details = {"source_fingerprint": fingerprint, "board_id": board, "revision": revision,
               "history_mode": history["mode"] if history else None, "residual_discrepancies": len(residual),
               "sources_unchanged": sources_intact, "netlist_sha256_after": bc.sha256_bytes((root / PATHS["netlist"]).read_bytes()),
               "findings": [(f["code"], f.get("ref")) for f in findings]}
    return finish(root, log, status, report, inventory, details)


def load_history(root, fingerprint, log):
    """Load the before-record for these exact sources; archive it separately if sources changed."""
    path = root / BEFORE_RECORD
    if not path.is_file():
        return None
    try:
        record = json.loads(path.read_text(encoding="utf-8"))
    except ValueError:
        record = None
    if isinstance(record, dict) and record.get("fingerprint") == fingerprint:
        return record
    old = (record or {}).get("fingerprint", "unreadable")[:12]
    archived = path.with_name(f"stage4_before_record.{old}.json")
    os.replace(path, archived)
    log.step("history", "before-record matches current sources", f"stale record archived as {archived.name}; new audit started", True)
    return None


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--workspace", required=True, help="absolute path of the prepared workspace")
    args = parser.parse_args(argv)
    try:
        root = bc.resolve_workspace(args.workspace)
    except bc.InputError as exc:
        print(f"[ATTENTION] blocked: {exc}", file=sys.stderr)
        return EXIT["blocked"]
    log = RunLog(root)
    try:
        code = run(root, log)
    except Exception as exc:  # unexpected defect: report loudly, never claim a pass
        print(f"[ATTENTION] internal error: {type(exc).__name__}: {exc}", file=sys.stderr)
        log.step("internal_error", "no exception", f"{type(exc).__name__}: {exc}", False)
        log.flush("blocked")
        return EXIT["blocked"]
    print(f"result exit code {code}")
    return code


if __name__ == "__main__":
    sys.exit(main())
