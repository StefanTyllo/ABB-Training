# Extraction map: HW1 board-package reconciliation (Stage 3)

Scope: review of `workflow.md` steps 1-10. No reusable automation is implemented here (stage 4). Dispositions: **D** = deterministic code, **M** = model judgment, **H** = human decision. Paths, board ID, revision and references are always read from data, never embedded.

Authority: `approval.json` = expected board/revision/source list; `bom.csv` = identity/kind/value; `schematic.json` = pins, corroborates values; `derived/netlist.json` = output under review.

## Step review

| # | Step | Purpose | Inputs | Operation | Expected output | Failure condition | Disposition |
|---|------|---------|--------|-----------|-----------------|-------------------|-------------|
| 1 | Read contracts, fix authority | Know rules and hierarchy | task-card, CI_CONTRACT, REPORT_CONTRACT, workflow | Read; state hierarchy | Authority statement | Contract missing/unreadable | M (reading); hierarchy rule itself is encoded as constants in D |
| 2a | Collect/enumerate sources (**collection**) | Prove all required inputs exist and are unambiguous | WORKSPACE, 3 source paths, NETLIST_PATH | Existence/readability check; infer lab from files | Inventory: path, role, size, sha256 | Missing, unreadable, ambiguous lab -> `blocked` | D |
| 2b | Parse sources (**parsing**) | Typed records from JSON/CSV | approval, schematic JSON; BOM CSV; netlist JSON | `json.load`, `csv.DictReader`; keep original text of each value | Records keyed by ref (BOM rows incl. per-row board/revision) | Unparsable, missing columns/keys, wrong types -> `blocked` | D |
| 2c | Snapshot before state (**reporting**) | Preserve original netlist values and hashes before edit | Parsed netlist, hashes | Write stable evidence file; hash sources+netlist | `evidence/` before-record | Hashing/write denied -> state it, do not claim capture | D (write); M (wording if capture unavailable) |
| 3 | Provenance gate (**validation**) | Every approved source independently names expected board+revision | approval, each source's own board/revision (every BOM row too) | Equality check per source; approved list vs actual files | Pass, or `missing_source_revision` naming source | Absent/blank/different board or revision, source not in approved list, approval lacks fields -> `blocked`, netlist untouched, `changed_files: []` | D (check). H: supplying explicitly revisioned approved source |
| 4 | Index and match components (**comparison**) | Compare by ref, not order | BOM, schematic, netlist records | Build ref index; detect duplicates; compare ref sets; compare kind to BOM | Per-ref matched triples | Duplicate/missing/extra ref; kind or identity mismatch | D to detect. Source-vs-source conflict -> H/M escalation |
| 5 | Normalize quantities (**calculation**) | Dimensionally comparable values | Value strings | Parse number+unit; kOhm=1e3, Ohm=1, nF=1e-9, uF=1e-6, F=1; relative tolerance compare; ICs literal | Normalized float+dimension | Unknown unit, bad number, dimension mismatch (ohm vs F), non-finite -> reject | D. M only for a future ambiguous native-drawing case |
| 5b | Compare pins (**comparison**) | Pin-to-net check by pin number | Schematic pins, netlist pins | Compare dicts keyed by pin number; sets then nets | List of pin differences | Differing pin set/count or net | D |
| 6 | Classify differences | Separate cosmetic from real | Compare results | Same normalized value + different text -> `equivalent_notation`; else `value_mismatch`; pin diff -> `pin_mapping_mismatch` | Findings with code, ref, field paths, before/after | Unclassifiable difference | D (rules). M for anything outside the three codes |
| 7 | Decide supportability | Correct only demonstrable export errors | Findings; BOM, schematic | Value fix needs BOM and schematic agreeing; pin fix needs schematic; conflict -> stop | Complete correction plan, each item citing source field | BOM vs schematic value conflict; no authoritative evidence | D (check agreement). M/H: resolving true conflicts |
| 8 | Apply edits | Fix offending fields only | Correction plan, netlist | Edit only planned fields; preserve order, other data, equivalent notation; refuse if plan incomplete | Corrected `derived/netlist.json` | Partial plan; write failure; any source edit | D (given complete plan) |
| 9 | Re-verify (**validation**) | Prove zero unresolved discrepancies and sources unchanged | Corrected netlist, sources, recorded hashes | Re-run steps 4-6; recompare source hashes | Zero real discrepancies; source hashes equal | Any remaining real discrepancy or hash change | D |
| 10 | Report (**reporting**) | Contract-conformant audit | Findings, before/after, hashes | Build report.json; status rule: reconciled -> `pass`, provenance/input/authority failure -> `blocked`; `changed_files` = derived artifacts changed; keep prior findings on rerun | `report.json` | Missing evidence/explanation, report/files in changed_files, stale report reused | D for structure/status. M for assumptions text. Reuse requires revalidation against current sources |
| 11 | Judge result | Is the source hierarchy fit and the outcome acceptable | Report, evidence | Review; request missing authority | Decision | Blocked case: no recovery evidence exists | H |

## Proposed function contracts (design only; implement in stage 4)

All functions are pure unless noted; errors are typed (`InputError` = blocked) and never silently guessed.

| Function | Input | Output | Errors / notes |
|---|---|---|---|
| `resolve_workspace(path: str) -> Path` | Workspace path | Absolute resolved root | Not a directory -> InputError. All other paths resolve against it |
| `detect_lab(root: Path) -> str` | Workspace root | `"hw1"` | Required files missing or both HW1/HW2 shapes present -> InputError |
| `inventory_sources(root, paths: dict[role->relpath]) -> dict` | Root, role->path map (approval, bom, schematic, netlist) | `{role: {path, exists, bytes, sha256}}` | Missing/unreadable -> entry flagged, caller blocks; hashing denied -> `sha256: null` plus reason |
| `load_approval(path) -> Approval` | Approval JSON path | `{board_id, revision, sources: [relpath]}` | Missing board/revision/sources, wrong types -> InputError |
| `load_bom(path) -> list[BomRow]` | CSV path | Rows `{board_id, revision, ref, kind, value}` (raw strings, blank preserved) | Missing columns or unparsable -> InputError. Blank revision is retained so the gate can see it |
| `load_schematic(path)` / `load_netlist(path)` -> `Doc` | JSON path | `{board_id, revision, components: list}` | Unparsable, components not a list -> InputError. Revision absent -> `None` (not defaulted) |
| `check_provenance(approval, docs: dict[path->Doc\|rows]) -> list[Finding]` | Approval; each approved source's declared board/revision (each BOM row separately) | Empty list, or `missing_source_revision` / identity findings naming source and what is needed | Never uses approval revision as fallback. Any finding => status `blocked`, no edit |
| `index_components(items: list, label: str) -> dict[ref->item]` | Component list, source label | Map by ref | Duplicate ref -> DuplicateRefError with label and ref |
| `compare_ref_sets(bom_idx, sch_idx, net_idx) -> dict` | Three indices | `{missing: [(ref, where)], extra: [(ref, where)]}` | Non-empty -> `component_set_mismatch` finding; no edits |
| `parse_quantity(text: str) -> Quantity` | e.g. `"4.7 kOhm"` | `{value: float (base units), dimension: "resistance"\|"capacitance", raw}` | Unknown unit, malformed or non-finite number -> UnitError (no guessing) |
| `quantities_equal(a, b, rel_tol=1e-9, abs_tol=0.0) -> bool` | Two Quantity | True if same dimension and within tolerance | Different dimension -> False; tolerance is an explicit argument |
| `compare_value(kind, bom_val, sch_val, net_val) -> ValueResult` | Raw value strings and kind | `{status: match\|equivalent_notation\|value_mismatch\|authority_conflict, normalized: {...}}` | IC kinds compared as literal strings. BOM vs schematic disagreement -> `authority_conflict` (escalate) |
| `compare_pins(sch_pins: dict, net_pins: dict) -> PinResult` | Pin number -> net maps | `{status: match\|pin_mapping_mismatch\|pin_set_mismatch, diffs: [{pin, expected, actual}]}` | Keys compared as strings, order ignored |
| `build_discrepancy_plan(matches) -> Plan` | Per-ref compare results | List of `{ref, field_path, before, after, authority_field, code}` plus equivalent-notation notes with no action | Any `authority_conflict` or set mismatch -> plan marked unresolved and edits refused |
| `apply_plan(netlist_doc, plan) -> new_doc` | Netlist doc, complete plan | Copy with only planned fields changed, order preserved | Incomplete/unresolved plan -> refuse. Caller writes file only after success |
| `verify_reconciled(netlist_doc, sources) -> list[Finding]` | Corrected netlist, sources | Empty list when clean | Residual discrepancy -> non-empty (status `fail`) |
| `build_report(lab, case, board_id, status, findings, changed_files, assumptions) -> dict` | Fields per REPORT_CONTRACT | JSON-serializable report, stable key order, no timestamps | Empty evidence/explanation or report/log in changed_files -> ValueError |
| `merge_prior_report(prior, current_source_fingerprint) -> dict\|None` | Existing report, current identity/revision/content hash | Prior findings+changed_files if still valid for the same sources, else None | Stale/mismatched report is discarded, never trusted blindly |
| `write_evidence(dir, before_record) -> None` | Evidence dir, stable before-record | Writes deterministic evidence (original values, hashes) | Failure reported honestly |
| `main(argv) -> int` | `--workspace` | Exit 0 pass, 1 fail, 2 blocked | Blocked leaves netlist byte-identical |

Design rule: `inventory/provenance` functions are separate from `compare/*`; comparison functions are not called if the gate fails.

## Retained as judgment

- **M:** read-through of contracts; wording of explanations and assumptions; classifying differences outside the three known codes; interpreting ambiguous drawings (future).
- **H:** supplying an explicitly revisioned approved source after a block; resolving genuine BOM-vs-schematic conflicts; confirming the source hierarchy suits a real project; accepting a blocked outcome.

## Untested branches (from workflow.md; need stage-4 fixtures)

Blocked/missing-revision with unchanged-netlist guarantee; BOM/schematic conflict; unknown units; duplicate or missing refs; differing pin sets; source hash immutability; idempotent rerun and stale-report reuse; float tolerance choice (proposed: relative 1e-9).
