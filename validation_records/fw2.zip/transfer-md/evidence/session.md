# Session record: FW2 transfer (Markdown-only), followed workflow.md

Workspace: `runs/fw2/transfer-md`; case.json = fw2/transfer. Spec = requirements.md. Example: `A5 02 2A 00 F8 75` -> sequence 42, value -2048 (from spec).
Instructor check: not run (not permitted/supplied). No protocol pass is claimed from own checks alone.
Note: several compound bash commands (sha256sum, tee, multi-command with cat) were refused by the environment; I split them into simpler ones. Pre-edit digests were therefore not captured with a tool; preservation was instead ensured by editing only `fw2/parser.c` (parser.h, main.c, requirements.md, case.json were only read; never edited).

## 1. Build (pre-repair)
`gcc -std=c11 -Wall -Wextra -Werror fw2/parser.c fw2/main.c -o fw2/parser` -> rc 0, no output. Compiling only proves syntax/type correctness, not protocol correctness.

## 2. Reproduction before editing (expected: `[{"sequence":42,"value":-2048}]`)
| Command | rc | stdout | Result |
| --- | --- | --- | --- |
| `./fw2/parser a502 2a00 f875` | 0 | `[]` | FAIL (split lost) |
| `./fw2/parser a5022a00f875` | 0 | `[{"sequence":42,"value":63488}]` | FAIL (sign) |
| `./fw2/parser a5022a 00f875` | 0 | `[]` | FAIL (split lost) |

## 3. Inspection of parser.c against spec
a. State lifetime: `parser_feed` began with `p->used = 0;` (comment "chunk boundary"), discarding the partial packet on every call. Contradicts "partial state survives chunk boundaries".
b. Conversion: `unsigned raw = low | high<<8; int value = raw;` widens an unsigned 16-bit quantity to int with no sign extension, so 0xF800 became 63488 rather than -2048.
c. Resync: header discard, length != 02 discarding only leading A5 once a second byte exists, wait for 6 bytes, checksum failure discarding only the first byte and rescanning, consume 6 on success: all match the contract. Left unchanged.

## 4. Repair (only fw2/parser.c)
- Removed the `p->used = 0;` line at the start of `parser_feed`.
- `uint16_t raw = (uint16_t)(low | high<<8); int value = (int16_t)raw;` (two's-complement reinterpretation: 0xF800 = 63488 - 65536 = -2048).

## 5. Rebuild and repeat
Build rc 0 under same flags. `./fw2/parser a502 2a00 f875` -> `[{"sequence":42,"value":-2048}]` rc 0; `./fw2/parser a5022a00f875` -> same.

## 6. Broadened checks (throwaway script /tmp/fw2_check.py, outside workspace; expected values built from fields with an independent XOR routine; each stream run whole, split at every byte boundary, and byte-by-byte)
All passed: spec example; positive 1234; minimum -32768; maximum 32767; -1 with seq 255; bad checksum -> `[]`; noise before frame; stray A5 01 before frame; A5 before a real frame; bad-checksum frame whose rescan reveals a following valid frame; A5 inside payload/sequence (seq 165, value -23131); two frames; incomplete tail still emits earlier frames; incomplete-only -> `[]`.
CLI: no args `[]`; empty chunks accepted; uppercase hex works; odd length (`abc`), non-hex (`zz`, `0g`) and 4097-byte chunk -> rc 2, stderr message, empty stdout; 4096-byte chunk accepted.
Result: 0 failures.

## 7. Explanation
- Compile success != correctness: the compiler cannot know the protocol; both defects were semantic and the build passed with -Werror before repair.
- Chunk boundaries are transport artifacts (arbitrary receive sizes); a stream decoder must give identical output however bytes are sliced, so partial packet state must persist across feed calls (one Parser per stream).
- Signed conversion: low/high form a 16-bit pattern; if bit 15 is set, value = pattern - 65536. Casting to int16_t performs that reinterpretation.

## Limits / not run
- Instructor smoke/50-case checker not run. Generated `fw2/parser` binary is an artifact, not evidence. No pre-edit digest file captured (see note). No automation created (Markdown-only transfer).
