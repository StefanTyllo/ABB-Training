# Workflow: reproduce, repair and verify a streaming packet parser

Reusable for any workspace prepared for this lab (any case). Derived from one observed session; incident values are inputs, not constants.

## Named inputs (validate before use)
| Input | Source / validation | If missing or invalid |
| --- | --- | --- |
| `WORKSPACE` | Absolute directory containing the files below; resolve every path from it, not from cwd | Stop; report |
| `SPEC` | `requirements.md` in `WORKSPACE`; the sole protocol authority | Stop; never infer the protocol from the code or its output |
| `CASE` | `case.json` (`lab`, `case`); must be `fw2` | Stop on other labs |
| `SRC_DIR`, `SOURCE` | `SRC_DIR/parser.c`: the only file to edit | Stop |
| `PRESERVED` | `parser.h`, `main.c`, `SPEC`, `case.json`; record their digests before work and compare at the end | Edit none of them; if a change looks necessary, report it as a blocker |
| `COMPILER_CMD` | Default `gcc -std=c11 -Wall -Wextra -Werror <SOURCE> <main.c> -o <EXE>`; the compiler must exist | Report a blocked build; do not substitute another toolchain silently |
| `EXE` | Generated binary path, treated as untrusted output | Derive from `SRC_DIR`; delete or ignore a stale one on build failure |
| `EXAMPLE` | The packet example for `CASE` read from `SPEC` (sequence, value, bytes) | Stop reproduction; do not copy values from an earlier case |
| `CHUNK_SCHEDULE` | Lists of even-length hex chunk strings (each chunk = one CLI argument) | Use at least: whole packet, split in two at every byte boundary of `EXAMPLE` |
| `EVIDENCE_DIR` | Destination for the session record (default `evidence/`) | Create it; never overwrite earlier evidence, append or use a new file |
| `INSTRUCTOR_CHECK` | External checker, only if explicitly permitted and its path supplied | Do not search for or read it; record "not run" |

## Specification invariants (take values from `SPEC`; do not weaken)
- Packet is six bytes: header, length byte, sequence, value low, value high, checksum. Sequence is unsigned 8-bit. The value is signed 16-bit two's-complement, little-endian. The checksum is the XOR of the first five bytes.
- One parser state per stream; every feed call continues that stream. Chunk boundaries (including empty chunks) must not change the decoded result. A fresh process is a fresh stream. There is no timeout behavior.
- Resynchronization exactly as in `SPEC`: discard to the header byte; a wrong length discards only the leading header byte; a checksum failure discards only the first byte and rescans the rest, keeping a possible partial candidate; success emits once and consumes six bytes; header bytes inside a valid frame are data; an incomplete tail emits nothing.
- CLI contract from `SPEC`: malformed, odd-length or over-limit chunks exit nonzero with stderr and no stdout; no arguments give `[]`; success prints a JSON array of `{sequence, value}`.
- Expected values always come from `SPEC` and hand computation, never from the program under test.

## Steps
1. **Validate inputs.** Confirm every item above; record source digests. Read `SPEC` fully before touching code.
2. **Build** with `COMPILER_CMD`; capture the command, exit status, stdout and stderr. A build failure is its own result (not a decode failure): stop and never run an older `EXE`. A passing build shows only that the code compiles, not that the protocol is right.
3. **Reproduce before editing.** Run `EXAMPLE` as the whole stream and over each `CHUNK_SCHEDULE` split. Save the command, arguments, rc, stdout and stderr, and the expected object from `SPEC`. Unexpected failures stay recorded as failures.
4. **Inspect** the source against `SPEC`, one question at a time:
   a. Is partial-packet state kept across feed calls (lifetime and any reset at the start of a call; any per-call locals)?
   b. How are the value bytes combined and widened (width, signedness, conversion to the output type)?
   c. Does the resynchronization logic match the contract (discard counts, rescan, partial candidate preserved)?
   Explain each finding against `SPEC`. Change only what contradicts it.
5. **Repair minimally** in `SOURCE` only. Do not add result-specific special cases or hard-coded responses.
6. **Rebuild** (step 2) and repeat the step 3 reproductions. Rebuild after every source change.
7. **Broaden checks** so a narrow repair cannot pass. Build each stream from fields, compute the checksum by hand or by an independent routine, and run each both whole and split at every boundary:
   - positive value; negative value; minimum -32768 and maximum 32767;
   - bad checksum gives nothing;
   - valid frame after noise, including a stray header byte before it;
   - incomplete tail gives nothing, while earlier complete frames still emit;
   - no arguments, an empty chunk, and uppercase and lowercase hex;
   - odd length and non-hex input give nonzero rc, stderr, empty stdout.
8. **Verify preservation:** `PRESERVED` digests unchanged; only `SOURCE` differs; the generated `EXE` is not claimed as evidence.
9. **Record** in `EVIDENCE_DIR`: each command with its reason, rc and outputs; expected vs actual per check; edited lines; explanation (why compiling is not correctness, why chunk boundaries must not matter, the two's-complement conversion); limits and what was not run.

## Missing-input and blocked behavior
- Missing or invalid input: follow the table; report a blocked result rather than guessing or fabricating evidence.
- Compiler unavailable or build fails: report blocked or failed with the captured output; keep it visible.
- `INSTRUCTOR_CHECK` not provided or not permitted: state it was not run. Never claim a protocol pass from own checks alone.
- Environment refuses a command: split it into simpler commands and note it.
- Expected-failure results (the pre-repair reproductions) are evidence; keep them.

## Diagnosis hints
- Whole passes but split fails: partial state is lost across calls.
- Magnitude wrong or positive for a negative value: width or signedness of the conversion.
- Extra or missing frames after noise or bad checksum: compare with the resync contract.
- A fix works for the example only: the broadened checks in step 7 should fail it.

## Completion criteria
- Build exits 0 under the stated flags; every reproduction and broadened check matches `SPEC`-derived expectations.
- `PRESERVED` files unchanged; the explanation is recorded; limits are stated.

## Untested branches (not exercised in the observed session)
- Build-failure path and stale-executable protection.
- Another case (the transfer case) and a candidate whose defects differ from those observed.
- Resynchronization edge cases: wrong length byte after a header, a checksum failure that hides a partial candidate, a header byte inside a valid payload.
- Empty chunks, uppercase hex, and the maximum chunk size (reject an oversized chunk).
- Independent instructor/protocol checker and the facilitator rubric.
- Independent instructor checker (still not run by automation).

## Automated helpers (stage 4)
Deterministic steps 1, 2, 3, 6 (re-verify), 7, 8 and 9 (records) are implemented in `automation/` (see `automation/README.md`). Reasoning steps (diagnosis, repair, explanation) stay with the agent; the helpers never contain or apply a repair.

After each edit to `SOURCE`, run:
```bash
python3 automation/guardrails.py --workspace /absolute/path/to/workspace
```
It validates inputs, rebuilds (deleting any stale `EXE` first), replays the `SPEC`-derived example, positive/negative/min/max values, bad checksum, noise and resync cases, incomplete tail and malformed CLI input, each whole and split at every boundary, then checks that preserved files are unchanged and writes `evidence/fw2-verification.json`.

Reading the result:
- Exit 0: build and every check match the `SPEC`-derived expectations. This is not an instructor protocol pass; that remains "not run".
- Exit 2 (`build_failed`): a compile error. Nothing was replayed; fix the compiler output first. This is distinct from a decode failure.
- Exit 1: a check failed. The log line `FAIL <case> cuts=... expected=... observed=...` is the reproduction. If the whole stream passes but splits fail, partial state is lost; if negative or min values fail, inspect the signed conversion; extra or missing frames after noise point at resynchronization.
- Exit 3: blocked (missing input, other lab, no compiler, no example for the case). Report it; do not guess.

Self-check of the automation: `python3 -m unittest discover -s automation/tests -v` runs it against altered defect fixtures (lost state, unsigned conversion, compile error), the valid parser, and failure branches.

In a transfer workspace the original defects are present: run the script before editing to capture expected failures (exit 1, kept as evidence in `evidence/`; copy `fw2-verification.json` to a new name first, since it is regenerated each run), then repair `parser.c` and rerun until exit 0.
