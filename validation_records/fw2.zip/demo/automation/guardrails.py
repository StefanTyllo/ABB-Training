#!/usr/bin/env python3
"""Common FW2 guardrails entry point.

Usage: python3 automation/guardrails.py --workspace /absolute/path/to/workspace

Builds the candidate parser, replays the requirement-linked checks, writes
machine-readable evidence under <workspace>/evidence and exits 0 only when the
build and every check pass.  It never edits parser.c and is safe to repeat.
Exit codes: 0 pass, 1 check failed, 2 build failed, 3 blocked/error.
"""

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fw2_tools as tools  # noqa: E402

EXIT_CODES = {"pass": 0, "fail": 1, "build_failed": 2, "blocked": 3, "error": 3}
PRESERVED_BASELINE = "fw2-preserved-baseline.json"
VERIFICATION_EVIDENCE = "fw2-verification.json"


def check_preservation(workspace):
    """Record digests of preserved files once, then compare on every later run.

    The baseline is written only if absent and never overwritten, so repeat runs
    detect later edits to parser.h, main.c, requirements.md or case.json.
    """
    ws = tools.load_workspace(workspace)
    paths = ws["paths"]
    names = ("parser_h", "main_c", "spec", "case_json")
    current = {name: tools.sha256_file(paths[name]) for name in names}
    baseline_path = os.path.join(paths["evidence"], PRESERVED_BASELINE)
    if not os.path.exists(baseline_path):
        tools.write_evidence(paths["evidence"], PRESERVED_BASELINE, {"digests": current})
        tools.log("ACTION preservation: first run, recorded baseline digests")
        return {"status": "pass", "unchanged": True, "changed": [], "baseline_created": True,
                "id": "preserved_files", "requirement": "R-PRESERVE"}
    with open(baseline_path, encoding="utf-8") as handle:
        baseline = json.load(handle)["digests"]
    result = tools.verify_preserved(baseline, current)
    result.update(id="preserved_files", requirement="R-PRESERVE", baseline_created=False)
    tools.log("RESULT preservation: %s changed=%s" % (result["status"], result["changed"]))
    return result


def main(argv=None):
    """Run the verification and return the process exit code."""
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--workspace", required=True, help="absolute workspace path")
    args = parser.parse_args(argv)
    workspace = os.path.abspath(args.workspace)

    summary = tools.verify_workspace(workspace)
    if summary["build"].get("status") == "pass":
        preserved = check_preservation(workspace)
        summary["checks"].append(preserved)
        if preserved["status"] != "pass" and summary["status"] == "pass":
            summary["status"] = "fail"
    summary["instructor_check"] = "not run"
    print(tools.render_report(summary), flush=True)

    evidence_dir = os.path.join(workspace, "evidence")
    if os.path.isdir(workspace):
        path = tools.write_evidence(evidence_dir, VERIFICATION_EVIDENCE, summary, overwrite=True)
        tools.log("evidence written: %s" % path)
    return EXIT_CODES.get(summary["status"], 3)


if __name__ == "__main__":
    sys.exit(main())
