"""Deterministic build / packet / replay / compare helpers for the FW2 stream parser.

These helpers only VERIFY a candidate parser.  They contain no parser
implementation: expected results come from a spec-driven oracle that is built
from packet fields, never from the executable under test.

Every function returns a JSON-serializable record instead of raising for an
expected engineering outcome, so failed or blocked results stay visible.
Record ``status`` is one of: pass, fail, build_failed, blocked, error.
"""

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

# Specification invariants (requirements.md, FW2): protocol facts, not parameters.
HEADER = 0xA5
LENGTH_BYTE = 0x02
PACKET_SIZE = 6
MAX_CHUNK_BYTES = 4096
VALUE_MIN, VALUE_MAX = -32768, 32767

DEFAULT_COMPILER = [
    "gcc", "-std=c11", "-Wall", "-Wextra", "-Werror",
    "{source}", "{main}", "-o", "{exe}",
]


def utc_now():
    """Return an ISO-8601 UTC timestamp."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def log(message):
    """Print an action/result line (flushed so CI logs stay ordered)."""
    print(message, flush=True)


# --------------------------------------------------------------------------
# Workspace and digests
# --------------------------------------------------------------------------
def sha256_file(path):
    """Return the SHA-256 hex digest of a file, or None if it is missing."""
    try:
        with open(path, "rb") as handle:
            return hashlib.sha256(handle.read()).hexdigest()
    except OSError:
        return None


def snapshot_files(paths):
    """Map each path to its digest (None when missing)."""
    return {path: sha256_file(path) for path in paths}


def load_workspace(workspace):
    """Validate the workspace and resolve every path from it.

    Returns a record with status ``pass`` or ``blocked`` (with ``reason``).
    """
    workspace = os.path.abspath(workspace)
    paths = {
        "parser_c": os.path.join(workspace, "fw2", "parser.c"),
        "parser_h": os.path.join(workspace, "fw2", "parser.h"),
        "main_c": os.path.join(workspace, "fw2", "main.c"),
        "spec": os.path.join(workspace, "requirements.md"),
        "case_json": os.path.join(workspace, "case.json"),
        "exe": os.path.join(workspace, "fw2", "parser"),
        "evidence": os.path.join(workspace, "evidence"),
    }
    record = {"status": "pass", "workspace": workspace, "paths": paths,
              "lab": None, "case": None}
    missing = [name for name in ("parser_c", "parser_h", "main_c", "spec", "case_json")
               if not os.path.isfile(paths[name])]
    if missing:
        record.update(status="blocked", reason="missing input files: " + ", ".join(missing))
        return record
    try:
        with open(paths["case_json"], encoding="utf-8") as handle:
            case = json.load(handle)
        record["lab"], record["case"] = case["lab"], case["case"]
    except (OSError, ValueError, KeyError, TypeError) as exc:
        record.update(status="blocked", reason="case.json unreadable: %s" % exc)
        return record
    if record["lab"] != "fw2":
        record.update(status="blocked", reason="case.json lab is %r, expected 'fw2'" % record["lab"])
    return record


def read_example(spec_text, case):
    """Extract this case's example packet from the specification text.

    Looks for ``<Case> `A5 02 .. ..` means sequence N, value V``.  A missing
    example is ``blocked``; values from another case are never reused.
    """
    pattern = re.compile(
        r"%s\s+`([0-9A-Fa-f ]+)`\s+means\s+sequence\s+(\d+),\s*value\s+(-?\d+)" % re.escape(case),
        re.IGNORECASE)
    match = pattern.search(spec_text)
    if not match:
        return {"status": "blocked", "reason": "no example for case %r in requirements.md" % case}
    return {"status": "pass", "bytes_hex": match.group(1).replace(" ", "").upper(),
            "sequence": int(match.group(2)), "value": int(match.group(3))}


# --------------------------------------------------------------------------
# Build
# --------------------------------------------------------------------------
def source_digest(src_dir):
    """Digest of the three build inputs, plus a combined digest."""
    files = {name: sha256_file(os.path.join(src_dir, name))
             for name in ("parser.c", "parser.h", "main.c")}
    combined = hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()
    return {"files": files, "combined": combined}


def build_candidate(src_dir, exe_path, compiler_cmd=None):
    """Compile the candidate; a stale executable is removed BEFORE compiling.

    A compile failure (``build_failed``) or missing compiler (``blocked``)
    leaves no executable, so an older binary can never be replayed.
    """
    template = compiler_cmd or DEFAULT_COMPILER
    command = [part.format(source=os.path.join(src_dir, "parser.c"),
                           main=os.path.join(src_dir, "main.c"),
                           exe=exe_path) for part in template]
    record = {"status": "pass", "command": command, "rc": None, "stdout": "", "stderr": "",
              "source": source_digest(src_dir), "exe": exe_path,
              "exe_exists": False, "started": utc_now(), "finished": None}
    if os.path.lexists(exe_path):
        os.remove(exe_path)  # stale binary must never survive a failed build
    try:
        done = subprocess.run(command, capture_output=True, text=True, timeout=120, check=False)
        record.update(rc=done.returncode, stdout=done.stdout, stderr=done.stderr)
        if done.returncode != 0:
            record["status"] = "build_failed"
            if os.path.lexists(exe_path):
                os.remove(exe_path)  # a partial output is not trustworthy either
    except FileNotFoundError as exc:
        record.update(status="blocked", stderr="compiler not found: %s" % exc)
    except subprocess.TimeoutExpired:
        record.update(status="error", stderr="compiler timed out")
    record["exe_exists"] = os.path.isfile(exe_path)
    if record["status"] == "pass" and not record["exe_exists"]:
        record["status"] = "error"
        record["stderr"] += "compiler returned 0 but produced no executable"
    record["finished"] = utc_now()
    return record


# --------------------------------------------------------------------------
# Packet construction and splitting
# --------------------------------------------------------------------------
def checksum(first_five):
    """XOR of the first five packet bytes."""
    if len(first_five) != 5:
        raise ValueError("checksum needs exactly 5 bytes, got %d" % len(first_five))
    result = 0
    for byte in first_five:
        result ^= byte
    return result


def build_packet(sequence, value, bad_checksum=False):
    """Pack ``A5 02 seq lo hi chk`` from fields; optionally corrupt the checksum."""
    if not 0 <= sequence <= 255:
        raise ValueError("sequence %r outside 0..255" % sequence)
    if not VALUE_MIN <= value <= VALUE_MAX:
        raise ValueError("value %r outside signed 16-bit range" % value)
    raw = value & 0xFFFF  # two's-complement, little-endian
    body = bytes([HEADER, LENGTH_BYTE, sequence, raw & 0xFF, raw >> 8])
    check = checksum(body)
    if bad_checksum:
        check ^= 0x01
    return body + bytes([check])


def split_stream(data, cuts):
    """Slice ``data`` at sorted offsets into hex chunks; empty chunks are kept."""
    if list(cuts) != sorted(cuts) or any(c < 0 or c > len(data) for c in cuts):
        raise ValueError("cuts %r must be sorted and within 0..%d" % (list(cuts), len(data)))
    edges = [0] + list(cuts) + [len(data)]
    chunks = [data[a:b] for a, b in zip(edges, edges[1:])]
    if any(len(chunk) > MAX_CHUNK_BYTES for chunk in chunks):
        raise ValueError("chunk exceeds %d bytes" % MAX_CHUNK_BYTES)
    return [chunk.hex().upper() for chunk in chunks]


def all_splits(data, mode):
    """Deterministic cut schedules: whole, every 2-way split, or single-byte."""
    if mode == "whole":
        return [[]]
    if mode == "two_way":
        return [[i] for i in range(0, len(data) + 1)]  # includes empty first/last chunk
    if mode == "single_byte":
        return [list(range(1, len(data)))]
    raise ValueError("unknown split mode %r" % mode)


# --------------------------------------------------------------------------
# Spec oracle (never derived from the executable)
# --------------------------------------------------------------------------
def expected_frames(model):
    """Compute stream bytes and expected output from a stream model.

    Segments: ("frame", seq, value) emits; ("bad", seq, value) is a frame with a
    wrong checksum and emits nothing; ("noise", bytes) emits nothing; ("tail",
    bytes) is an incomplete packet prefix at end of stream and emits nothing.
    Noise must not contain A5 (interacting resync cases are hand-derived in
    build_case_matrix instead).  Returns ``(stream_bytes, expected_list)``.
    """
    stream, expected = b"", []
    for segment in model:
        kind = segment[0]
        if kind == "frame":
            stream += build_packet(segment[1], segment[2])
            expected.append({"sequence": segment[1], "value": segment[2]})
        elif kind == "bad":
            stream += build_packet(segment[1], segment[2], bad_checksum=True)
        elif kind == "noise":
            if HEADER in segment[1]:
                raise ValueError("noise must not contain A5; use a hand-derived case")
            stream += bytes(segment[1])
        elif kind == "tail":
            if len(segment[1]) >= PACKET_SIZE:
                raise ValueError("tail must be shorter than a packet")
            stream += bytes(segment[1])
        else:
            raise ValueError("unknown segment kind %r" % kind)
    return stream, expected


# --------------------------------------------------------------------------
# Replay and compare
# --------------------------------------------------------------------------
def replay_stream(exe, chunks, build=None, timeout_s=10):
    """Run the executable once with one chunk per argument (no shell).

    Refuses to run unless ``build`` (when given) has status ``pass`` and the
    executable exists, so a stale binary cannot produce evidence.
    """
    command = [exe] + list(chunks)
    record = {"status": "pass", "command": command, "chunks": list(chunks), "rc": None,
              "stdout": "", "stderr": "", "actual": None, "parse_error": None}
    if build is not None and build.get("status") != "pass":
        record.update(status="blocked", stderr="build status is %r; replay refused" % build.get("status"))
        return record
    if not os.path.isfile(exe):
        record.update(status="blocked", stderr="executable missing: %s" % exe)
        return record
    try:
        done = subprocess.run(command, capture_output=True, text=True, timeout=timeout_s, check=False)
    except subprocess.TimeoutExpired:
        record.update(status="error", stderr="replay timed out after %ss" % timeout_s)
        return record
    except OSError as exc:
        record.update(status="error", stderr="cannot execute: %s" % exc)
        return record
    record.update(rc=done.returncode, stdout=done.stdout, stderr=done.stderr)
    try:
        record["actual"] = json.loads(done.stdout)
    except ValueError as exc:
        record["parse_error"] = str(exc)
    return record


def compare_results(expected, actual):
    """Exact ordered comparison of ``{sequence, value}`` object lists with int types."""
    record = {"equal": False, "expected": expected, "actual": actual, "first_diff": None}
    if not isinstance(actual, list):
        record["first_diff"] = "actual is not a JSON array"
        return record
    for index in range(max(len(expected), len(actual))):
        want = expected[index] if index < len(expected) else None
        got = actual[index] if index < len(actual) else None
        valid = (isinstance(got, dict) and set(got) == {"sequence", "value"}
                 and all(type(v) is int for v in got.values()))
        if want != got or not valid:
            record["first_diff"] = {"index": index, "expected": want, "actual": got}
            return record
    record["equal"] = True
    return record


def check_rejects_malformed(exe, chunks, build=None):
    """Malformed CLI input must give rc != 0, stderr text and empty stdout."""
    replay = replay_stream(exe, chunks, build)
    record = {"status": "fail", "replay": replay}
    if replay["status"] != "pass":
        record["status"] = replay["status"]
        return record
    record["rc_nonzero"] = replay["rc"] != 0
    record["stderr_nonempty"] = bool(replay["stderr"].strip())
    record["stdout_empty"] = replay["stdout"] == ""
    if record["rc_nonzero"] and record["stderr_nonempty"] and record["stdout_empty"]:
        record["status"] = "pass"
    return record


def run_case(case_def, exe, build=None):
    """Replay a case on each of its schedules and compare to the oracle output.

    ``case_def``: ``{id, requirement, stream (bytes), expected, schedules}`` where a
    schedule is a list of cut offsets.  The case fails if any schedule fails.
    """
    runs = []
    status = "pass"
    for cuts in case_def["schedules"]:
        chunks = split_stream(case_def["stream"], cuts)
        replay = replay_stream(exe, chunks, build)
        if replay["status"] != "pass":
            verdict, run_status = None, replay["status"]
        else:
            verdict = compare_results(case_def["expected"], replay["actual"])
            run_status = "pass" if verdict["equal"] and replay["rc"] == 0 else "fail"
        if run_status != "pass" and status == "pass":
            status = run_status
        runs.append({"cuts": cuts, "replay": replay, "comparison": verdict, "status": run_status})
        if run_status != "pass":
            log("  FAIL %s cuts=%s expected=%s observed=%s" % (
                case_def["id"], cuts, case_def["expected"],
                replay["actual"] if replay["actual"] is not None else replay["stderr"].strip()))
    return {"id": case_def["id"], "requirement": case_def["requirement"], "status": status,
            "stream_hex": case_def["stream"].hex().upper(), "expected": case_def["expected"],
            "schedules_run": len(runs), "runs": runs}


def check_stale_exe_protection(src_dir):
    """A failing build in a scratch copy must remove the sentinel exe and block replay."""
    scratch = tempfile.mkdtemp(prefix="fw2-stale-")
    try:
        for name in ("parser.h", "main.c"):
            shutil.copy(os.path.join(src_dir, name), scratch)
        with open(os.path.join(scratch, "parser.c"), "w", encoding="utf-8") as handle:
            handle.write("this is deliberately not C;\n")
        exe = os.path.join(scratch, "parser")
        with open(exe, "w", encoding="utf-8") as handle:
            handle.write("#!/bin/sh\necho '[{\"sequence\":1,\"value\":1}]'\n")
        os.chmod(exe, 0o755)
        build = build_candidate(scratch, exe)
        replay = replay_stream(exe, [], build)
        ok = (build["status"] == "build_failed" and not build["exe_exists"]
              and replay["status"] == "blocked" and replay["stdout"] == "")
        return {"status": "pass" if ok else "fail", "build_status": build["status"],
                "exe_exists_after_failed_build": build["exe_exists"],
                "replay_status": replay["status"], "replay_stdout": replay["stdout"],
                "command": build["command"]}
    finally:
        shutil.rmtree(scratch, ignore_errors=True)


def verify_preserved(baseline, current):
    """Compare digest maps; ``changed`` lists differing keys."""
    changed = sorted(k for k in baseline if baseline[k] != current.get(k))
    return {"status": "pass" if not changed else "fail", "unchanged": not changed,
            "changed": changed}


# --------------------------------------------------------------------------
# Check matrix
# --------------------------------------------------------------------------
def build_case_matrix(example):
    """Requirement-linked cases built from fields; the example comes from the spec."""
    ex_seq, ex_val = example["sequence"], example["value"]
    models = [
        ("example", "R-STREAM", [("frame", ex_seq, ex_val)]),
        ("positive", "R-VALUE", [("frame", 3, 1234)]),
        ("negative", "R-VALUE", [("frame", 4, -1)]),
        ("signed_min", "R-VALUE", [("frame", 5, VALUE_MIN)]),
        ("signed_max", "R-VALUE", [("frame", 6, VALUE_MAX)]),
        ("sequence_a5_and_payload_a5", "R-HEADER-DATA", [("frame", 0xA5, -23131)]),
        ("bad_checksum", "R-CHECKSUM", [("bad", 9, 100)]),
        ("noise_then_frame", "R-RESYNC", [("noise", b"\x01\x02\x03"), ("frame", 10, -300)]),
        ("incomplete_tail", "R-TAIL", [("frame", 11, 5), ("tail", bytes([HEADER, LENGTH_BYTE, 12]))]),
        ("two_frames", "R-STREAM", [("frame", 13, 7), ("frame", 14, -7)]),
    ]
    cases = []
    for name, requirement, model in models:
        stream, expected = expected_frames(model)
        cases.append({"id": name, "requirement": requirement, "stream": stream,
                      "expected": expected})
    # Interacting resync cases are derived by hand from requirements.md so the
    # oracle never degenerates into a second parser.
    frame = build_packet(ex_seq, ex_val)
    one = [{"sequence": ex_seq, "value": ex_val}]
    hand = [
        # A stray header sees a second byte A5 != 02, so only it is dropped.
        ("stray_header_then_frame", "R-RESYNC", bytes([HEADER]) + frame, one),
        # Wrong length after a header: drop only the leading A5, rescan.
        ("wrong_length_then_frame", "R-RESYNC", bytes([HEADER, 0x03]) + frame, one),
        # A bad-checksum candidate overlapping a real frame: drop one byte, rescan.
        ("bad_checksum_hides_frame", "R-RESYNC", build_packet(1, 2, True)[:3] + frame, one),
        ("frame_twice", "R-STREAM", frame + frame, one * 2),
    ]
    for name, requirement, stream, expected in hand:
        cases.append({"id": name, "requirement": requirement, "stream": stream,
                      "expected": expected})
    for case in cases:
        case["schedules"] = (all_splits(case["stream"], "whole") + all_splits(case["stream"], "two_way")
                             + all_splits(case["stream"], "single_byte"))
    return cases


def malformed_cases():
    """Malformed argument lists: odd length, non-hex, over-limit chunk."""
    return [
        ("odd_length", "R-CLI", ["A50"]),
        ("non_hex", "R-CLI", ["A5ZZ"]),
        ("oversize_chunk", "R-CLI", ["00" * (MAX_CHUNK_BYTES + 1)]),
        ("bad_after_good", "R-CLI", ["A502", "XY"]),
    ]


def extra_cli_cases(exe, build):
    """No arguments, empty chunks, lower-case hex and the maximum chunk size."""
    frame = build_packet(7, -123)
    one = [{"sequence": 7, "value": -123}]
    specs = [
        ("no_arguments", "R-CLI", [], []),
        ("empty_chunks", "R-CLI", ["", frame.hex().upper(), ""], one),
        ("lowercase_hex", "R-CLI", [frame.hex().lower()], one),
        ("max_chunk_accepted", "R-CLI", ["00" * MAX_CHUNK_BYTES], []),
    ]
    results = []
    for name, requirement, chunks, expected in specs:
        replay = replay_stream(exe, chunks, build)
        verdict = compare_results(expected, replay["actual"]) if replay["status"] == "pass" else None
        ok = replay["status"] == "pass" and verdict["equal"] and replay["rc"] == 0
        status = "pass" if ok else (replay["status"] if replay["status"] != "pass" else "fail")
        results.append({"id": name, "requirement": requirement, "status": status,
                        "expected": expected, "replay": replay, "comparison": verdict})
    return results


# --------------------------------------------------------------------------
# Evidence and report
# --------------------------------------------------------------------------
def write_evidence(evidence_dir, name, record, overwrite=False):
    """Write a JSON record; original stage/baseline/session evidence is never overwritten."""
    os.makedirs(evidence_dir, exist_ok=True)
    path = os.path.join(evidence_dir, name)
    protected = name.startswith(("stage", "baseline", "session"))
    if os.path.exists(path) and (protected or not overwrite):
        raise FileExistsError("refusing to overwrite existing evidence: %s" % path)
    record = dict(record, written_utc=utc_now())
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(record, handle, indent=2, sort_keys=True)
        handle.write("\n")
    return path


def render_report(summary):
    """Human summary; failed/blocked entries stay visible, instructor check not run."""
    lines = ["FW2 verification: %s" % summary["status"].upper()]
    if summary.get("reason"):
        lines.append("  reason: %s" % summary["reason"])
    lines.append("  build: %s" % summary["build"]["status"])
    for item in summary["checks"]:
        lines.append("  [%s] %s (%s)" % (item["status"], item["id"], item["requirement"]))
    lines.append("  instructor check: not run (not permitted in this workspace)")
    return "\n".join(lines)


def verify_workspace(workspace, compiler_cmd=None):
    """Build the workspace candidate and run every required check.

    Never edits parser.c.  Status is pass only if the build and every check pass.
    """
    ws = load_workspace(workspace)
    summary = {"status": "blocked", "workspace": ws["workspace"], "case": ws.get("case"),
               "build": {"status": "blocked"}, "checks": [], "python": sys.version.split()[0]}
    if ws["status"] != "pass":
        summary["reason"] = ws["reason"]
        log("BLOCKED: %s" % ws["reason"])
        return summary
    paths = ws["paths"]
    src_dir = os.path.dirname(paths["parser_c"])
    with open(paths["spec"], encoding="utf-8") as handle:
        example = read_example(handle.read(), ws["case"])
    summary["example"] = example
    if example["status"] != "pass":
        summary["reason"] = example["reason"]
        log("BLOCKED: %s" % example["reason"])
        return summary

    log("ACTION build: expect rc 0 under -Wall -Wextra -Werror (compiling does not prove the protocol)")
    build = build_candidate(src_dir, paths["exe"], compiler_cmd)
    summary["build"] = build
    log("RESULT build: status=%s rc=%s source_digest=%s" % (
        build["status"], build["rc"], build["source"]["combined"][:12]))
    if build["status"] != "pass":
        log("observed compiler stderr: %s" % build["stderr"].strip())
        summary["status"] = build["status"]
        return summary

    checks = summary["checks"]
    for case in build_case_matrix(example):
        log("ACTION case %s (%d schedules), expected=%s" % (
            case["id"], len(case["schedules"]), case["expected"]))
        result = run_case(case, paths["exe"], build)
        checks.append(result)
        log("RESULT case %s: %s" % (case["id"], result["status"]))
    for name, requirement, chunks in malformed_cases():
        result = check_rejects_malformed(paths["exe"], chunks, build)
        result.update(id="malformed_" + name, requirement=requirement)
        checks.append(result)
        log("RESULT malformed %s: %s (expected rc!=0, stderr text, empty stdout)" % (name, result["status"]))
    for result in extra_cli_cases(paths["exe"], build):
        checks.append(result)
        log("RESULT cli %s: %s" % (result["id"], result["status"]))
    stale = check_stale_exe_protection(src_dir)
    stale.update(id="stale_exe_protection", requirement="R-BUILD")
    checks.append(stale)
    log("RESULT stale_exe_protection: %s" % stale["status"])

    summary["status"] = "pass" if all(c["status"] == "pass" for c in checks) else "fail"
    return summary
