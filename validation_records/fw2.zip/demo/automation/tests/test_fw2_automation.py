"""Checks for the FW2 automation: defect detection, valid input, failure branches.

Run: python3 -m unittest discover -s automation/tests -v   (from the workspace)
Altered fixtures live in automation/tests/fixtures; temporary workspaces copy the
trusted header, CLI, spec and case metadata from the real workspace.
"""

import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
AUTOMATION = os.path.dirname(HERE)
WORKSPACE = os.path.dirname(AUTOMATION)
sys.path.insert(0, AUTOMATION)
import fw2_tools as tools  # noqa: E402

GUARDRAILS = os.path.join(AUTOMATION, "guardrails.py")


def make_workspace(parser_c):
    """Create a temp workspace around the given parser.c; returns its path."""
    root = tempfile.mkdtemp(prefix="fw2-test-ws-")
    os.makedirs(os.path.join(root, "fw2"))
    for name in ("case.json", "requirements.md"):
        shutil.copy(os.path.join(WORKSPACE, name), root)
    for name in ("parser.h", "main.c"):
        shutil.copy(os.path.join(WORKSPACE, "fw2", name), os.path.join(root, "fw2"))
    shutil.copy(parser_c, os.path.join(root, "fw2", "parser.c"))
    return root


def run_guardrails(root):
    """Run the entry point; return (rc, evidence dict or None)."""
    done = subprocess.run([sys.executable, GUARDRAILS, "--workspace", root],
                          capture_output=True, text=True)
    path = os.path.join(root, "evidence", "fw2-verification.json")
    evidence = None
    if os.path.exists(path):
        with open(path, encoding="utf-8") as handle:
            evidence = json.load(handle)
    return done.returncode, evidence, done.stdout


def failing_ids(evidence):
    return {c["id"] for c in evidence["checks"] if c["status"] != "pass"}


class HelperUnits(unittest.TestCase):
    def test_packet_example_bytes(self):
        # -123 is 0xFF85 little-endian -> 85 FF; checksum is XOR of first five bytes.
        self.assertEqual(tools.build_packet(7, -123).hex().upper(), "A5020785FFDA")

    def test_packet_range_errors(self):
        with self.assertRaises(ValueError):
            tools.build_packet(256, 0)
        with self.assertRaises(ValueError):
            tools.build_packet(0, 32768)

    def test_split_and_invalid_cuts(self):
        self.assertEqual(tools.split_stream(b"\x01\x02\x03", [1, 1]), ["01", "", "0203"])
        with self.assertRaises(ValueError):
            tools.split_stream(b"\x01\x02", [2, 1])

    def test_compare_detects_type_and_order(self):
        want = [{"sequence": 1, "value": 2}]
        self.assertTrue(tools.compare_results(want, [{"sequence": 1, "value": 2}])["equal"])
        self.assertFalse(tools.compare_results(want, [{"sequence": 1, "value": 2.0}])["equal"])
        self.assertFalse(tools.compare_results(want, [])["equal"])

    def test_read_example_missing_case_is_blocked(self):
        self.assertEqual(tools.read_example("nothing here", "Demo")["status"], "blocked")


class FailureBranches(unittest.TestCase):
    def test_stale_exe_protection(self):
        self.assertEqual(tools.check_stale_exe_protection(os.path.join(WORKSPACE, "fw2"))["status"], "pass")

    def test_compile_error_not_decode_failure_and_exe_removed(self):
        root = make_workspace(os.path.join(HERE, "fixtures", "compile_error", "parser.c"))
        self.addCleanup(shutil.rmtree, root, True)
        exe = os.path.join(root, "fw2", "parser")
        with open(exe, "w") as handle:  # stale sentinel from an earlier "good" build
            handle.write("#!/bin/sh\necho '[]'\n")
        os.chmod(exe, 0o755)
        rc, evidence, _ = run_guardrails(root)
        self.assertEqual(rc, 2)
        self.assertEqual(evidence["build"]["status"], "build_failed")
        self.assertFalse(os.path.exists(exe))
        self.assertEqual(evidence["checks"], [])

    def test_missing_compiler_is_blocked(self):
        root = make_workspace(os.path.join(WORKSPACE, "fw2", "parser.c"))
        self.addCleanup(shutil.rmtree, root, True)
        build = tools.build_candidate(os.path.join(root, "fw2"), os.path.join(root, "fw2", "parser"),
                                      ["no-such-compiler-xyz", "{source}"])
        self.assertEqual(build["status"], "blocked")
        self.assertEqual(tools.replay_stream(build["exe"], [], build)["status"], "blocked")

    def test_wrong_lab_blocked(self):
        root = make_workspace(os.path.join(WORKSPACE, "fw2", "parser.c"))
        self.addCleanup(shutil.rmtree, root, True)
        with open(os.path.join(root, "case.json"), "w") as handle:
            json.dump({"lab": "fw1", "case": "demo"}, handle)
        rc, evidence, _ = run_guardrails(root)
        self.assertEqual(rc, 3)
        self.assertEqual(evidence["status"], "blocked")


class DefectDetection(unittest.TestCase):
    def run_fixture(self, name):
        root = make_workspace(os.path.join(HERE, "fixtures", name, "parser.c"))
        self.addCleanup(shutil.rmtree, root, True)
        rc, evidence, _ = run_guardrails(root)
        return rc, evidence

    def test_state_loss_is_detected(self):
        rc, evidence = self.run_fixture("state_loss")
        self.assertEqual(rc, 1)
        self.assertEqual(evidence["build"]["status"], "pass")
        # Whole-packet cases still pass; only split schedules expose lost state.
        self.assertIn("example", failing_ids(evidence))
        whole = next(c for c in evidence["checks"] if c["id"] == "example")["runs"][0]
        self.assertEqual(whole["status"], "pass")

    def test_unsigned_conversion_is_detected(self):
        rc, evidence = self.run_fixture("unsigned_value")
        self.assertEqual(rc, 1)
        failed = failing_ids(evidence)
        self.assertTrue({"example", "negative", "signed_min"} <= failed)
        self.assertNotIn("positive", failed)
        self.assertNotIn("bad_checksum", failed)


class ValidCandidate(unittest.TestCase):
    def test_current_parser_passes_and_source_unchanged(self):
        source = os.path.join(WORKSPACE, "fw2", "parser.c")
        root = make_workspace(source)
        self.addCleanup(shutil.rmtree, root, True)
        before = tools.sha256_file(os.path.join(root, "fw2", "parser.c"))
        rc, evidence, _ = run_guardrails(root)
        self.assertEqual(rc, 0, failing_ids(evidence) if evidence else "no evidence")
        rc2, evidence2, _ = run_guardrails(root)  # idempotent repeat
        self.assertEqual(rc2, 0)
        self.assertEqual(before, tools.sha256_file(os.path.join(root, "fw2", "parser.c")))
        ids = {c["id"] for c in evidence2["checks"]}
        for required in ("example", "signed_min", "signed_max", "bad_checksum", "noise_then_frame",
                         "incomplete_tail", "stale_exe_protection", "malformed_odd_length"):
            self.assertIn(required, ids)

    def test_preserved_file_change_is_detected(self):
        root = make_workspace(os.path.join(WORKSPACE, "fw2", "parser.c"))
        self.addCleanup(shutil.rmtree, root, True)
        self.assertEqual(run_guardrails(root)[0], 0)
        with open(os.path.join(root, "fw2", "main.c"), "a") as handle:
            handle.write("\n/* tampered */\n")
        rc, evidence, _ = run_guardrails(root)
        self.assertEqual(rc, 1)
        self.assertIn("preserved_files", failing_ids(evidence))


if __name__ == "__main__":
    unittest.main()
