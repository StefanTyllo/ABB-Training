/* Test fixture: deliberate compile error. */
#include "parser.h"
void parser_feed(Parser *p, const uint8_t *data, size_t size, Emit emit) {
    this_function_does_not_exist(p, data, size, emit);
}
