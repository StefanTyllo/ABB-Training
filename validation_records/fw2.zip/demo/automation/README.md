# FW2 automation

Verifies a candidate `fw2/parser.c`. It builds, replays and compares; it contains no parser and never edits `parser.c`. Run from anywhere; all paths resolve from `--workspace`.

## Commands (use an absolute workspace path)
```bash
# Full verification (build + all checks + evidence). Idempotent.
python3 automation/guardrails.py --workspace /absolute/path/to/workspace

# Tests of the automation itself (defect fixtures, valid input, failure branches)
cd /absolute/path/to/workspace && python3 -m unittest discover -s automation/tests -v
```

## Exit codes
| Code | Meaning |
| --- | --- |
| 0 | Build passed and every check passed |
| 1 | A decode/protocol/preservation check failed |
| 2 | Build failed (compile error); no executable is run |
| 3 | Blocked (missing input, wrong lab, no compiler, no example) or error |

## Files
- `guardrails.py` – entry point, preservation check, evidence, exit code.
- `fw2_tools.py` – `build_candidate`, `build_packet`, `split_stream`, `all_splits`, `expected_frames` (spec oracle), `replay_stream`, `compare_results`, `check_rejects_malformed`, `check_stale_exe_protection`, `run_case`, `write_evidence`.
- `tests/test_fw2_automation.py` and `tests/fixtures/{state_loss,unsigned_value,compile_error}/parser.c` – altered fixtures used only by tests.

## Evidence (under `<workspace>/evidence/`)
- `fw2-verification.json` – regenerated each run: source digests, build command/rc/stdout/stderr, per-check requirement ID, input chunks, expected and actual objects, process results, `instructor_check: "not run"`.
- `fw2-preserved-baseline.json` – digests of `parser.h`, `main.c`, `requirements.md`, `case.json`; written once, never overwritten, compared on repeat runs.
- Evidence files named `stage*`, `baseline*`, `session*` are never overwritten.

## Checks
Whole/split equivalence (whole, every 2-way split including empty chunks, single-byte); signed min/max, positive, negative; bad checksum; incomplete tail; noise, stray header, wrong length and overlapping bad-checksum candidate followed by a valid frame; `A5` inside payload/sequence; malformed CLI input; no args, empty chunks, lower-case hex, 4096-byte chunk; stale-exe protection (scratch copy with a compile error and a sentinel executable); preserved files.

Expected values are computed from packet fields and `requirements.md`, never from the program under test. The instructor checker is not run by this automation.
