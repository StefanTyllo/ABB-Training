# Extraction map: FW2 streaming-parser workflow (stage 3)

Scope: review of `workflow.md` steps against `requirements.md` (sole protocol authority) and `task-card.md`. This is a design map only. No reusable automation exists yet; it is implemented in stage 4 under `automation/`.

Dispositions: **D** = deterministic code, **M** = model judgment, **H** = human decision.
Cross-cutting rule: every function returns a result record (never raises for an expected engineering failure) so a failed or blocked result stays visible. Paths resolve from `--workspace`. Nothing hard-codes the case identity, example packet, or chunk boundaries.

## Step review

| # | Step | Purpose | Inputs | Operation | Expected output | Failure condition | Disposition |
|---|------|---------|--------|-----------|-----------------|-------------------|-------------|
| 1a | Validate inputs: collection | Confirm all files exist and the workspace is the right lab | workspace path, `case.json`, `requirements.md`, `fw2/{parser.c,parser.h,main.c}` | Check existence; read `case.json`; require `lab == fw2` | Validated input record with absolute paths | Missing file, unparsable JSON, other lab: **blocked**, stop | D |
| 1b | Source/preserved digests | Prove what was tested and what stayed unchanged | Files above | SHA-256 of each file; compare against recorded baseline | Digest map; preserved-file comparison | Preserved file digest differs: **fail** | D |
| 1c | Read the specification | Know the contract before touching code | `requirements.md` | Read in full | Understanding of the contract | n/a | M |
| 1d | Extract the example packet | Get case-specific reproduction input from the spec | `requirements.md`, `case.json` | Parse the `Demo`/`Transfer` example line for this case (bytes, sequence, value) | `{bytes, sequence, value}` | No example found for the case: **blocked**; never reuse another case's values | D (parse), M (if the wording is ambiguous) |
| 2 | Build | Compile the candidate and record the result | source dir, compiler command, exe path | Delete any stale exe first; run the command; capture rc/stdout/stderr, start/end time, source digest | Build record | Compiler missing: **blocked**; nonzero rc: **build_failed**. In both cases the exe is not executed, and the build result is kept distinct from decode failures | D |
| 2b | Interpret a build pass | Avoid treating compilation as correctness | Build record | State that the compiler checks syntax, not the protocol | Explanation | n/a | M |
| 3 | Construct packets | Build valid stream bytes from fields | sequence, value, optional checksum override | Pack `A5 02 seq lo hi`, XOR checksum, and range-check seq 0..255 and value -32768..32767 | 6 bytes | Field out of range: reject with an error | D |
| 3b | Split into chunks | Apply a supplied schedule | byte string, cut offsets | Slice at the offsets; empty chunks allowed; each chunk at most 4096 bytes; hex-encode | List of hex strings | Offsets non-monotonic or out of range; oversized chunk | D |
| 3c | Replay a stream | Run the exe once per stream, one chunk per argument | exe, chunk list, timeout | Run via subprocess without a shell; record argv, rc, stdout, stderr; parse stdout JSON | Process record + parsed objects | Exe missing or stale: **blocked**; timeout; nonzero rc when success was expected; unparsable stdout | D |
| 4 | Compare | Decide pass/fail per case | actual objects, expected objects | Exact ordered equality of `{sequence, value}` lists; for error cases require rc != 0, non-empty stderr, empty stdout | Verdict + diff | Mismatch: **fail** (decode failure, distinct from build failure) | D |
| 4b | Expected-object derivation | Spec-derived oracle, independent of the program under test | field lists, noise bytes, spec resync rules | Compute expected output from the fields by hand-written rules, never from the exe | Expected list | Oracle disagrees with the spec examples | D for simple cases; M for the design of the oracle; H if the spec is ambiguous |
| 5 | Locate the defect | Find the source lines that contradict the spec | Source, failing reproductions, spec | Read the source: state lifetime, integer widening, resync discards | Diagnosis | n/a | M |
| 6 | Repair | Minimal edit to `parser.c` only | Diagnosis | Edit the source | Changed `parser.c` | Preserved file touched; special-casing; hard-coded response | M (automation must never contain a repaired parser) |
| 7 | Choose the check set | Cover a narrow fix | Spec, defect classes | Select cases: whole vs split at every boundary, min/max, positive/negative, bad checksum, noise + stray header, incomplete tail, empty/no-argument, upper/lower hex, malformed input | Check matrix | n/a | M (choice and adequacy), D (execution) |
| 7b | Whole/split equivalence | Boundaries must not change the result | Stream bytes | Run the whole stream and every 2-way split (plus an all-single-byte split); compare to the whole result and to the expected value | Per-schedule verdicts | Any schedule differs | D |
| 7c | Malformed CLI input | Check rejection before any stdout | odd-length, non-hex, over-limit chunk | Run; check rc != 0, stderr non-empty, stdout empty | Verdict | Any condition violated | D |
| 7d | Stale-exe protection | A failed build must not run an old binary | Source with deliberate compile error in a scratch copy | Place a sentinel exe, run a failing build, confirm the exe is removed or not run and the result is `build_failed` | Verdict | Old exe executed | D (run on a temp copy only; never modify the workspace source) |
| 8 | Preservation | Only the source differs | Baseline and current digests | Compare digests of `parser.h`, `main.c`, `requirements.md`, `case.json` | Pass/fail | Any change | D |
| 9a | Evidence record | Reproducible, requirement-linked record | All results above | Write JSON with the source digest, command, input chunks, expected, actual, process result, timestamps, and requirement ID; append-only (new file or merge without overwriting the original baseline) | `evidence/*.json` | Cannot write; overwrite attempted | D |
| 9b | Explanation | Why the repair works; why the checks are adequate; limits | Evidence | Write the narrative | Report | n/a | M |
| 10 | Instructor/external check | Independent protocol verdict | Path supplied only if permitted | Run only if explicitly allowed | Verdict or "not run" | Not permitted: record "not run"; never claim a protocol pass from own checks | H (permission); D (run) |
| 11 | Judge completion | Accept or reject the work | All evidence | Review the explanation and automation quality | Decision | n/a | H |
| 12 | Resolve a new ambiguous requirement | Spec silent or contradictory | Spec | Decide the interpretation | Decision | n/a | H |

## Proposed function contracts (implement in stage 4; none implemented now)

All live under `automation/`. "Record" means a JSON-serializable dict. Common fields: `status` in `{pass, fail, build_failed, blocked, error}`, `command` (argv list), `rc`, `stdout`, `stderr`, `source_sha256`.

| Function | Input | Output | Errors / notes |
|---|---|---|---|
| `load_workspace(workspace) -> Record` | Absolute path | `{workspace, lab, case, paths{parser_c, parser_h, main_c, spec, exe, evidence}}` | Missing files or wrong lab → `blocked` with the reason; no exception |
| `sha256_file(path) -> str` | Path | Hex digest | Missing file → `None`, recorded by the caller |
| `snapshot_files(paths) -> dict` | List of paths | `{path: digest}` | Used for the preserved-file check |
| `read_example(spec_text, case) -> Record` | `requirements.md` text and the case name | `{bytes_hex, sequence, value}` | No example for the case → `blocked` |
| `build_candidate(src_dir, exe_path, compiler_cmd=None) -> Record` | Source dir, exe path, optional argv template | `{status, command, rc, stdout, stderr, source_sha256, exe_exists, started, finished}` | Removes the stale exe before compiling; compiler absent → `blocked`; rc != 0 → `build_failed` and the exe is removed; it must be impossible to replay after a non-pass build |
| `checksum(first_five: bytes) -> int` | 5 bytes | XOR as 0..255 | Raises `ValueError` if length != 5 |
| `build_packet(sequence, value, bad_checksum=False) -> bytes` | seq 0..255, value -32768..32767 | 6 bytes, or 6 bytes with a deliberately wrong checksum | Out-of-range → `ValueError` |
| `split_stream(data, cuts) -> list[str]` | Bytes, sorted offsets within 0..len | Hex chunks (empty chunks are kept, each ≤ 4096 bytes) | Invalid cuts → `ValueError` |
| `all_splits(data, mode) -> list[list[int]]` | Bytes, `two_way`/`single_byte` | Cut-offset schedules | Deterministic order |
| `expected_frames(stream_model) -> list[dict]` | Independent oracle input: sequence of ("frame", seq, value), ("noise", bytes), ("bad", seq, value), ("tail", bytes) | Ordered `[{sequence, value}]` computed from the spec resync rules, never by the exe | Documents the oracle rules; mismatches with the spec examples are `error` |
| `replay_stream(exe, chunks, timeout_s) -> Record` | Exe path, hex chunks | `{command, chunks, rc, stdout, stderr, actual (parsed list or None), parse_error}` | Refuses to run if the build status is not `pass`; subprocess without a shell; timeout → `error` |
| `compare_results(expected, actual) -> Record` | Two lists of objects | `{equal, expected, actual, first_diff}` | Exact order and key equality; types are checked (`int`) |
| `check_rejects_malformed(exe, chunks) -> Record` | Exe, bad chunk list | `{rc_nonzero, stderr_nonempty, stdout_empty, status}` | Any violated condition → `fail` |
| `run_case(case_def, exe) -> Record` | `{id, requirement, model, schedules}` | Per-schedule replay + comparison; case status = fail if any schedule fails | Includes requirement ID |
| `check_stale_exe_protection(workspace_copy) -> Record` | Temporary copy only | Verdict that a failed build leaves no runnable stale exe | Never touches the workspace source |
| `verify_preserved(baseline, current) -> Record` | Two digest maps | `{unchanged: bool, changed: [paths]}` | Baseline stored once, never overwritten |
| `write_evidence(evidence_dir, name, record) -> path` | Dir, name, record | Path written | Refuses to overwrite an existing baseline; creates new files; stamps UTC time |
| `render_report(records) -> str` | All results | Text summary with per-requirement table, blocked/failed items kept visible, "instructor check: not run" unless a result is supplied | Overall `pass` only if every check passes |
| `main(argv) -> int` (`guardrails.py --workspace`) | Absolute workspace path | Exit 0 only if the build and every check pass; otherwise nonzero | Idempotent; never edits `parser.c`; non-interactive; verbose action/result output |

## Notes for stage 4

- Helpers carry no repaired parser and no fixture-style hard-coded CLI response.
- The spec invariants (six-byte layout, signed range, XOR checksum, streaming/resync rules) are constants in the oracle, not parameters; everything else (source dir, compiler, exe, fields, schedules, evidence dir) is a parameter.
- Resync edge cases (wrong length after the header, bad checksum hiding a partial candidate, header byte inside a valid payload) need oracle cases beyond the workflow's observed session; the oracle must follow `requirements.md` literally.
- Instructor checker: not run and not read in this rehearsal; recorded as "not run".
