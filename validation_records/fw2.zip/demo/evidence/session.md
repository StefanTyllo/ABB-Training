# FW2 demo – Stage 1 session log (scripted CI rehearsal)

Spec facts used (requirements.md): packet `A5 02 seq lo hi xor5`; value = signed 16-bit LE; `Parser` persists across feed calls; incomplete tail emits nothing.

## 1. Build
Why: establish a baseline; the card says build passes while behavior fails.
`gcc -std=c11 -Wall -Wextra -Werror fw2/parser.c fw2/main.c -o fw2/parser` -> exit 0.
Observation: compilation succeeded with -Werror, so it proves only syntax/type safety, not protocol correctness.
(A first combined command line was refused by the CI permission layer; I re-ran the steps as separate commands.)

## 2. Reproduce (before repair)
Why: capture the failure before touching code.
- `./fw2/parser a5020785ffda` -> `[{"sequence":7,"value":65413}]` rc=0 (expected value -123)
- `./fw2/parser a50207 85ffda` -> `[]` rc=0 (expected sequence 7, value -123)

## 3. Inspect (rationale)
- Whole vs split: split input loses the packet, so state doesn't survive between feed calls. `parser_feed` begins with `p->used = 0; /* seeded: chunk boundary */`, which wipes the partial packet. Chunk boundaries are a transport detail, so the decoded result must not depend on them. `main.c` creates one Parser per process and reuses it, which is correct.
- Signed conversion: 0xFF85 assembled into an `unsigned`, then assigned to `int` -> 65413. The same two bytes as two's complement are 0xFF85 - 0x10000 = -123, so the value must go through `int16_t`.
- Resync logic (A5 scan, length 02 check, checksum discard-one) was read against the spec and matches; it was left unchanged.

## 4. Repair (focused, only fw2/parser.c)
1. Removed `p->used = 0;` at the start of `parser_feed`.
2. `int value = (int)(int16_t)(uint16_t)raw;`

## 5. Rebuild and re-run
Rebuild: same gcc command -> exit 0.
Expected values below were derived by hand from the spec (XOR checksums computed manually), not from program output.

| Args | Expected | Actual | rc |
|---|---|---|---|
| `a5020785ffda` | seq 7, -123 | `[{"sequence":7,"value":-123}]` | 0 |
| `a50207 85ffda` | seq 7, -123 | same | 0 |
| `a502 2a00 f875` | seq 42, -2048 | `[{"sequence":42,"value":-2048}]` | 0 |
| `a50201341280` (positive 0x1234; xor=0x80) | seq 1, 4660 | `[{"sequence":1,"value":4660}]` | 0 |
| `a50203008024` (min 0x8000; xor=0x24) | seq 3, -32768 | `[{"sequence":3,"value":-32768}]` | 0 |
| `a50204ff7f23` (max 0x7FFF; xor=0x23) | seq 4, 32767 | `[{"sequence":4,"value":32767}]` | 0 |
| `a502013412 81` (bad checksum) | `[]` | `[]` | 0 |
| `00ffa5a5020785ffda` (noise + extra A5) | seq 7, -123 | `[{"sequence":7,"value":-123}]` | 0 |
| `00ffa5 a50207 85ffda` (noise, split) | seq 7, -123 | same | 0 |
| `a5020785ffda a50201` (incomplete tail) | only seq 7 | `[{"sequence":7,"value":-123}]` | 0 |
| (no args) | `[]` | `[]` | 0 |
| `abc` (odd length) | stderr, nonzero | `invalid chunk length` | 2 |
| `zz` | stderr, nonzero | `invalid hex` | 2 |

Why these extra cases: the minimum/maximum, positive and negative values stop a conversion fix tailored to -123; the bad checksum, noise and tail cases stop a state fix that merely stops resetting; the split noise case combines both.

## 6. Limits / not done
- The facilitator `smoke.py` instructor checker was not run or read, because the rehearsal rules forbid reading instructor files. Protocol-pass is therefore not claimed; the results above are my own spec-derived checks.
- No reusable automation (`automation/`) was created, as Stage 1 requires.
- Generated artifact `fw2/parser` is left in place.
