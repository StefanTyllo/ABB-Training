# Copilot CLI Session

> [!NOTE]
> - **Session ID:** `6863adaa-e82e-4ce3-b496-9b81d55b7ee1`  
> - **Started:** 10/14/2026, 3:48:51 PM  
> - **Duration:** 43s  
> - **Exported:** 10/14/2026, 3:49:35 PM  

---

<sub>1s</sub>

### User

You are performing a scripted CI rehearsal of the ABB training lab.
Your working directory is /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo. Stay in this workspace. Do not read instructor files,
external graders, other workspaces, or CI orchestration. They are independent assessment.
Read task-card.md, CI_CONTRACT.md, and the local requirements/report contract.
Use actual terminal tools; do not claim unexecuted results. Do not print environment variables
or credentials. Preserve source authorities and supplied adapters. Expected engineering failure
or blocked results must remain visible. This is a scripted rehearsal, not a human learner pilot.
STAGE 3: Review each workflow step. Write extraction-map.md with purpose,
inputs, operation, expected output, failure condition, and disposition (deterministic code, model judgment,
human decision). Prioritize collection, parsing, calculation, comparison, validation, reporting. Give every
proposed function an input/output contract. Do not implement reusable automation until stage 4.


---

<sub>2s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && ls -la && cat task-card.md CI_CONTRACT.md**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && ls -la && cat task-card.md CI_CONTRACT.md

<details>
<summary>151 lines</summary>

````
total 56
drwxr-xr-x 4 runner runner 4096 Oct 14 15:48 .
drwxr-xr-x 5 runner runner 4096 Oct 14 15:46 ..
-rw-r--r-- 1 runner runner 5336 Oct 14 15:46 CI_CONTRACT.md
-rw-r--r-- 1 runner runner   31 Oct 14 15:46 case.json
drwxr-xr-x 2 runner runner 4096 Oct 14 15:48 evidence
drwxr-xr-x 2 runner runner 4096 Oct 14 15:47 fw2
-rw-r--r-- 1 runner runner 2838 Oct 14 15:46 requirements.md
-rw-r--r-- 1 runner runner 4846 Oct 14 15:46 task-card.md
-rw-r--r-- 1 runner runner 7100 Oct 14 15:48 workflow-md-only.md
-rw-r--r-- 1 runner runner 7100 Oct 14 15:48 workflow.md

# FW2 Reproduce and repair a streaming parser

**Task card.** Repair the supplied C parser to satisfy its signed-value and streaming requirements. Preserve its public interface. Demonstrate the failures, explain the repair, and extract a reusable build/reproduction/verification workflow.

**Prepare from the training root**
```bash
python materials/prepare_lab.py fw2 demo work/fw2-demo
cd work/fw2-demo
```
Read `requirements.md` before editing. A packet is `A5 02 sequence low high checksum`; the value is signed 16-bit little-endian and checksum is XOR of the first five bytes. Each CLI argument is one receive chunk in the same stream. The complete contract defines noise, invalid length, checksum failure, and resynchronization. There is no timeout requirement in this fixture.

**Allowed changes:** `fw2/parser.c`, plus common workflow/automation/evidence files. Preserve `parser.h`, `main.c`, and the specification. The compiled `fw2/parser` is a generated artifact.

## Stage 1 Guided operations
```bash
gcc -std=c11 -Wall -Wextra -Werror \
  fw2/parser.c fw2/main.c -o fw2/parser
./fw2/parser a5020785ffda
./fw2/parser a50207 85ffda
```
Both invocations describe sequence 7 and value -123. Save their actual outputs. Explain why receive-chunk boundaries must not change the decoded result. Inspect the integer conversion and lifetime of partial parser state before changing code.

Make a focused repair. Rebuild and repeat the same reproductions. Then run a positive value, negative boundary, checksum error, and a valid packet following noise. Derive expected values from the specification, not the current output.

| Decision point | Evidence to explain |
| --- | --- |
| Build passes, behavior fails | Why successful compilation does not establish protocol correctness |
| Whole versus split packet | Whether state survives between feed calls |
| Signed conversion | How the same two bytes represent a negative two's-complement value |
| After repair | Which additional cases protect against a narrow example-specific fix |

**Demonstration complete:** both reproductions produce the specified result; the facilitator's protocol check passes; the participant explains the change. Use the shared documentation prompt.


# FW2 Extract build and replay tooling

## Stage 2 Abstraction focus
Parameterize source directory, compiler command, executable path, packet fields, chunk schedule, and evidence destination. Preserve the six-byte packet format, signed range, checksum definition, and streaming semantics as specification invariants.

## Stage 3 Deterministic boundary
| Move into code | Retain as reasoning |
| --- | --- |
| Compile and capture exit status/stdout/stderr | Locate the implementation defect |
| Construct packets from valid fields and split by supplied boundaries | Decide how to repair state handling without unnecessary changes |
| Replay streams and compare actual/expected objects | Resolve any future ambiguous protocol requirement |
| Produce requirement-linked verification records | Explain why the check set is adequate for this task |

## Stage 4 Required implementation behavior
Create readable build, packet construction, stream replay, and comparison functions under `automation/`. Do not put a corrected parser inside the workflow automation. The automation verifies the candidate parser; the agent still performs task-specific repairs.

Represent compilation failure separately from an incorrect decode. A failed compiler command must stop execution of an older executable. Every result must identify the source snapshot or digest, command, input bytes/chunks, expected objects, actual objects, and process result.

**Required checks:** whole/split equivalence; signed minimum and maximum; bad checksum rejected; incomplete tail emits nothing; valid frame after noise recovered; compilation failure cannot reuse a stale executable. Follow the exact resynchronization contract in requirements.md.

**Transfer preparation, from the training root**
```bash
python materials/prepare_lab.py fw2 transfer work/fw2-transfer-md
python materials/prepare_lab.py fw2 transfer work/fw2-transfer-code
```
The fresh starters retain the defects. Use this new reproduction after building:
```bash
./fw2/parser a502 2a00 f875
```
Expected result: sequence 42, value -2048. Transfer the workflow and helpers, not the repaired `parser.c` or old executable. The new agent must use the process to repair the fresh candidate.

**Facilitator protocol check**, from the training root after a learner build:
```bash
python materials/firmware/instructor/smoke.py \
  work/fw2-demo/fw2/parser
```
Use the transfer executable path for a transfer submission. The checker evaluates 50 stream cases plus malformed input. Also review the explanation and automation; a protocol pass alone does not complete the training assessment.
# Firmware CI contract

The runner creates one workspace per case with `training_kit/prepare_lab.py`.
`case.json` contains `lab` (`fw1` or `fw2`) and `case` (`demo` or `transfer`).
Use only that workspace's paths and inputs; do not hard-code the demo identity,
baud, packet sequence, absolute paths, or receive-chunk boundaries.

Follow the training method: manually walk through the demo with Copilot CLI
explaining why; document the observed workflow in `workflow.md`; abstract incident
specifics; identify deterministic steps; then generate verbose automation.
Stage 1 is the manual walkthrough: do not create reusable automation yet.
Keep explanatory comments and useful action/result output in that automation.
An independent reviewer evaluates the explanation and workflow quality; runtime
checks alone do not establish those qualities or prove when evidence was captured.

## Common automation entry point

Create `automation/guardrails.py`, runnable as:

```bash
python3 automation/guardrails.py --workspace /absolute/path/to/workspace
```

It must return 0 after successful completion and verification, and nonzero on
failure. Resolve all input/output paths from `--workspace`, not the caller's cwd.
Do not require interactive input. It must work after Copilot completes the task
in either the demo or a separately prepared transfer workspace, and be idempotent:
a repeat invocation preserves
the original baseline and does not perform an additional device write or change
the repaired parser sources. The runner copies only `automation/` and
`workflow.md` from the demo into a freshly prepared transfer workspace. All helper
code required by automation must therefore live under `automation/`. Copilot
performs the transfer task before the grader runs; copying helpers does not
replace that fresh investigation and repair.

After Copilot completes the task, the independent grader invokes automation,
validates the completed result using trusted
checks, invokes it again, and validates preservation and results. The grader
does not fix or patch starter sources. Do not modify grader/instructor files.

## FW1

Inputs are `fw1/device.py`, `fw1/expected.json`, `case.json`, and
`device/state.json`. Leave the simulator, expected settings, and case metadata
unchanged. Use device CLI primitives for mutations, not direct state-file edits.
Before the first mutation, write `evidence/baseline.json` containing these keys,
each holding the unmodified JSON output of the corresponding primitive:

| Key | Primitive |
| --- | --- |
| `identity` | `read --field identity` |
| `firmware` | `read --field firmware` |
| `config` | `read --field config` |
| `faults` | `read --field faults` |
| `logs` | `logs` |

All calls use `--workdir <workspace>/device`. Baseline must show original baud
9600, LINK_TIMEOUT, and the original boot log, with matching device identity and
firmware. Never overwrite or reformat an existing baseline. Missing baseline on
an already repaired device is an error: do not fabricate historic evidence.
Use the case and expected settings to derive the target baud. Final config must
match the target, faults must be empty, and probe must succeed. The original boot
log remains, followed by exactly one intended `9600 -> target` change. Running
automation again must preserve state and baseline byte-for-byte.
The grader runs the helper after Copilot has completed the device task, including
capturing the baseline and applying any justified change.

## FW2

Inputs are `fw2/parser.c`, `fw2/parser.h`, `fw2/main.c`, `case.json`, and
`requirements.md`. Repair the parser implementation and use the documented public
API/CLI. Copilot performs a fresh repair in each case. The reusable helper only
builds the candidate, replays protocol cases, compares results, and reports
verification; it must not apply the repair or carry a corrected parser in its
helpers. Preserve `main.c`, `parser.h`,
and case metadata. Do not replace the CLI with hard-coded fixture responses.
An executable supplied by automation is not trusted: the grader rebuilds
`parser.c` with the trusted original CLI/header and runs the instructor's external
50-case stream grader plus malformed input checks. Repeat automation must leave
parser source bytes unchanged. FW2 does not require FW1's baseline JSON.

## Independent evaluation

From the repository root:

```bash
python3 training_ci/grade_firmware.py --lab fw1 --workspace /path/to/fw1-demo
python3 training_ci/grade_firmware.py --lab fw2 --workspace /path/to/fw2-demo
python3 training_ci/grade_firmware.py --lab fw1 --workspace /path/to/fw1-transfer --mode md-only
```

Repeat for each transfer workspace after copying the two common artifacts and
having Copilot complete the fresh task.
The grader prints a JSON result to stdout, a terminal summary to stderr, and saves
`evidence/grade_firmware.json`; it exits 0 on pass and 1 on failed checks.
`--mode code` is the default and invokes/requires automation as described above.
`--mode md-only` requires `workflow.md` and grades the existing baseline/device
state or parser with the same independent result checks, but neither requires nor
invokes automation. The runner uses fresh, separate MD-only and code transfer
workspaces. Learners must not access grader/instructor sources; the runner records
protected-file hashes independently.
<shellId: 0 completed with exit code 0>
````

</details>


---

<sub>4s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && cat requirements.md workflow.md case.json; ls evidence fw2; cat fw2/parser.c fw2/parser.h fw2/main.c**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && cat requirements.md workflow.md case.json; ls evidence fw2; cat fw2/parser.c fw2/parser.h fw2/main.c

<details>
<summary>190 lines</summary>

```
# Exercise contracts

## FW1

- Each invocation handles one primitive and prints one JSON value to stdout on
  success. Invalid commands/parameters/values report stderr and exit nonzero.
- `--workdir PATH` precedes the subcommand; default is `.device` relative to cwd.
  Commands persist mutable state in `PATH/state.json`. Reads/probes do not mutate.
- `init --case demo|transfer` creates state once. Both cases start at baud 9600.
  Demo is SIM-017 / expected 19200; transfer is SIM-083 / expected 38400.
  Both use firmware 1.4.2. `fw1/expected.json` is the fixed configuration reference:
  exercise code must not change it. This separation is logical, not security.
- `read --field identity|firmware|config|faults`, `logs`, and `probe` expose
  independent observations. A mismatch produces LINK_TIMEOUT and a failed probe;
  matching baud produces no active fault and a successful probe. Historical boot
  timeout remains in logs after recovery; logs are not the current fault register.
- `set --parameter baud --value INT` accepts 1200..115200 inclusive; all other
  parameter names and out-of-range values fail without modifying state. Accepted
  writes append a log entry. Capturing before/after evidence is learner work.
- Simulator scope: one operator, local files, deterministic link comparison.
  No hardware timing, authentication, concurrency, retries, or crash recovery.

## FW2

- A packet is exactly six bytes: `A5 02 sequence low high checksum`.
  Sequence is unsigned 8-bit; low/high encode a signed two's-complement 16-bit
  little-endian value. Checksum is XOR of the preceding five bytes.
- `Parser` is initialized to zero once per stream. Every feed call continues
  that stream. Calls may contain zero bytes, partial packets, many packets, or
  noise. Partial state survives chunk boundaries. There is no timeout behavior.
- Resynchronization: discard leading bytes until A5. Once a second byte exists,
  reject any length other than 02 by discarding only the leading A5 and rescanning.
  Wait for six bytes for a candidate with valid header. On checksum failure,
  discard only its first byte and rescan all remaining bytes, preserving a possible
  partial candidate. On success, emit once and consume all six bytes. A5 inside a
  valid payload/sequence/checksum is ordinary data. At end-of-stream, incomplete
  data emits nothing. A fresh process starts a fresh stream.
- CLI arguments are chunks of contiguous, even-length hexadecimal (either case).
  Empty chunks are accepted; maximum is 4096 bytes per argument. Reject malformed
  or longer chunks with nonzero exit and stderr before any stdout. No arguments
  emit `[]`. Successful output is a JSON array of `{sequence, value}` objects.
- Demo `A5 02 07 85 FF DA` means sequence 7, value -123. Transfer
  `A5 02 2A 00 F8 75` means sequence 42, value -2048.
# Workflow: reproduce, repair and verify a streaming packet parser

Reusable for any workspace prepared for this lab (any case). Derived from one observed session; incident values are inputs, not constants.

## Named inputs (validate before use)
| Input | Source / validation | If missing or invalid |
| --- | --- | --- |
| `WORKSPACE` | Absolute directory containing the files below; resolve every path from it, not from cwd | Stop; report |
| `SPEC` | `requirements.md` in `WORKSPACE`; the sole protocol authority | Stop; never infer the protocol from the code or its output |
| `CASE` | `case.json` (`lab`, `case`); must be `fw2` | Stop on other labs |
| `SRC_DIR`, `SOURCE` | `SRC_DIR/parser.c`: the only file to edit | Stop |
| `PRESERVED` | `parser.h`, `main.c`, `SPEC`, `case.json`; record their digests before work and compare at the end | Edit none of them; if a change looks necessary, report it as a blocker |
| `COMPILER_CMD` | Default `gcc -std=c11 -Wall -Wextra -Werror <SOURCE> <main.c> -o <EXE>`; the compiler must exist | Report a blocked build; do not substitute another toolchain silently |
| `EXE` | Generated binary path, treated as untrusted output | Derive from `SRC_DIR`; delete or ignore a stale one on build failure |
| `EXAMPLE` | The packet example for `CASE` read from `SPEC` (sequence, value, bytes) | Stop reproduction; do not copy values from an earlier case |
| `CHUNK_SCHEDULE` | Lists of even-length hex chunk strings (each chunk = one CLI argument) | Use at least: whole packet, split in two at every byte boundary of `EXAMPLE` |
| `EVIDENCE_DIR` | Destination for the session record (default `evidence/`) | Create it; never overwrite earlier evidence, append or use a new file |
| `INSTRUCTOR_CHECK` | External checker, only if explicitly permitted and its path supplied | Do not search for or read it; record "not run" |

## Specification invariants (take values from `SPEC`; do not weaken)
- Packet is six bytes: header, length byte, sequence, value low, value high, checksum. Sequence is unsigned 8-bit. The value is signed 16-bit two's-complement, little-endian. The checksum is the XOR of the first five bytes.
- One parser state per stream; every feed call continues that stream. Chunk boundaries (including empty chunks) must not change the decoded result. A fresh process is a fresh stream. There is no timeout behavior.
- Resynchronization exactly as in `SPEC`: discard to the header byte; a wrong length discards only the leading header byte; a checksum failure discards only the first byte and rescans the rest, keeping a possible partial candidate; success emits once and consumes six bytes; header bytes inside a valid frame are data; an incomplete tail emits nothing.
- CLI contract from `SPEC`: malformed, odd-length or over-limit chunks exit nonzero with stderr and no stdout; no arguments give `[]`; success prints a JSON array of `{sequence, value}`.
- Expected values always come from `SPEC` and hand computation, never from the program under test.

## Steps
1. **Validate inputs.** Confirm every item above; record source digests. Read `SPEC` fully before touching code.
2. **Build** with `COMPILER_CMD`; capture the command, exit status, stdout and stderr. A build failure is its own result (not a decode failure): stop and never run an older `EXE`. A passing build shows only that the code compiles, not that the protocol is right.
3. **Reproduce before editing.** Run `EXAMPLE` as the whole stream and over each `CHUNK_SCHEDULE` split. Save the command, arguments, rc, stdout and stderr, and the expected object from `SPEC`. Unexpected failures stay recorded as failures.
4. **Inspect** the source against `SPEC`, one question at a time:
   a. Is partial-packet state kept across feed calls (lifetime and any reset at the start of a call; any per-call locals)?
   b. How are the value bytes combined and widened (width, signedness, conversion to the output type)?
   c. Does the resynchronization logic match the contract (discard counts, rescan, partial candidate preserved)?
   Explain each finding against `SPEC`. Change only what contradicts it.
5. **Repair minimally** in `SOURCE` only. Do not add result-specific special cases or hard-coded responses.
6. **Rebuild** (step 2) and repeat the step 3 reproductions. Rebuild after every source change.
7. **Broaden checks** so a narrow repair cannot pass. Build each stream from fields, compute the checksum by hand or by an independent routine, and run each both whole and split at every boundary:
   - positive value; negative value; minimum -32768 and maximum 32767;
   - bad checksum gives nothing;
   - valid frame after noise, including a stray header byte before it;
   - incomplete tail gives nothing, while earlier complete frames still emit;
   - no arguments, an empty chunk, and uppercase and lowercase hex;
   - odd length and non-hex input give nonzero rc, stderr, empty stdout.
8. **Verify preservation:** `PRESERVED` digests unchanged; only `SOURCE` differs; the generated `EXE` is not claimed as evidence.
9. **Record** in `EVIDENCE_DIR`: each command with its reason, rc and outputs; expected vs actual per check; edited lines; explanation (why compiling is not correctness, why chunk boundaries must not matter, the two's-complement conversion); limits and what was not run.

## Missing-input and blocked behavior
- Missing or invalid input: follow the table; report a blocked result rather than guessing or fabricating evidence.
- Compiler unavailable or build fails: report blocked or failed with the captured output; keep it visible.
- `INSTRUCTOR_CHECK` not provided or not permitted: state it was not run. Never claim a protocol pass from own checks alone.
- Environment refuses a command: split it into simpler commands and note it.
- Expected-failure results (the pre-repair reproductions) are evidence; keep them.

## Diagnosis hints
- Whole passes but split fails: partial state is lost across calls.
- Magnitude wrong or positive for a negative value: width or signedness of the conversion.
- Extra or missing frames after noise or bad checksum: compare with the resync contract.
- A fix works for the example only: the broadened checks in step 7 should fail it.

## Completion criteria
- Build exits 0 under the stated flags; every reproduction and broadened check matches `SPEC`-derived expectations.
- `PRESERVED` files unchanged; the explanation is recorded; limits are stated.

## Untested branches (not exercised in the observed session)
- Build-failure path and stale-executable protection.
- Another case (the transfer case) and a candidate whose defects differ from those observed.
- Resynchronization edge cases: wrong length byte after a header, a checksum failure that hides a partial candidate, a header byte inside a valid payload.
- Empty chunks, uppercase hex, and the maximum chunk size (reject an oversized chunk).
- Independent instructor/protocol checker and the facilitator rubric.
- Any automation; deterministic steps (build capture, packet construction and splitting, replay, comparison, records) are candidates for later stages only.
{"lab": "fw2", "case": "demo"}
evidence:
session.md
stage1-execution.json
stage1-prompt.txt
stage1-response.txt
stage1-transcript.md
stage2-execution.json
stage2-prompt.txt
stage2-response.txt
stage2-transcript.md
stage3-prompt.txt
stage3-response.txt

fw2:
main.c
parser
parser.c
parser.h
#include "parser.h"
#include <string.h>

static void discard_first(Parser *p) {
    --p->used;
    memmove(p->bytes, p->bytes + 1, p->used);
}

void parser_feed(Parser *p, const uint8_t *data, size_t size, Emit emit) {
    for (size_t i = 0; i < size; ++i) {
        p->bytes[p->used++] = data[i];
        while (p->used) {
            if (p->bytes[0] != 0xA5 || (p->used >= 2 && p->bytes[1] != 2)) {
                discard_first(p);
                continue;
            }
            if (p->used < 6) break;
            uint8_t checksum = 0;
            for (size_t j = 0; j < 5; ++j) checksum ^= p->bytes[j];
            if (checksum != p->bytes[5]) {
                discard_first(p);
                continue;
            }
            unsigned raw = p->bytes[3] | ((unsigned)p->bytes[4] << 8);
            int value = (int)(int16_t)(uint16_t)raw;
            emit(p->bytes[2], value);
            p->used = 0;
        }
    }
}
#ifndef PARSER_H
#define PARSER_H
#include <stddef.h>
#include <stdint.h>
typedef struct { uint8_t bytes[6]; size_t used; } Parser;
typedef void (*Emit)(unsigned sequence, int value);
void parser_feed(Parser *p, const uint8_t *data, size_t size, Emit emit);
#endif
#include "parser.h"
#include <stdio.h>
#include <string.h>

static int first = 1;
static void emit(unsigned sequence, int value) {
    printf("%s{\"sequence\":%u,\"value\":%d}", first ? "" : ",", sequence, value);
    first = 0;
}
static int digit(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}
int main(int argc, char **argv) {
    for (int a = 1; a < argc; ++a) {
        size_t n = strlen(argv[a]);
        if (n % 2 || n > 8192) { fputs("invalid chunk length\n", stderr); return 2; }
        for (size_t i = 0; i < n; ++i)
            if (digit(argv[a][i]) < 0) { fputs("invalid hex\n", stderr); return 2; }
    }
    Parser parser = {{0}, 0};
    putchar('[');
    for (int a = 1; a < argc; ++a) {
        uint8_t bytes[4096];
        size_t n = strlen(argv[a]) / 2;
        for (size_t i = 0; i < n; ++i)
            bytes[i] = (uint8_t)((digit(argv[a][2*i]) << 4) | digit(argv[a][2*i+1]));
        parser_feed(&parser, bytes, n, emit);
    }
    puts("]");
    return 0;
}
<shellId: 1 completed with exit code 0>
```

</details>


---

<sub>39s</sub>

### `create`

**create a new file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/extraction-map.md.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/extraction-map.md

```
Created file /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/extraction-map.md with 11364 characters
```


---

<sub>43s</sub>

### Copilot

I wrote `extraction-map.md` in the demo workspace. I didn't build, run or test anything. This stage was a document review, so I read `task-card.md`, `CI_CONTRACT.md`, `requirements.md`, `workflow.md` and the source files, and nothing else.

- **Step table:** each workflow step has purpose, inputs, operation, expected output, failure condition and a deterministic / model / human disposition. Collection, parsing, calculation, comparison, validation and reporting steps come first.
- **Function contracts:** every proposed function has an input and output contract and a defined error behavior. They include `build_candidate`, `build_packet`, `split_stream`, `replay_stream`, `compare_results`, `expected_frames` and `write_evidence`.
- **Failure visibility:** a compile failure is kept separate from a wrong decode, and a failed build stops the stale executable from running. `blocked` and `fail` results stay visible in the contracts.
- **Instructor check:** not run. The map records it as "not run" rather than claiming a protocol pass.
- **Automation:** none implemented, as stage 3 requires.

---

<sub>Generated by [GitHub Copilot CLI](https://github.com/features/copilot/cli)</sub>
