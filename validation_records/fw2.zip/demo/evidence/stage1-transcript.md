# Copilot CLI Session

> [!NOTE]
> - **Session ID:** `f2ed97ae-d8a9-4751-a395-94672a9af261`  
> - **Started:** 10/14/2026, 3:46:46 PM  
> - **Duration:** 48s  
> - **Exported:** 10/14/2026, 3:47:34 PM  

---

<sub>1s</sub>

### User

You are performing a scripted CI rehearsal of the ABB training lab.
Your working directory is /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo. Stay in this workspace. Do not read instructor files,
external graders, other workspaces, or CI orchestration. They are independent assessment.
Read task-card.md, CI_CONTRACT.md, and the local requirements/report contract.
Use actual terminal tools; do not claim unexecuted results. Do not print environment variables
or credentials. Preserve source authorities and supplied adapters. Expected engineering failure
or blocked results must remain visible. This is a scripted rehearsal, not a human learner pilot.
STAGE 1: Execute the task-card demonstration one operation at a time.
CI cannot provide interactive explanations. Use each decision point in the task card as the scripted
facilitator rationale: state why, execute, inspect the actual result, then proceed. Record every command,
observation, and rationale in evidence/session.md. Complete the task and its stated checks. For browser
labs the correct server is already running at http://127.0.0.1:8765; do not stop it.
For variant evaluation or helper lifecycle checks start your own server on another free port,
set BASE_URL for that subprocess, and stop only your own child process.
Use existing low-level tools. Do not create reusable automation yet. Finally reconstruct the actual process
as workflow.md with prerequisites, ordered steps, branches, evidence, recovery and completion criteria.


---

<sub>2s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && ls -la && cat task-card.md CI_CONTRACT.md && ls requirements* evidence 2>/dev/null**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && ls -la && cat task-card.md CI_CONTRACT.md && ls requirements* evidence 2>/dev/null

<details>
<summary>153 lines</summary>

````
total 40
drwxr-xr-x 4 runner runner 4096 Oct 14 15:46 .
drwxr-xr-x 5 runner runner 4096 Oct 14 15:46 ..
-rw-r--r-- 1 runner runner 5336 Oct 14 15:46 CI_CONTRACT.md
-rw-r--r-- 1 runner runner   31 Oct 14 15:46 case.json
drwxr-xr-x 2 runner runner 4096 Oct 14 15:46 evidence
drwxr-xr-x 2 runner runner 4096 Oct 14 15:46 fw2
-rw-r--r-- 1 runner runner 2838 Oct 14 15:46 requirements.md
-rw-r--r-- 1 runner runner 4846 Oct 14 15:46 task-card.md

# FW2 Reproduce and repair a streaming parser

**Task card.** Repair the supplied C parser to satisfy its signed-value and streaming requirements. Preserve its public interface. Demonstrate the failures, explain the repair, and extract a reusable build/reproduction/verification workflow.

**Prepare from the training root**
```bash
python materials/prepare_lab.py fw2 demo work/fw2-demo
cd work/fw2-demo
```
Read `requirements.md` before editing. A packet is `A5 02 sequence low high checksum`; the value is signed 16-bit little-endian and checksum is XOR of the first five bytes. Each CLI argument is one receive chunk in the same stream. The complete contract defines noise, invalid length, checksum failure, and resynchronization. There is no timeout requirement in this fixture.

**Allowed changes:** `fw2/parser.c`, plus common workflow/automation/evidence files. Preserve `parser.h`, `main.c`, and the specification. The compiled `fw2/parser` is a generated artifact.

## Stage 1 Guided operations
```bash
gcc -std=c11 -Wall -Wextra -Werror \
  fw2/parser.c fw2/main.c -o fw2/parser
./fw2/parser a5020785ffda
./fw2/parser a50207 85ffda
```
Both invocations describe sequence 7 and value -123. Save their actual outputs. Explain why receive-chunk boundaries must not change the decoded result. Inspect the integer conversion and lifetime of partial parser state before changing code.

Make a focused repair. Rebuild and repeat the same reproductions. Then run a positive value, negative boundary, checksum error, and a valid packet following noise. Derive expected values from the specification, not the current output.

| Decision point | Evidence to explain |
| --- | --- |
| Build passes, behavior fails | Why successful compilation does not establish protocol correctness |
| Whole versus split packet | Whether state survives between feed calls |
| Signed conversion | How the same two bytes represent a negative two's-complement value |
| After repair | Which additional cases protect against a narrow example-specific fix |

**Demonstration complete:** both reproductions produce the specified result; the facilitator's protocol check passes; the participant explains the change. Use the shared documentation prompt.


# FW2 Extract build and replay tooling

## Stage 2 Abstraction focus
Parameterize source directory, compiler command, executable path, packet fields, chunk schedule, and evidence destination. Preserve the six-byte packet format, signed range, checksum definition, and streaming semantics as specification invariants.

## Stage 3 Deterministic boundary
| Move into code | Retain as reasoning |
| --- | --- |
| Compile and capture exit status/stdout/stderr | Locate the implementation defect |
| Construct packets from valid fields and split by supplied boundaries | Decide how to repair state handling without unnecessary changes |
| Replay streams and compare actual/expected objects | Resolve any future ambiguous protocol requirement |
| Produce requirement-linked verification records | Explain why the check set is adequate for this task |

## Stage 4 Required implementation behavior
Create readable build, packet construction, stream replay, and comparison functions under `automation/`. Do not put a corrected parser inside the workflow automation. The automation verifies the candidate parser; the agent still performs task-specific repairs.

Represent compilation failure separately from an incorrect decode. A failed compiler command must stop execution of an older executable. Every result must identify the source snapshot or digest, command, input bytes/chunks, expected objects, actual objects, and process result.

**Required checks:** whole/split equivalence; signed minimum and maximum; bad checksum rejected; incomplete tail emits nothing; valid frame after noise recovered; compilation failure cannot reuse a stale executable. Follow the exact resynchronization contract in requirements.md.

**Transfer preparation, from the training root**
```bash
python materials/prepare_lab.py fw2 transfer work/fw2-transfer-md
python materials/prepare_lab.py fw2 transfer work/fw2-transfer-code
```
The fresh starters retain the defects. Use this new reproduction after building:
```bash
./fw2/parser a502 2a00 f875
```
Expected result: sequence 42, value -2048. Transfer the workflow and helpers, not the repaired `parser.c` or old executable. The new agent must use the process to repair the fresh candidate.

**Facilitator protocol check**, from the training root after a learner build:
```bash
python materials/firmware/instructor/smoke.py \
  work/fw2-demo/fw2/parser
```
Use the transfer executable path for a transfer submission. The checker evaluates 50 stream cases plus malformed input. Also review the explanation and automation; a protocol pass alone does not complete the training assessment.
# Firmware CI contract

The runner creates one workspace per case with `training_kit/prepare_lab.py`.
`case.json` contains `lab` (`fw1` or `fw2`) and `case` (`demo` or `transfer`).
Use only that workspace's paths and inputs; do not hard-code the demo identity,
baud, packet sequence, absolute paths, or receive-chunk boundaries.

Follow the training method: manually walk through the demo with Copilot CLI
explaining why; document the observed workflow in `workflow.md`; abstract incident
specifics; identify deterministic steps; then generate verbose automation.
Stage 1 is the manual walkthrough: do not create reusable automation yet.
Keep explanatory comments and useful action/result output in that automation.
An independent reviewer evaluates the explanation and workflow quality; runtime
checks alone do not establish those qualities or prove when evidence was captured.

## Common automation entry point

Create `automation/guardrails.py`, runnable as:

```bash
python3 automation/guardrails.py --workspace /absolute/path/to/workspace
```

It must return 0 after successful completion and verification, and nonzero on
failure. Resolve all input/output paths from `--workspace`, not the caller's cwd.
Do not require interactive input. It must work after Copilot completes the task
in either the demo or a separately prepared transfer workspace, and be idempotent:
a repeat invocation preserves
the original baseline and does not perform an additional device write or change
the repaired parser sources. The runner copies only `automation/` and
`workflow.md` from the demo into a freshly prepared transfer workspace. All helper
code required by automation must therefore live under `automation/`. Copilot
performs the transfer task before the grader runs; copying helpers does not
replace that fresh investigation and repair.

After Copilot completes the task, the independent grader invokes automation,
validates the completed result using trusted
checks, invokes it again, and validates preservation and results. The grader
does not fix or patch starter sources. Do not modify grader/instructor files.

## FW1

Inputs are `fw1/device.py`, `fw1/expected.json`, `case.json`, and
`device/state.json`. Leave the simulator, expected settings, and case metadata
unchanged. Use device CLI primitives for mutations, not direct state-file edits.
Before the first mutation, write `evidence/baseline.json` containing these keys,
each holding the unmodified JSON output of the corresponding primitive:

| Key | Primitive |
| --- | --- |
| `identity` | `read --field identity` |
| `firmware` | `read --field firmware` |
| `config` | `read --field config` |
| `faults` | `read --field faults` |
| `logs` | `logs` |

All calls use `--workdir <workspace>/device`. Baseline must show original baud
9600, LINK_TIMEOUT, and the original boot log, with matching device identity and
firmware. Never overwrite or reformat an existing baseline. Missing baseline on
an already repaired device is an error: do not fabricate historic evidence.
Use the case and expected settings to derive the target baud. Final config must
match the target, faults must be empty, and probe must succeed. The original boot
log remains, followed by exactly one intended `9600 -> target` change. Running
automation again must preserve state and baseline byte-for-byte.
The grader runs the helper after Copilot has completed the device task, including
capturing the baseline and applying any justified change.

## FW2

Inputs are `fw2/parser.c`, `fw2/parser.h`, `fw2/main.c`, `case.json`, and
`requirements.md`. Repair the parser implementation and use the documented public
API/CLI. Copilot performs a fresh repair in each case. The reusable helper only
builds the candidate, replays protocol cases, compares results, and reports
verification; it must not apply the repair or carry a corrected parser in its
helpers. Preserve `main.c`, `parser.h`,
and case metadata. Do not replace the CLI with hard-coded fixture responses.
An executable supplied by automation is not trusted: the grader rebuilds
`parser.c` with the trusted original CLI/header and runs the instructor's external
50-case stream grader plus malformed input checks. Repeat automation must leave
parser source bytes unchanged. FW2 does not require FW1's baseline JSON.

## Independent evaluation

From the repository root:

```bash
python3 training_ci/grade_firmware.py --lab fw1 --workspace /path/to/fw1-demo
python3 training_ci/grade_firmware.py --lab fw2 --workspace /path/to/fw2-demo
python3 training_ci/grade_firmware.py --lab fw1 --workspace /path/to/fw1-transfer --mode md-only
```

Repeat for each transfer workspace after copying the two common artifacts and
having Copilot complete the fresh task.
The grader prints a JSON result to stdout, a terminal summary to stderr, and saves
`evidence/grade_firmware.json`; it exits 0 on pass and 1 on failed checks.
`--mode code` is the default and invokes/requires automation as described above.
`--mode md-only` requires `workflow.md` and grades the existing baseline/device
state or parser with the same independent result checks, but neither requires nor
invokes automation. The runner uses fresh, separate MD-only and code transfer
workspaces. Learners must not access grader/instructor sources; the runner records
protected-file hashes independently.
requirements.md

evidence:
stage1-prompt.txt
stage1-response.txt
<shellId: 0 completed with exit code 0>
````

</details>


---

<sub>4s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && cat requirements.md case.json; head -c 600 evidence/stage1-prompt.txt; echo ----; head -c 400 evidence/stage1-response.txt; ls fw2; cat fw2/parser.h fw2/parser.c fw2/main.c**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && cat requirements.md case.json; head -c 600 evidence/stage1-prompt.txt; echo ----; head -c 400 evidence/stage1-response.txt; ls fw2; cat fw2/parser.h fw2/parser.c fw2/main.c

<details>
<summary>121 lines</summary>

```
# Exercise contracts

## FW1

- Each invocation handles one primitive and prints one JSON value to stdout on
  success. Invalid commands/parameters/values report stderr and exit nonzero.
- `--workdir PATH` precedes the subcommand; default is `.device` relative to cwd.
  Commands persist mutable state in `PATH/state.json`. Reads/probes do not mutate.
- `init --case demo|transfer` creates state once. Both cases start at baud 9600.
  Demo is SIM-017 / expected 19200; transfer is SIM-083 / expected 38400.
  Both use firmware 1.4.2. `fw1/expected.json` is the fixed configuration reference:
  exercise code must not change it. This separation is logical, not security.
- `read --field identity|firmware|config|faults`, `logs`, and `probe` expose
  independent observations. A mismatch produces LINK_TIMEOUT and a failed probe;
  matching baud produces no active fault and a successful probe. Historical boot
  timeout remains in logs after recovery; logs are not the current fault register.
- `set --parameter baud --value INT` accepts 1200..115200 inclusive; all other
  parameter names and out-of-range values fail without modifying state. Accepted
  writes append a log entry. Capturing before/after evidence is learner work.
- Simulator scope: one operator, local files, deterministic link comparison.
  No hardware timing, authentication, concurrency, retries, or crash recovery.

## FW2

- A packet is exactly six bytes: `A5 02 sequence low high checksum`.
  Sequence is unsigned 8-bit; low/high encode a signed two's-complement 16-bit
  little-endian value. Checksum is XOR of the preceding five bytes.
- `Parser` is initialized to zero once per stream. Every feed call continues
  that stream. Calls may contain zero bytes, partial packets, many packets, or
  noise. Partial state survives chunk boundaries. There is no timeout behavior.
- Resynchronization: discard leading bytes until A5. Once a second byte exists,
  reject any length other than 02 by discarding only the leading A5 and rescanning.
  Wait for six bytes for a candidate with valid header. On checksum failure,
  discard only its first byte and rescan all remaining bytes, preserving a possible
  partial candidate. On success, emit once and consume all six bytes. A5 inside a
  valid payload/sequence/checksum is ordinary data. At end-of-stream, incomplete
  data emits nothing. A fresh process starts a fresh stream.
- CLI arguments are chunks of contiguous, even-length hexadecimal (either case).
  Empty chunks are accepted; maximum is 4096 bytes per argument. Reject malformed
  or longer chunks with nonzero exit and stderr before any stdout. No arguments
  emit `[]`. Successful output is a JSON array of `{sequence, value}` objects.
- Demo `A5 02 07 85 FF DA` means sequence 7, value -123. Transfer
  `A5 02 2A 00 F8 75` means sequence 42, value -2048.
{"lab": "fw2", "case": "demo"}
You are performing a scripted CI rehearsal of the ABB training lab.
Your working directory is /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo. Stay in this workspace. Do not read instructor files,
external graders, other workspaces, or CI orchestration. They are independent assessment.
Read task-card.md, CI_CONTRACT.md, and the local requirements/report contract.
Use actual terminal tools; do not claim unexecuted results. Do not print environment variables
or credentials. Preserve source authorities and supplied adapters. Expected engineering failure
or blocked results must remain vi----
main.c
parser.c
parser.h
#ifndef PARSER_H
#define PARSER_H
#include <stddef.h>
#include <stdint.h>
typedef struct { uint8_t bytes[6]; size_t used; } Parser;
typedef void (*Emit)(unsigned sequence, int value);
void parser_feed(Parser *p, const uint8_t *data, size_t size, Emit emit);
#endif
#include "parser.h"
#include <string.h>

static void discard_first(Parser *p) {
    --p->used;
    memmove(p->bytes, p->bytes + 1, p->used);
}

void parser_feed(Parser *p, const uint8_t *data, size_t size, Emit emit) {
    p->used = 0; /* seeded: chunk boundary */
    for (size_t i = 0; i < size; ++i) {
        p->bytes[p->used++] = data[i];
        while (p->used) {
            if (p->bytes[0] != 0xA5 || (p->used >= 2 && p->bytes[1] != 2)) {
                discard_first(p);
                continue;
            }
            if (p->used < 6) break;
            uint8_t checksum = 0;
            for (size_t j = 0; j < 5; ++j) checksum ^= p->bytes[j];
            if (checksum != p->bytes[5]) {
                discard_first(p);
                continue;
            }
            unsigned raw = p->bytes[3] | ((unsigned)p->bytes[4] << 8);
            int value = raw;
            emit(p->bytes[2], value);
            p->used = 0;
        }
    }
}
#include "parser.h"
#include <stdio.h>
#include <string.h>

static int first = 1;
static void emit(unsigned sequence, int value) {
    printf("%s{\"sequence\":%u,\"value\":%d}", first ? "" : ",", sequence, value);
    first = 0;
}
static int digit(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}
int main(int argc, char **argv) {
    for (int a = 1; a < argc; ++a) {
        size_t n = strlen(argv[a]);
        if (n % 2 || n > 8192) { fputs("invalid chunk length\n", stderr); return 2; }
        for (size_t i = 0; i < n; ++i)
            if (digit(argv[a][i]) < 0) { fputs("invalid hex\n", stderr); return 2; }
    }
    Parser parser = {{0}, 0};
    putchar('[');
    for (int a = 1; a < argc; ++a) {
        uint8_t bytes[4096];
        size_t n = strlen(argv[a]) / 2;
        for (size_t i = 0; i < n; ++i)
            bytes[i] = (uint8_t)((digit(argv[a][2*i]) << 4) | digit(argv[a][2*i+1]));
        parser_feed(&parser, bytes, n, emit);
    }
    puts("]");
    return 0;
}
<shellId: 1 completed with exit code 0>
```

</details>


---

<sub>8s</sub>

### Copilot

Why: build first, then reproduce the defect, to show that compiling doesn't prove protocol correctness.

---

<sub>8s</sub>

### `bash` — Failed

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && sha256sum fw2/parser.c; gcc -std=c11 -Wall -Wextra -Werror fw2/parser.c fw2/main.c -o fw2/parser; echo build=$?; ./fw2/parser a5020785ffda; echo rc=$?; ./fw2/parser a50207 85ffda; echo rc=$?**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && sha256sum fw2/parser.c; gcc -std=c11 -Wall -Wextra -Werror fw2/parser.c fw2/main.c -o fw2/parser; echo build=$?; ./fw2/parser a5020785ffda; echo rc=$?; ./fw2/parser a50207 85ffda; echo rc=$?

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>10s</sub>

### Copilot

Retrying as separate simpler commands.

---

<sub>10s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && gcc -std=c11 -Wall -Wextra -Werror fw2/parser.c fw2/main.c -o fw2/parser; echo build=$?**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && gcc -std=c11 -Wall -Wextra -Werror fw2/parser.c fw2/main.c -o fw2/parser; echo build=$?

```
build=0
<shellId: 3 completed with exit code 0>
```


---

<sub>12s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && ./fw2/parser a5020785ffda; echo rc=$?; ./fw2/parser a50207 85ffda; echo rc=$?**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && ./fw2/parser a5020785ffda; echo rc=$?; ./fw2/parser a50207 85ffda; echo rc=$?

```
[{"sequence":7,"value":65413}]
rc=0
[]
rc=0
<shellId: 4 completed with exit code 0>
```


---

<sub>15s</sub>

### Copilot

Both defects reproduced: value 65413 instead of -123 (unsigned conversion), and the split input emits nothing (state reset every feed). Fixing both.

---

<sub>15s</sub>

### `edit`

**edit the file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/fw2/parser.c.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/fw2/parser.c

```
File /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/fw2/parser.c updated with changes.
```


---

<sub>15s</sub>

### `edit`

**edit the file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/fw2/parser.c.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/fw2/parser.c

```
File /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/fw2/parser.c updated with changes.
```


---

<sub>20s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && gcc -std=c11 -Wall -Wextra -Werror fw2/parser.c fw2/main.c -o fw2/parser; echo build=$?
for a in "a5020785ffda" "a50207 85ffda" "a502 2a00 f875" "a50201341280" "a50203008024" "a50204ff7f23" "a5020134128" "a502013412 81" "00ffa5a5020785ffda" "00ffa5 a50207 85ffda" "a5020785ffda a50201" ""; do echo "args=[$a]"; ./fw2/parser $a; echo rc=$?; done; ./fw2/parser abc; echo rc=$?; ./fw2/parser zz; echo rc=$?**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && gcc -std=c11 -Wall -Wextra -Werror fw2/parser.c fw2/main.c -o fw2/parser; echo build=$?
for a in "a5020785ffda" "a50207 85ffda" "a502 2a00 f875" "a50201341280" "a50203008024" "a50204ff7f23" "a5020134128" "a502013412 81" "00ffa5a5020785ffda" "00ffa5 a50207 85ffda" "a5020785ffda a50201" ""; do echo "args=[$a]"; ./fw2/parser $a; echo rc=$?; done; ./fw2/parser abc; echo rc=$?; ./fw2/parser zz; echo rc=$?

<details>
<summary>42 lines</summary>

```
build=0
args=[a5020785ffda]
[{"sequence":7,"value":-123}]
rc=0
args=[a50207 85ffda]
[{"sequence":7,"value":-123}]
rc=0
args=[a502 2a00 f875]
[{"sequence":42,"value":-2048}]
rc=0
args=[a50201341280]
[{"sequence":1,"value":4660}]
rc=0
args=[a50203008024]
[{"sequence":3,"value":-32768}]
rc=0
args=[a50204ff7f23]
[{"sequence":4,"value":32767}]
rc=0
args=[a5020134128]
invalid chunk length
rc=2
args=[a502013412 81]
[]
rc=0
args=[00ffa5a5020785ffda]
[{"sequence":7,"value":-123}]
rc=0
args=[00ffa5 a50207 85ffda]
[{"sequence":7,"value":-123}]
rc=0
args=[a5020785ffda a50201]
[{"sequence":7,"value":-123}]
rc=0
args=[]
[]
rc=0
invalid chunk length
rc=2
invalid hex
rc=2
<shellId: 5 completed with exit code 0>
```

</details>


---

<sub>43s</sub>

### `create`

**create a new file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/evidence/session.md.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/evidence/session.md

```
Created file /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/evidence/session.md with 3511 characters
```


---

<sub>43s</sub>

### `create`

**create a new file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/workflow.md.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/workflow.md

```
Created file /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/workflow.md with 3683 characters
```


---

<sub>48s</sub>

### Copilot

Stage 1 is done: I repaired `fw2/parser.c`, and the rebuilt parser now gives sequence 7, value -123 for both the whole and the split input. I did not run or read the instructor `smoke.py` check, because the rehearsal rules forbid reading instructor files. So I'm not claiming a protocol-check pass.

- **Defects found:**
  - Parser state was reset at the start of every `parser_feed` call, so the split input `a50207 85ffda` printed `[]`.
  - The value was converted as unsigned, so `a5020785ffda` printed 65413 instead of -123.
- **Repair:** I removed the per-call reset and converted the value through `int16_t`. Only `parser.c` was edited, and the rebuild passes under `-Werror`.
- **Checks:** I derived expected values by hand from the spec, not from the program's output. Everything matched:
  - positive value 4660
  - minimum -32768 and maximum 32767
  - bad checksum rejected
  - valid frame after noise, whole and split
  - incomplete tail emits nothing
  - malformed chunks exit 2 with stderr
  - the transfer example `a502 2a00 f875` gives 42 / -2048
- **No automation yet:** I did not create `automation/` or `guardrails.py`, since Stage 1 says not to.
- **One refused command:** the combined build-and-run command line was refused by the CI permission layer, so I ran the steps as separate commands. This is noted in the log.

Files are in `/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo`:
- `evidence/session.md`
- `workflow.md`

---

<sub>Generated by [GitHub Copilot CLI](https://github.com/features/copilot/cli)</sub>
