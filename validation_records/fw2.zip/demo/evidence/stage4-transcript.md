# Copilot CLI Session

> [!NOTE]
> - **Session ID:** `b1538552-3569-4e73-9e2e-0091228fe655`  
> - **Started:** 10/14/2026, 3:49:36 PM  
> - **Duration:** 3m 30s  
> - **Exported:** 10/14/2026, 3:53:06 PM  

---

<sub>1s</sub>

### User

You are performing a scripted CI rehearsal of the ABB training lab.
Your working directory is /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo. Stay in this workspace. Do not read instructor files,
external graders, other workspaces, or CI orchestration. They are independent assessment.
Read task-card.md, CI_CONTRACT.md, and the local requirements/report contract.
Use actual terminal tools; do not claim unexecuted results. Do not print environment variables
or credentials. Preserve source authorities and supplied adapters. Expected engineering failure
or blocked results must remain visible. This is a scripted rehearsal, not a human learner pilot.
STAGE 4: Implement the deterministic operations in extraction-map.md under
automation/, using CI_CONTRACT.md for the common guardrails entry point. Follow every Stage 4 requirement in
task-card.md. Use descriptive names, docstrings, engineering-intent comments, explicit intermediate values,
and actionable expected/observed logs. Produce real machine-readable evidence and meaningful exit codes.
Add checks for the defect, valid input and failure branch; altered fixtures belong under automation/tests.
Run and inspect those checks. Do not overwrite the original stage1 baseline/session evidence. The already
completed task may require idempotent verification. Preserve workflow-md-only.md. Update workflow.md to call
the helpers and explain results, and document exact commands in automation/README.md. Do not access graders.


---

<sub>2s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && ls -la && cat task-card.md CI_CONTRACT.md && ls automation 2>/dev/null**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && ls -la && cat task-card.md CI_CONTRACT.md && ls automation 2>/dev/null

<details>
<summary>152 lines</summary>

````
total 68
drwxr-xr-x 4 runner runner  4096 Oct 14 15:49 .
drwxr-xr-x 5 runner runner  4096 Oct 14 15:46 ..
-rw-r--r-- 1 runner runner  5336 Oct 14 15:46 CI_CONTRACT.md
-rw-r--r-- 1 runner runner    31 Oct 14 15:46 case.json
drwxr-xr-x 2 runner runner  4096 Oct 14 15:49 evidence
-rw-r--r-- 1 runner runner 11384 Oct 14 15:49 extraction-map.md
drwxr-xr-x 2 runner runner  4096 Oct 14 15:47 fw2
-rw-r--r-- 1 runner runner  2838 Oct 14 15:46 requirements.md
-rw-r--r-- 1 runner runner  4846 Oct 14 15:46 task-card.md
-rw-r--r-- 1 runner runner  7100 Oct 14 15:48 workflow-md-only.md
-rw-r--r-- 1 runner runner  7100 Oct 14 15:48 workflow.md

# FW2 Reproduce and repair a streaming parser

**Task card.** Repair the supplied C parser to satisfy its signed-value and streaming requirements. Preserve its public interface. Demonstrate the failures, explain the repair, and extract a reusable build/reproduction/verification workflow.

**Prepare from the training root**
```bash
python materials/prepare_lab.py fw2 demo work/fw2-demo
cd work/fw2-demo
```
Read `requirements.md` before editing. A packet is `A5 02 sequence low high checksum`; the value is signed 16-bit little-endian and checksum is XOR of the first five bytes. Each CLI argument is one receive chunk in the same stream. The complete contract defines noise, invalid length, checksum failure, and resynchronization. There is no timeout requirement in this fixture.

**Allowed changes:** `fw2/parser.c`, plus common workflow/automation/evidence files. Preserve `parser.h`, `main.c`, and the specification. The compiled `fw2/parser` is a generated artifact.

## Stage 1 Guided operations
```bash
gcc -std=c11 -Wall -Wextra -Werror \
  fw2/parser.c fw2/main.c -o fw2/parser
./fw2/parser a5020785ffda
./fw2/parser a50207 85ffda
```
Both invocations describe sequence 7 and value -123. Save their actual outputs. Explain why receive-chunk boundaries must not change the decoded result. Inspect the integer conversion and lifetime of partial parser state before changing code.

Make a focused repair. Rebuild and repeat the same reproductions. Then run a positive value, negative boundary, checksum error, and a valid packet following noise. Derive expected values from the specification, not the current output.

| Decision point | Evidence to explain |
| --- | --- |
| Build passes, behavior fails | Why successful compilation does not establish protocol correctness |
| Whole versus split packet | Whether state survives between feed calls |
| Signed conversion | How the same two bytes represent a negative two's-complement value |
| After repair | Which additional cases protect against a narrow example-specific fix |

**Demonstration complete:** both reproductions produce the specified result; the facilitator's protocol check passes; the participant explains the change. Use the shared documentation prompt.


# FW2 Extract build and replay tooling

## Stage 2 Abstraction focus
Parameterize source directory, compiler command, executable path, packet fields, chunk schedule, and evidence destination. Preserve the six-byte packet format, signed range, checksum definition, and streaming semantics as specification invariants.

## Stage 3 Deterministic boundary
| Move into code | Retain as reasoning |
| --- | --- |
| Compile and capture exit status/stdout/stderr | Locate the implementation defect |
| Construct packets from valid fields and split by supplied boundaries | Decide how to repair state handling without unnecessary changes |
| Replay streams and compare actual/expected objects | Resolve any future ambiguous protocol requirement |
| Produce requirement-linked verification records | Explain why the check set is adequate for this task |

## Stage 4 Required implementation behavior
Create readable build, packet construction, stream replay, and comparison functions under `automation/`. Do not put a corrected parser inside the workflow automation. The automation verifies the candidate parser; the agent still performs task-specific repairs.

Represent compilation failure separately from an incorrect decode. A failed compiler command must stop execution of an older executable. Every result must identify the source snapshot or digest, command, input bytes/chunks, expected objects, actual objects, and process result.

**Required checks:** whole/split equivalence; signed minimum and maximum; bad checksum rejected; incomplete tail emits nothing; valid frame after noise recovered; compilation failure cannot reuse a stale executable. Follow the exact resynchronization contract in requirements.md.

**Transfer preparation, from the training root**
```bash
python materials/prepare_lab.py fw2 transfer work/fw2-transfer-md
python materials/prepare_lab.py fw2 transfer work/fw2-transfer-code
```
The fresh starters retain the defects. Use this new reproduction after building:
```bash
./fw2/parser a502 2a00 f875
```
Expected result: sequence 42, value -2048. Transfer the workflow and helpers, not the repaired `parser.c` or old executable. The new agent must use the process to repair the fresh candidate.

**Facilitator protocol check**, from the training root after a learner build:
```bash
python materials/firmware/instructor/smoke.py \
  work/fw2-demo/fw2/parser
```
Use the transfer executable path for a transfer submission. The checker evaluates 50 stream cases plus malformed input. Also review the explanation and automation; a protocol pass alone does not complete the training assessment.
# Firmware CI contract

The runner creates one workspace per case with `training_kit/prepare_lab.py`.
`case.json` contains `lab` (`fw1` or `fw2`) and `case` (`demo` or `transfer`).
Use only that workspace's paths and inputs; do not hard-code the demo identity,
baud, packet sequence, absolute paths, or receive-chunk boundaries.

Follow the training method: manually walk through the demo with Copilot CLI
explaining why; document the observed workflow in `workflow.md`; abstract incident
specifics; identify deterministic steps; then generate verbose automation.
Stage 1 is the manual walkthrough: do not create reusable automation yet.
Keep explanatory comments and useful action/result output in that automation.
An independent reviewer evaluates the explanation and workflow quality; runtime
checks alone do not establish those qualities or prove when evidence was captured.

## Common automation entry point

Create `automation/guardrails.py`, runnable as:

```bash
python3 automation/guardrails.py --workspace /absolute/path/to/workspace
```

It must return 0 after successful completion and verification, and nonzero on
failure. Resolve all input/output paths from `--workspace`, not the caller's cwd.
Do not require interactive input. It must work after Copilot completes the task
in either the demo or a separately prepared transfer workspace, and be idempotent:
a repeat invocation preserves
the original baseline and does not perform an additional device write or change
the repaired parser sources. The runner copies only `automation/` and
`workflow.md` from the demo into a freshly prepared transfer workspace. All helper
code required by automation must therefore live under `automation/`. Copilot
performs the transfer task before the grader runs; copying helpers does not
replace that fresh investigation and repair.

After Copilot completes the task, the independent grader invokes automation,
validates the completed result using trusted
checks, invokes it again, and validates preservation and results. The grader
does not fix or patch starter sources. Do not modify grader/instructor files.

## FW1

Inputs are `fw1/device.py`, `fw1/expected.json`, `case.json`, and
`device/state.json`. Leave the simulator, expected settings, and case metadata
unchanged. Use device CLI primitives for mutations, not direct state-file edits.
Before the first mutation, write `evidence/baseline.json` containing these keys,
each holding the unmodified JSON output of the corresponding primitive:

| Key | Primitive |
| --- | --- |
| `identity` | `read --field identity` |
| `firmware` | `read --field firmware` |
| `config` | `read --field config` |
| `faults` | `read --field faults` |
| `logs` | `logs` |

All calls use `--workdir <workspace>/device`. Baseline must show original baud
9600, LINK_TIMEOUT, and the original boot log, with matching device identity and
firmware. Never overwrite or reformat an existing baseline. Missing baseline on
an already repaired device is an error: do not fabricate historic evidence.
Use the case and expected settings to derive the target baud. Final config must
match the target, faults must be empty, and probe must succeed. The original boot
log remains, followed by exactly one intended `9600 -> target` change. Running
automation again must preserve state and baseline byte-for-byte.
The grader runs the helper after Copilot has completed the device task, including
capturing the baseline and applying any justified change.

## FW2

Inputs are `fw2/parser.c`, `fw2/parser.h`, `fw2/main.c`, `case.json`, and
`requirements.md`. Repair the parser implementation and use the documented public
API/CLI. Copilot performs a fresh repair in each case. The reusable helper only
builds the candidate, replays protocol cases, compares results, and reports
verification; it must not apply the repair or carry a corrected parser in its
helpers. Preserve `main.c`, `parser.h`,
and case metadata. Do not replace the CLI with hard-coded fixture responses.
An executable supplied by automation is not trusted: the grader rebuilds
`parser.c` with the trusted original CLI/header and runs the instructor's external
50-case stream grader plus malformed input checks. Repeat automation must leave
parser source bytes unchanged. FW2 does not require FW1's baseline JSON.

## Independent evaluation

From the repository root:

```bash
python3 training_ci/grade_firmware.py --lab fw1 --workspace /path/to/fw1-demo
python3 training_ci/grade_firmware.py --lab fw2 --workspace /path/to/fw2-demo
python3 training_ci/grade_firmware.py --lab fw1 --workspace /path/to/fw1-transfer --mode md-only
```

Repeat for each transfer workspace after copying the two common artifacts and
having Copilot complete the fresh task.
The grader prints a JSON result to stdout, a terminal summary to stderr, and saves
`evidence/grade_firmware.json`; it exits 0 on pass and 1 on failed checks.
`--mode code` is the default and invokes/requires automation as described above.
`--mode md-only` requires `workflow.md` and grades the existing baseline/device
state or parser with the same independent result checks, but neither requires nor
invokes automation. The runner uses fresh, separate MD-only and code transfer
workspaces. Learners must not access grader/instructor sources; the runner records
protected-file hashes independently.
<shellId: 0 completed with exit code 2>
````

</details>


---

<sub>4s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && cat requirements.md extraction-map.md case.json; ls evidence fw2; cat fw2/parser.c fw2/parser.h fw2/main.c; git status --short | head**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && cat requirements.md extraction-map.md case.json; ls evidence fw2; cat fw2/parser.c fw2/parser.h fw2/main.c; git status --short | head

<details>
<summary>190 lines</summary>

```
# Exercise contracts

## FW1

- Each invocation handles one primitive and prints one JSON value to stdout on
  success. Invalid commands/parameters/values report stderr and exit nonzero.
- `--workdir PATH` precedes the subcommand; default is `.device` relative to cwd.
  Commands persist mutable state in `PATH/state.json`. Reads/probes do not mutate.
- `init --case demo|transfer` creates state once. Both cases start at baud 9600.
  Demo is SIM-017 / expected 19200; transfer is SIM-083 / expected 38400.
  Both use firmware 1.4.2. `fw1/expected.json` is the fixed configuration reference:
  exercise code must not change it. This separation is logical, not security.
- `read --field identity|firmware|config|faults`, `logs`, and `probe` expose
  independent observations. A mismatch produces LINK_TIMEOUT and a failed probe;
  matching baud produces no active fault and a successful probe. Historical boot
  timeout remains in logs after recovery; logs are not the current fault register.
- `set --parameter baud --value INT` accepts 1200..115200 inclusive; all other
  parameter names and out-of-range values fail without modifying state. Accepted
  writes append a log entry. Capturing before/after evidence is learner work.
- Simulator scope: one operator, local files, deterministic link comparison.
  No hardware timing, authentication, concurrency, retries, or crash recovery.

## FW2

- A packet is exactly six bytes: `A5 02 sequence low high checksum`.
  Sequence is unsigned 8-bit; low/high encode a signed two's-complement 16-bit
  little-endian value. Checksum is XOR of the preceding five bytes.
- `Parser` is initialized to zero once per stream. Every feed call continues
  that stream. Calls may contain zero bytes, partial packets, many packets, or
  noise. Partial state survives chunk boundaries. There is no timeout behavior.
- Resynchronization: discard leading bytes until A5. Once a second byte exists,
  reject any length other than 02 by discarding only the leading A5 and rescanning.
  Wait for six bytes for a candidate with valid header. On checksum failure,
  discard only its first byte and rescan all remaining bytes, preserving a possible
  partial candidate. On success, emit once and consume all six bytes. A5 inside a
  valid payload/sequence/checksum is ordinary data. At end-of-stream, incomplete
  data emits nothing. A fresh process starts a fresh stream.
- CLI arguments are chunks of contiguous, even-length hexadecimal (either case).
  Empty chunks are accepted; maximum is 4096 bytes per argument. Reject malformed
  or longer chunks with nonzero exit and stderr before any stdout. No arguments
  emit `[]`. Successful output is a JSON array of `{sequence, value}` objects.
- Demo `A5 02 07 85 FF DA` means sequence 7, value -123. Transfer
  `A5 02 2A 00 F8 75` means sequence 42, value -2048.
# Extraction map: FW2 streaming-parser workflow (stage 3)

Scope: review of `workflow.md` steps against `requirements.md` (sole protocol authority) and `task-card.md`. This is a design map only. No reusable automation exists yet; it is implemented in stage 4 under `automation/`.

Dispositions: **D** = deterministic code, **M** = model judgment, **H** = human decision.
Cross-cutting rule: every function returns a result record (never raises for an expected engineering failure) so a failed or blocked result stays visible. Paths resolve from `--workspace`. Nothing hard-codes the case identity, example packet, or chunk boundaries.

## Step review

| # | Step | Purpose | Inputs | Operation | Expected output | Failure condition | Disposition |
|---|------|---------|--------|-----------|-----------------|-------------------|-------------|
| 1a | Validate inputs: collection | Confirm all files exist and the workspace is the right lab | workspace path, `case.json`, `requirements.md`, `fw2/{parser.c,parser.h,main.c}` | Check existence; read `case.json`; require `lab == fw2` | Validated input record with absolute paths | Missing file, unparsable JSON, other lab: **blocked**, stop | D |
| 1b | Source/preserved digests | Prove what was tested and what stayed unchanged | Files above | SHA-256 of each file; compare against recorded baseline | Digest map; preserved-file comparison | Preserved file digest differs: **fail** | D |
| 1c | Read the specification | Know the contract before touching code | `requirements.md` | Read in full | Understanding of the contract | n/a | M |
| 1d | Extract the example packet | Get case-specific reproduction input from the spec | `requirements.md`, `case.json` | Parse the `Demo`/`Transfer` example line for this case (bytes, sequence, value) | `{bytes, sequence, value}` | No example found for the case: **blocked**; never reuse another case's values | D (parse), M (if the wording is ambiguous) |
| 2 | Build | Compile the candidate and record the result | source dir, compiler command, exe path | Delete any stale exe first; run the command; capture rc/stdout/stderr, start/end time, source digest | Build record | Compiler missing: **blocked**; nonzero rc: **build_failed**. In both cases the exe is not executed, and the build result is kept distinct from decode failures | D |
| 2b | Interpret a build pass | Avoid treating compilation as correctness | Build record | State that the compiler checks syntax, not the protocol | Explanation | n/a | M |
| 3 | Construct packets | Build valid stream bytes from fields | sequence, value, optional checksum override | Pack `A5 02 seq lo hi`, XOR checksum, and range-check seq 0..255 and value -32768..32767 | 6 bytes | Field out of range: reject with an error | D |
| 3b | Split into chunks | Apply a supplied schedule | byte string, cut offsets | Slice at the offsets; empty chunks allowed; each chunk at most 4096 bytes; hex-encode | List of hex strings | Offsets non-monotonic or out of range; oversized chunk | D |
| 3c | Replay a stream | Run the exe once per stream, one chunk per argument | exe, chunk list, timeout | Run via subprocess without a shell; record argv, rc, stdout, stderr; parse stdout JSON | Process record + parsed objects | Exe missing or stale: **blocked**; timeout; nonzero rc when success was expected; unparsable stdout | D |
| 4 | Compare | Decide pass/fail per case | actual objects, expected objects | Exact ordered equality of `{sequence, value}` lists; for error cases require rc != 0, non-empty stderr, empty stdout | Verdict + diff | Mismatch: **fail** (decode failure, distinct from build failure) | D |
| 4b | Expected-object derivation | Spec-derived oracle, independent of the program under test | field lists, noise bytes, spec resync rules | Compute expected output from the fields by hand-written rules, never from the exe | Expected list | Oracle disagrees with the spec examples | D for simple cases; M for the design of the oracle; H if the spec is ambiguous |
| 5 | Locate the defect | Find the source lines that contradict the spec | Source, failing reproductions, spec | Read the source: state lifetime, integer widening, resync discards | Diagnosis | n/a | M |
| 6 | Repair | Minimal edit to `parser.c` only | Diagnosis | Edit the source | Changed `parser.c` | Preserved file touched; special-casing; hard-coded response | M (automation must never contain a repaired parser) |
| 7 | Choose the check set | Cover a narrow fix | Spec, defect classes | Select cases: whole vs split at every boundary, min/max, positive/negative, bad checksum, noise + stray header, incomplete tail, empty/no-argument, upper/lower hex, malformed input | Check matrix | n/a | M (choice and adequacy), D (execution) |
| 7b | Whole/split equivalence | Boundaries must not change the result | Stream bytes | Run the whole stream and every 2-way split (plus an all-single-byte split); compare to the whole result and to the expected value | Per-schedule verdicts | Any schedule differs | D |
| 7c | Malformed CLI input | Check rejection before any stdout | odd-length, non-hex, over-limit chunk | Run; check rc != 0, stderr non-empty, stdout empty | Verdict | Any condition violated | D |
| 7d | Stale-exe protection | A failed build must not run an old binary | Source with deliberate compile error in a scratch copy | Place a sentinel exe, run a failing build, confirm the exe is removed or not run and the result is `build_failed` | Verdict | Old exe executed | D (run on a temp copy only; never modify the workspace source) |
| 8 | Preservation | Only the source differs | Baseline and current digests | Compare digests of `parser.h`, `main.c`, `requirements.md`, `case.json` | Pass/fail | Any change | D |
| 9a | Evidence record | Reproducible, requirement-linked record | All results above | Write JSON with the source digest, command, input chunks, expected, actual, process result, timestamps, and requirement ID; append-only (new file or merge without overwriting the original baseline) | `evidence/*.json` | Cannot write; overwrite attempted | D |
| 9b | Explanation | Why the repair works; why the checks are adequate; limits | Evidence | Write the narrative | Report | n/a | M |
| 10 | Instructor/external check | Independent protocol verdict | Path supplied only if permitted | Run only if explicitly allowed | Verdict or "not run" | Not permitted: record "not run"; never claim a protocol pass from own checks | H (permission); D (run) |
| 11 | Judge completion | Accept or reject the work | All evidence | Review the explanation and automation quality | Decision | n/a | H |
| 12 | Resolve a new ambiguous requirement | Spec silent or contradictory | Spec | Decide the interpretation | Decision | n/a | H |

## Proposed function contracts (implement in stage 4; none implemented now)

All live under `automation/`. "Record" means a JSON-serializable dict. Common fields: `status` in `{pass, fail, build_failed, blocked, error}`, `command` (argv list), `rc`, `stdout`, `stderr`, `source_sha256`.

| Function | Input | Output | Errors / notes |
|---|---|---|---|
| `load_workspace(workspace) -> Record` | Absolute path | `{workspace, lab, case, paths{parser_c, parser_h, main_c, spec, exe, evidence}}` | Missing files or wrong lab → `blocked` with the reason; no exception |
| `sha256_file(path) -> str` | Path | Hex digest | Missing file → `None`, recorded by the caller |
| `snapshot_files(paths) -> dict` | List of paths | `{path: digest}` | Used for the preserved-file check |
| `read_example(spec_text, case) -> Record` | `requirements.md` text and the case name | `{bytes_hex, sequence, value}` | No example for the case → `blocked` |
| `build_candidate(src_dir, exe_path, compiler_cmd=None) -> Record` | Source dir, exe path, optional argv template | `{status, command, rc, stdout, stderr, source_sha256, exe_exists, started, finished}` | Removes the stale exe before compiling; compiler absent → `blocked`; rc != 0 → `build_failed` and the exe is removed; it must be impossible to replay after a non-pass build |
| `checksum(first_five: bytes) -> int` | 5 bytes | XOR as 0..255 | Raises `ValueError` if length != 5 |
| `build_packet(sequence, value, bad_checksum=False) -> bytes` | seq 0..255, value -32768..32767 | 6 bytes, or 6 bytes with a deliberately wrong checksum | Out-of-range → `ValueError` |
| `split_stream(data, cuts) -> list[str]` | Bytes, sorted offsets within 0..len | Hex chunks (empty chunks are kept, each ≤ 4096 bytes) | Invalid cuts → `ValueError` |
| `all_splits(data, mode) -> list[list[int]]` | Bytes, `two_way`/`single_byte` | Cut-offset schedules | Deterministic order |
| `expected_frames(stream_model) -> list[dict]` | Independent oracle input: sequence of ("frame", seq, value), ("noise", bytes), ("bad", seq, value), ("tail", bytes) | Ordered `[{sequence, value}]` computed from the spec resync rules, never by the exe | Documents the oracle rules; mismatches with the spec examples are `error` |
| `replay_stream(exe, chunks, timeout_s) -> Record` | Exe path, hex chunks | `{command, chunks, rc, stdout, stderr, actual (parsed list or None), parse_error}` | Refuses to run if the build status is not `pass`; subprocess without a shell; timeout → `error` |
| `compare_results(expected, actual) -> Record` | Two lists of objects | `{equal, expected, actual, first_diff}` | Exact order and key equality; types are checked (`int`) |
| `check_rejects_malformed(exe, chunks) -> Record` | Exe, bad chunk list | `{rc_nonzero, stderr_nonempty, stdout_empty, status}` | Any violated condition → `fail` |
| `run_case(case_def, exe) -> Record` | `{id, requirement, model, schedules}` | Per-schedule replay + comparison; case status = fail if any schedule fails | Includes requirement ID |
| `check_stale_exe_protection(workspace_copy) -> Record` | Temporary copy only | Verdict that a failed build leaves no runnable stale exe | Never touches the workspace source |
| `verify_preserved(baseline, current) -> Record` | Two digest maps | `{unchanged: bool, changed: [paths]}` | Baseline stored once, never overwritten |
| `write_evidence(evidence_dir, name, record) -> path` | Dir, name, record | Path written | Refuses to overwrite an existing baseline; creates new files; stamps UTC time |
| `render_report(records) -> str` | All results | Text summary with per-requirement table, blocked/failed items kept visible, "instructor check: not run" unless a result is supplied | Overall `pass` only if every check passes |
| `main(argv) -> int` (`guardrails.py --workspace`) | Absolute workspace path | Exit 0 only if the build and every check pass; otherwise nonzero | Idempotent; never edits `parser.c`; non-interactive; verbose action/result output |

## Notes for stage 4

- Helpers carry no repaired parser and no fixture-style hard-coded CLI response.
- The spec invariants (six-byte layout, signed range, XOR checksum, streaming/resync rules) are constants in the oracle, not parameters; everything else (source dir, compiler, exe, fields, schedules, evidence dir) is a parameter.
- Resync edge cases (wrong length after the header, bad checksum hiding a partial candidate, header byte inside a valid payload) need oracle cases beyond the workflow's observed session; the oracle must follow `requirements.md` literally.
- Instructor checker: not run and not read in this rehearsal; recorded as "not run".
{"lab": "fw2", "case": "demo"}
evidence:
session.md
stage1-execution.json
stage1-prompt.txt
stage1-response.txt
stage1-transcript.md
stage2-execution.json
stage2-prompt.txt
stage2-response.txt
stage2-transcript.md
stage3-execution.json
stage3-prompt.txt
stage3-response.txt
stage3-transcript.md
stage4-prompt.txt
stage4-response.txt

fw2:
main.c
parser
parser.c
parser.h
#include "parser.h"
#include <string.h>

static void discard_first(Parser *p) {
    --p->used;
    memmove(p->bytes, p->bytes + 1, p->used);
}

void parser_feed(Parser *p, const uint8_t *data, size_t size, Emit emit) {
    for (size_t i = 0; i < size; ++i) {
        p->bytes[p->used++] = data[i];
        while (p->used) {
            if (p->bytes[0] != 0xA5 || (p->used >= 2 && p->bytes[1] != 2)) {
                discard_first(p);
                continue;
            }
            if (p->used < 6) break;
            uint8_t checksum = 0;
            for (size_t j = 0; j < 5; ++j) checksum ^= p->bytes[j];
            if (checksum != p->bytes[5]) {
                discard_first(p);
                continue;
            }
            unsigned raw = p->bytes[3] | ((unsigned)p->bytes[4] << 8);
            int value = (int)(int16_t)(uint16_t)raw;
            emit(p->bytes[2], value);
            p->used = 0;
        }
    }
}
#ifndef PARSER_H
#define PARSER_H
#include <stddef.h>
#include <stdint.h>
typedef struct { uint8_t bytes[6]; size_t used; } Parser;
typedef void (*Emit)(unsigned sequence, int value);
void parser_feed(Parser *p, const uint8_t *data, size_t size, Emit emit);
#endif
#include "parser.h"
#include <stdio.h>
#include <string.h>

static int first = 1;
static void emit(unsigned sequence, int value) {
    printf("%s{\"sequence\":%u,\"value\":%d}", first ? "" : ",", sequence, value);
    first = 0;
}
static int digit(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}
int main(int argc, char **argv) {
    for (int a = 1; a < argc; ++a) {
        size_t n = strlen(argv[a]);
        if (n % 2 || n > 8192) { fputs("invalid chunk length\n", stderr); return 2; }
        for (size_t i = 0; i < n; ++i)
            if (digit(argv[a][i]) < 0) { fputs("invalid hex\n", stderr); return 2; }
    }
    Parser parser = {{0}, 0};
    putchar('[');
    for (int a = 1; a < argc; ++a) {
        uint8_t bytes[4096];
        size_t n = strlen(argv[a]) / 2;
        for (size_t i = 0; i < n; ++i)
            bytes[i] = (uint8_t)((digit(argv[a][2*i]) << 4) | digit(argv[a][2*i+1]));
        parser_feed(&parser, bytes, n, emit);
    }
    puts("]");
    return 0;
}
?? ../../
<shellId: 1 completed with exit code 0>
```

</details>


---

<sub>7s</sub>

### `bash` — Failed

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && cat workflow.md; cmp workflow.md workflow-md-only.md && echo same; head -c 600 evidence/session.md; python3 --version; which gcc**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && cat workflow.md; cmp workflow.md workflow-md-only.md && echo same; head -c 600 evidence/session.md; python3 --version; which gcc

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>9s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && cat workflow.md**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && cat workflow.md

<details>
<summary>64 lines</summary>

```
# Workflow: reproduce, repair and verify a streaming packet parser

Reusable for any workspace prepared for this lab (any case). Derived from one observed session; incident values are inputs, not constants.

## Named inputs (validate before use)
| Input | Source / validation | If missing or invalid |
| --- | --- | --- |
| `WORKSPACE` | Absolute directory containing the files below; resolve every path from it, not from cwd | Stop; report |
| `SPEC` | `requirements.md` in `WORKSPACE`; the sole protocol authority | Stop; never infer the protocol from the code or its output |
| `CASE` | `case.json` (`lab`, `case`); must be `fw2` | Stop on other labs |
| `SRC_DIR`, `SOURCE` | `SRC_DIR/parser.c`: the only file to edit | Stop |
| `PRESERVED` | `parser.h`, `main.c`, `SPEC`, `case.json`; record their digests before work and compare at the end | Edit none of them; if a change looks necessary, report it as a blocker |
| `COMPILER_CMD` | Default `gcc -std=c11 -Wall -Wextra -Werror <SOURCE> <main.c> -o <EXE>`; the compiler must exist | Report a blocked build; do not substitute another toolchain silently |
| `EXE` | Generated binary path, treated as untrusted output | Derive from `SRC_DIR`; delete or ignore a stale one on build failure |
| `EXAMPLE` | The packet example for `CASE` read from `SPEC` (sequence, value, bytes) | Stop reproduction; do not copy values from an earlier case |
| `CHUNK_SCHEDULE` | Lists of even-length hex chunk strings (each chunk = one CLI argument) | Use at least: whole packet, split in two at every byte boundary of `EXAMPLE` |
| `EVIDENCE_DIR` | Destination for the session record (default `evidence/`) | Create it; never overwrite earlier evidence, append or use a new file |
| `INSTRUCTOR_CHECK` | External checker, only if explicitly permitted and its path supplied | Do not search for or read it; record "not run" |

## Specification invariants (take values from `SPEC`; do not weaken)
- Packet is six bytes: header, length byte, sequence, value low, value high, checksum. Sequence is unsigned 8-bit. The value is signed 16-bit two's-complement, little-endian. The checksum is the XOR of the first five bytes.
- One parser state per stream; every feed call continues that stream. Chunk boundaries (including empty chunks) must not change the decoded result. A fresh process is a fresh stream. There is no timeout behavior.
- Resynchronization exactly as in `SPEC`: discard to the header byte; a wrong length discards only the leading header byte; a checksum failure discards only the first byte and rescans the rest, keeping a possible partial candidate; success emits once and consumes six bytes; header bytes inside a valid frame are data; an incomplete tail emits nothing.
- CLI contract from `SPEC`: malformed, odd-length or over-limit chunks exit nonzero with stderr and no stdout; no arguments give `[]`; success prints a JSON array of `{sequence, value}`.
- Expected values always come from `SPEC` and hand computation, never from the program under test.

## Steps
1. **Validate inputs.** Confirm every item above; record source digests. Read `SPEC` fully before touching code.
2. **Build** with `COMPILER_CMD`; capture the command, exit status, stdout and stderr. A build failure is its own result (not a decode failure): stop and never run an older `EXE`. A passing build shows only that the code compiles, not that the protocol is right.
3. **Reproduce before editing.** Run `EXAMPLE` as the whole stream and over each `CHUNK_SCHEDULE` split. Save the command, arguments, rc, stdout and stderr, and the expected object from `SPEC`. Unexpected failures stay recorded as failures.
4. **Inspect** the source against `SPEC`, one question at a time:
   a. Is partial-packet state kept across feed calls (lifetime and any reset at the start of a call; any per-call locals)?
   b. How are the value bytes combined and widened (width, signedness, conversion to the output type)?
   c. Does the resynchronization logic match the contract (discard counts, rescan, partial candidate preserved)?
   Explain each finding against `SPEC`. Change only what contradicts it.
5. **Repair minimally** in `SOURCE` only. Do not add result-specific special cases or hard-coded responses.
6. **Rebuild** (step 2) and repeat the step 3 reproductions. Rebuild after every source change.
7. **Broaden checks** so a narrow repair cannot pass. Build each stream from fields, compute the checksum by hand or by an independent routine, and run each both whole and split at every boundary:
   - positive value; negative value; minimum -32768 and maximum 32767;
   - bad checksum gives nothing;
   - valid frame after noise, including a stray header byte before it;
   - incomplete tail gives nothing, while earlier complete frames still emit;
   - no arguments, an empty chunk, and uppercase and lowercase hex;
   - odd length and non-hex input give nonzero rc, stderr, empty stdout.
8. **Verify preservation:** `PRESERVED` digests unchanged; only `SOURCE` differs; the generated `EXE` is not claimed as evidence.
9. **Record** in `EVIDENCE_DIR`: each command with its reason, rc and outputs; expected vs actual per check; edited lines; explanation (why compiling is not correctness, why chunk boundaries must not matter, the two's-complement conversion); limits and what was not run.

## Missing-input and blocked behavior
- Missing or invalid input: follow the table; report a blocked result rather than guessing or fabricating evidence.
- Compiler unavailable or build fails: report blocked or failed with the captured output; keep it visible.
- `INSTRUCTOR_CHECK` not provided or not permitted: state it was not run. Never claim a protocol pass from own checks alone.
- Environment refuses a command: split it into simpler commands and note it.
- Expected-failure results (the pre-repair reproductions) are evidence; keep them.

## Diagnosis hints
- Whole passes but split fails: partial state is lost across calls.
- Magnitude wrong or positive for a negative value: width or signedness of the conversion.
- Extra or missing frames after noise or bad checksum: compare with the resync contract.
- A fix works for the example only: the broadened checks in step 7 should fail it.

## Completion criteria
- Build exits 0 under the stated flags; every reproduction and broadened check matches `SPEC`-derived expectations.
- `PRESERVED` files unchanged; the explanation is recorded; limits are stated.

## Untested branches (not exercised in the observed session)
- Build-failure path and stale-executable protection.
- Another case (the transfer case) and a candidate whose defects differ from those observed.
- Resynchronization edge cases: wrong length byte after a header, a checksum failure that hides a partial candidate, a header byte inside a valid payload.
- Empty chunks, uppercase hex, and the maximum chunk size (reject an oversized chunk).
- Independent instructor/protocol checker and the facilitator rubric.
- Any automation; deterministic steps (build capture, packet construction and splitting, replay, comparison, records) are candidates for later stages only.
<shellId: 3 completed with exit code 0>
```

</details>


---

<sub>9s</sub>

### `bash` — Failed

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && cmp workflow.md workflow-md-only.md && echo same; python3 --version; which gcc**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && cmp workflow.md workflow-md-only.md && echo same; python3 --version; which gcc

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>11s</sub>

### `bash` — Failed

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo; cmp workflow.md workflow-md-only.md; python3 --version; which gcc; git -C . log --oneline | head -3**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo; cmp workflow.md workflow-md-only.md; python3 --version; which gcc; git -C . log --oneline | head -3

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>13s</sub>

### Copilot

Splitting into simpler commands.

---

<sub>13s</sub>

### `bash`

**python3 --version**

$ python3 --version

```
Python 3.12.15
<shellId: 6 completed with exit code 0>
```


---

<sub>13s</sub>

### `bash`

**which gcc**

$ which gcc

```
/usr/bin/gcc
<shellId: 7 completed with exit code 0>
```


---

<sub>1m 23s</sub>

### `create` — Failed

**create a new file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/fw2_tools.py.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/fw2_tools.py

```
Parent directory does not exist
```


---

<sub>1m 25s</sub>

### `bash`

**mkdir -p /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/tests/fixtures/{state_loss,unsigned_value,compile_error}**

$ mkdir -p /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/tests/fixtures/{state_loss,unsigned_value,compile_error}

```

<shellId: 8 completed with exit code 0>
```


---

<sub>2m 18s</sub>

### `create`

**create a new file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/fw2_tools.py.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/fw2_tools.py

```
Created file /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/fw2_tools.py with 23878 characters
```


---

<sub>2m 18s</sub>

### `create`

**create a new file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/guardrails.py.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/guardrails.py

```
Created file /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/guardrails.py with 3132 characters
```


---

<sub>2m 27s</sub>

### `edit`

**edit the file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/guardrails.py.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/guardrails.py

```
File /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/guardrails.py updated with changes.
```


---

<sub>2m 27s</sub>

### `edit`

**edit the file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/guardrails.py.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/guardrails.py

```
File /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/guardrails.py updated with changes.
```


---

<sub>2m 27s</sub>

### `create`

**create a new file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/tests/fixtures/state_loss/parser.c.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/tests/fixtures/state_loss/parser.c

```
Created file /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/tests/fixtures/state_loss/parser.c with 1003 characters
```


---

<sub>2m 27s</sub>

### `create`

**create a new file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/tests/fixtures/unsigned_value/parser.c.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/tests/fixtures/unsigned_value/parser.c

```
Created file /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/tests/fixtures/unsigned_value/parser.c with 975 characters
```


---

<sub>2m 27s</sub>

### `create`

**create a new file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/tests/fixtures/compile_error/parser.c.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/tests/fixtures/compile_error/parser.c

```
Created file /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/tests/fixtures/compile_error/parser.c with 198 characters
```


---

<sub>2m 46s</sub>

### `create`

**create a new file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/tests/test_fw2_automation.py.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/tests/test_fw2_automation.py

```
Created file /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/tests/test_fw2_automation.py with 7347 characters
```


---

<sub>2m 48s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && python3 -m unittest discover -s automation/tests -v 2>&1 | tail -40**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && python3 -m unittest discover -s automation/tests -v 2>&1 | tail -40

<details>
<summary>6 lines</summary>

```
Shell output was automatically compacted. Compacted output below. Original at /tmp/original-output-1791993144608-e4aa4e5572984c639c2607008aaefa0d.txt; only use if exact omitted lines are needed.

[unittest progress: omitted 13 non-diagnostic line(s)]

[unittest progress: omitted 1 non-diagnostic line(s)]
Ran 13 tests in 1.416s

OK

<shellId: 9 completed with exit code 0>
```

</details>


---

<sub>2m 50s</sub>

### Copilot

Tests pass. Now the real guardrails run, twice, plus source digest check.

---

<sub>2m 50s</sub>

### `bash` — Failed

**cd /tmp && W=/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo; sha256sum $W/fw2/parser.c; python3 $W/automation/guardrails.py --workspace $W | tail -45; echo rc=$?; python3 $W/automation/guardrails.py --workspace $W >/dev/null; echo rc2=$?; sha256sum $W/fw2/parser.c; ls $W/evidence**

$ cd /tmp && W=/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo; sha256sum $W/fw2/parser.c; python3 $W/automation/guardrails.py --workspace $W | tail -45; echo rc=$?; python3 $W/automation/guardrails.py --workspace $W >/dev/null; echo rc2=$?; sha256sum $W/fw2/parser.c; ls $W/evidence

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>2m 53s</sub>

### `bash` — Failed

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && python3 automation/guardrails.py --workspace "$PWD" > /tmp/g1.txt; echo rc=$?; tail -32 /tmp/g1.txt**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo && python3 automation/guardrails.py --workspace "$PWD" > /tmp/g1.txt; echo rc=$?; tail -32 /tmp/g1.txt

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>2m 55s</sub>

### `bash`

**python3 automation/guardrails.py --workspace /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo**

$ python3 automation/guardrails.py --workspace /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo

<details>
<summary>69 lines</summary>

```
ACTION build: expect rc 0 under -Wall -Wextra -Werror (compiling does not prove the protocol)
RESULT build: status=pass rc=0 source_digest=f085db0dc024
ACTION case example (9 schedules), expected=[{'sequence': 7, 'value': -123}]
RESULT case example: pass
ACTION case positive (9 schedules), expected=[{'sequence': 3, 'value': 1234}]
RESULT case positive: pass
ACTION case negative (9 schedules), expected=[{'sequence': 4, 'value': -1}]
RESULT case negative: pass
ACTION case signed_min (9 schedules), expected=[{'sequence': 5, 'value': -32768}]
RESULT case signed_min: pass
ACTION case signed_max (9 schedules), expected=[{'sequence': 6, 'value': 32767}]
RESULT case signed_max: pass
ACTION case sequence_a5_and_payload_a5 (9 schedules), expected=[{'sequence': 165, 'value': -23131}]
RESULT case sequence_a5_and_payload_a5: pass
ACTION case bad_checksum (9 schedules), expected=[]
RESULT case bad_checksum: pass
ACTION case noise_then_frame (12 schedules), expected=[{'sequence': 10, 'value': -300}]
RESULT case noise_then_frame: pass
ACTION case incomplete_tail (12 schedules), expected=[{'sequence': 11, 'value': 5}]
RESULT case incomplete_tail: pass
ACTION case two_frames (15 schedules), expected=[{'sequence': 13, 'value': 7}, {'sequence': 14, 'value': -7}]
RESULT case two_frames: pass
ACTION case stray_header_then_frame (10 schedules), expected=[{'sequence': 7, 'value': -123}]
RESULT case stray_header_then_frame: pass
ACTION case wrong_length_then_frame (11 schedules), expected=[{'sequence': 7, 'value': -123}]
RESULT case wrong_length_then_frame: pass
ACTION case bad_checksum_hides_frame (12 schedules), expected=[{'sequence': 7, 'value': -123}]
RESULT case bad_checksum_hides_frame: pass
ACTION case frame_twice (15 schedules), expected=[{'sequence': 7, 'value': -123}, {'sequence': 7, 'value': -123}]
RESULT case frame_twice: pass
RESULT malformed odd_length: pass (expected rc!=0, stderr text, empty stdout)
RESULT malformed non_hex: pass (expected rc!=0, stderr text, empty stdout)
RESULT malformed oversize_chunk: pass (expected rc!=0, stderr text, empty stdout)
RESULT malformed bad_after_good: pass (expected rc!=0, stderr text, empty stdout)
RESULT cli no_arguments: pass
RESULT cli empty_chunks: pass
RESULT cli lowercase_hex: pass
RESULT cli max_chunk_accepted: pass
RESULT stale_exe_protection: pass
ACTION preservation: first run, recorded baseline digests
FW2 verification: PASS
  build: pass
  [pass] example (R-STREAM)
  [pass] positive (R-VALUE)
  [pass] negative (R-VALUE)
  [pass] signed_min (R-VALUE)
  [pass] signed_max (R-VALUE)
  [pass] sequence_a5_and_payload_a5 (R-HEADER-DATA)
  [pass] bad_checksum (R-CHECKSUM)
  [pass] noise_then_frame (R-RESYNC)
  [pass] incomplete_tail (R-TAIL)
  [pass] two_frames (R-STREAM)
  [pass] stray_header_then_frame (R-RESYNC)
  [pass] wrong_length_then_frame (R-RESYNC)
  [pass] bad_checksum_hides_frame (R-RESYNC)
  [pass] frame_twice (R-STREAM)
  [pass] malformed_odd_length (R-CLI)
  [pass] malformed_non_hex (R-CLI)
  [pass] malformed_oversize_chunk (R-CLI)
  [pass] malformed_bad_after_good (R-CLI)
  [pass] no_arguments (R-CLI)
  [pass] empty_chunks (R-CLI)
  [pass] lowercase_hex (R-CLI)
  [pass] max_chunk_accepted (R-CLI)
  [pass] stale_exe_protection (R-BUILD)
  [pass] preserved_files (R-PRESERVE)
  instructor check: not run (not permitted in this workspace)
evidence written: /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/evidence/fw2-verification.json
<shellId: 12 completed with exit code 0>
```

</details>


---

<sub>2m 57s</sub>

### Copilot

Repeat run (idempotence) and digest check; then update docs.

---

<sub>2m 57s</sub>

### `bash` — Failed

**sha256sum fw2/parser.c; python3 automation/guardrails.py --workspace /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo | grep -E "preservation|verification:"; echo "rc=${PIPESTATUS[0]}"; sha256sum fw2/parser.c; ls evidence**

$ sha256sum fw2/parser.c; python3 automation/guardrails.py --workspace /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo | grep -E "preservation|verification:"; echo "rc=${PIPESTATUS[0]}"; sha256sum fw2/parser.c; ls evidence

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>2m 59s</sub>

### `bash` — Failed

**sha256sum fw2/parser.c**

$ sha256sum fw2/parser.c

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>3m 0s</sub>

### `bash`

**python3 automation/guardrails.py --workspace /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo | tail -5**

$ python3 automation/guardrails.py --workspace /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo | tail -5

<details>
<summary>6 lines</summary>

```
[pass] max_chunk_accepted (R-CLI)
  [pass] stale_exe_protection (R-BUILD)
  [pass] preserved_files (R-PRESERVE)
  instructor check: not run (not permitted in this workspace)
evidence written: /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/evidence/fw2-verification.json
<shellId: 15 completed with exit code 0>
```

</details>


---

<sub>3m 0s</sub>

### `bash` — Failed

**sha256sum fw2/parser.c; ls evidence**

$ sha256sum fw2/parser.c; ls evidence

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>3m 3s</sub>

### `bash`

**python3 -c "
import json;d=json.load(open('evidence/fw2-verification.json'));print(d['status'],d['build']['source']['combined'][:12],d['build']['source']['files']['parser.c'][:12])"**

$ python3 -c "
import json;d=json.load(open('evidence/fw2-verification.json'));print(d['status'],d['build']['source']['combined'][:12],d['build']['source']['files']['parser.c'][:12])"

```
pass f085db0dc024 bf29c4ebfc7a
<shellId: 17 completed with exit code 0>
```


---

<sub>3m 3s</sub>

### `glob`

**evidence/***

"evidence/*"

<details>
<summary>17 matches</summary>

```
./evidence/stage2-execution.json
./evidence/stage3-execution.json
./evidence/stage1-transcript.md
./evidence/fw2-verification.json
./evidence/stage3-prompt.txt
./evidence/stage3-transcript.md
./evidence/stage2-prompt.txt
./evidence/fw2-preserved-baseline.json
./evidence/stage1-execution.json
./evidence/stage2-response.txt
./evidence/stage3-response.txt
./evidence/session.md
./evidence/stage4-response.txt
./evidence/stage4-prompt.txt
./evidence/stage1-response.txt
./evidence/stage1-prompt.txt
./evidence/stage2-transcript.md
```

</details>


---

<sub>3m 12s</sub>

### `create`

**create a new file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/README.md.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/README.md

```
Created file /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/automation/README.md with 2440 characters
```


---

<sub>3m 12s</sub>

### `bash`

**tail -c 300 workflow.md**

$ tail -c 300 workflow.md

```
s, uppercase hex, and the maximum chunk size (reject an oversized chunk).
- Independent instructor/protocol checker and the facilitator rubric.
- Any automation; deterministic steps (build capture, packet construction and splitting, replay, comparison, records) are candidates for later stages only.
<shellId: 18 completed with exit code 0>
```


---

<sub>3m 19s</sub>

### `edit`

**edit the file at /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/workflow.md.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/workflow.md

```
File /home/runner/work/ABB-Training/ABB-Training/runs/fw2/demo/workflow.md updated with changes.
```


---

<sub>3m 23s</sub>

### `bash` — Failed

**rm -rf automation/__pycache__ automation/tests/__pycache__; python3 -c "
import os;print(os.path.exists('workflow-md-only.md'))"**

$ rm -rf automation/__pycache__ automation/tests/__pycache__; python3 -c "
import os;print(os.path.exists('workflow-md-only.md'))"

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>3m 24s</sub>

### `glob`

**automation/**/__pycache__**

"automation/**/__pycache__"

```
No files matched the pattern.
```


---

<sub>3m 30s</sub>

### Copilot

Stage 4 automation is in place and verified.

**Results (actually run)**
- `python3 -m unittest discover -s automation/tests -v`: 13 tests passed.
- `python3 automation/guardrails.py --workspace <abs path>` exited 0 on the current `fw2/parser.c`: build passed and all 24 checks passed. A second run also reported PASS, with the same source digest recorded both times, so `parser.c` is unchanged.
- The instructor checker was not run, and the report says so.

**Added under `automation/`**
- `guardrails.py`: the common entry point. Exit codes: 0 pass, 1 check failed, 2 build failed, 3 blocked.
- `fw2_tools.py`: the helpers from `extraction-map.md`. They build, construct and split packets, replay streams, and compare against a spec-derived oracle. They contain no parser.
- `tests/test_fw2_automation.py`, with altered fixtures in `tests/fixtures/` (lost state, unsigned conversion, compile error). The tests also cover the valid parser, a wrong-lab workspace, a missing compiler, and a tampered preserved file.
- `README.md` with the exact commands.

**Evidence and docs**
- `evidence/fw2-verification.json` is regenerated each run.
- `evidence/fw2-preserved-baseline.json` is written once and compared on later runs.
- Stage 1–3 evidence is untouched.
- `workflow.md` now explains how to call the helpers and read their exit codes. `workflow-md-only.md` was not edited.

Some shell commands (such as `sha256sum` and `cmp`) were denied, so I checked source preservation through the digests recorded in the evidence JSON. I did not do a byte comparison of `workflow.md` against `workflow-md-only.md`.

---

<sub>Generated by [GitHub Copilot CLI](https://github.com/features/copilot/cli)</sub>
