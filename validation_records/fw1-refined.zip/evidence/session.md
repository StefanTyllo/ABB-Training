# Session log: FW1 refined run

## Review finding
`capture_state` built raw primitive records, but guardrails/experiment discarded them in normal execution, so only `baseline.json` and a summary were retained. The initial rehearsal also fell back to manual device operations after compound shell commands (echo/tail) were denied.

## Revision
- `experiment.py` now persists `evidence/capture-before.json` (exclusive create) BEFORE the `set`; if it cannot be saved the run is BLOCKED with no write.
- `mutation.json` (full `run_primitive` record of the one `set`) and `capture-after.json` are saved by exclusive create. Reruns never overwrite them; healthy reruns write only `verification-latest.json`.
- `guardrails.py` verifies baseline and original artifacts are byte-identical across a rerun.
- Baseline-required and stale-baseline gates kept; simulator and reference untouched.

## Tests
`python3 -m unittest discover -v automation/tests`: 18 tests OK on disposable temp workspaces only (the active device was not used).
- Real subprocess checks (CLI on temp workspaces): retained evidence and ordering, unwritable before-path means no mutation, missing baseline, stale baseline, rerun preservation, plus earlier blocked-input/unknown-identity/altered-reference checks.
- Unit checks (in-process; device.py still a real subprocess): before file exists when `set` runs, injected persistence failure issues no `set`, failed verification is FAIL.
- Not covered: rejected `set`, post-write probe failure end to end, save failure after the write. This is not full end-to-end coverage.

## Actual recovery (atomic commands, each one python3 call)
Run 1: `python3 automation/guardrails.py --workspace /home/runner/work/ABB-Training/ABB-Training/runs/fw1-refined` -> exit OK.
- Observed before: SIM-083, fw 1.4.2, baud 9600, faults ["LINK_TIMEOUT"], logs ["boot: link timeout"], probe ok:false (timeout).
- Baseline written by code, then reference entry 'transfer' matched, target_baud 38400.
- capture-before.json saved, then the single `set` -> `{"parameter": "baud", "old": 9600, "new": 38400}`, mutation.json and capture-after.json saved by code.
- After: baud 38400, faults [], logs ["boot: link timeout", "baud changed: 9600 -> 38400"], probe ok:true (reply). All 7 verify checks PASS.
- The old "boot: link timeout" log is history; the fault register is empty, so no active fault remains.

Run 2 (idempotence): same command -> NOOP, no write, baseline sha256 unchanged (19baaeb3...dd23a); guardrails-result.json reports original_artifacts_preserved.changed = [] for baseline, capture_before, capture_after, mutation. Only verification-latest.json was (re)written.

No device.py set was run directly, state.json not edited, no evidence faked by hand. `workflow-md-only.md` unchanged.
