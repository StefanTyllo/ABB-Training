# FW1 automation

All helpers live under `automation/` and take the workspace via `--workspace` (absolute path); nothing is resolved from the caller's cwd. Exit codes: `0` OK/NOOP, `1` FAIL/ERROR, `2` BLOCKED/INVALID.

| File | Role |
|---|---|
| `guardrails.py` | Common entry point: baseline (once, before any write) -> gated experiment -> baseline-preserved check. Writes `evidence/guardrails-result.json`. |
| `capture_state.py` | Read-only capture of identity, firmware, config, faults, logs, probe (raw stdout, rc, UTC timestamp, input identity). Also holds shared helpers. |
| `experiment.py` | One gated `set --parameter baud` using the target from the identity-matched `fw1/expected.json` entry; verify before/after. |
| `tests/` | Checks on disposable workspaces; altered fixtures in `tests/fixtures/`. |

## Commands (run from the workspace root)

```bash
# Common entry point (idempotent; safe to repeat)
python3 automation/guardrails.py --workspace "$PWD"

# Capture only, read-only; add --save-baseline to save evidence/baseline.json
# (only if absent and the device is still faulted)
python3 automation/capture_state.py --workspace "$PWD" [--save-baseline] [--output capture.json]

# Controlled experiment (needs a valid baseline for the same device)
python3 automation/experiment.py --workspace "$PWD"

# Checks (each builds its own disposable workspace; demo state is not touched)
python3 -m unittest discover -v automation/tests
```

## Retained evidence (written by the code, not by hand)
| File | Content | Written |
|---|---|---|
| `evidence/baseline.json` | five primitive outputs, original state | once, before any write |
| `evidence/capture-before.json` | full capture (`complete`, `input_identity`, `timestamp_utc`, `records` for identity/firmware/config/faults/logs/probe; each record: `argv`, `timestamp_utc`, `returncode`, `stdout_raw`, `stderr`, `parsed`, `valid`) | exclusive create, BEFORE the `set`; if it cannot be saved the run is `BLOCKED` with no write |
| `evidence/mutation.json` | full `run_primitive` record of the single `set` | exclusive create right after the `set` |
| `evidence/capture-after.json` | same structure as before, after the change | exclusive create after the `set` |
| `evidence/verification-latest.json` | capture + verdict of a healthy rerun | replaced each rerun; originals above stay byte-identical |

Existing originals are never overwritten. A leftover `capture-before.json` with a still-faulted device blocks the run (no write); resolve by hand-reviewing, not by deleting blindly.

## Test coverage (be precise)
- **Subprocess (CLI run on disposable temp workspaces):** full retention and ordering via `guardrails.py`; unwritable before-path leaves device unchanged; missing baseline; stale baseline; rerun preserves all originals and device state; plus earlier checks (blocked inputs, unknown identity, altered reference, no fabricated baseline).
- **Unit (in-process, device.py still a real subprocess):** before capture exists on disk at the moment `set` runs; injected persistence failure means no `set` is issued; failed verification reported as FAIL.
- Not covered: rejected `set`, post-write probe failure end to end, failure of `mutation.json`/`capture-after.json` saves after a write, concurrent runs. Tests never touch the active device.

## Behavior
- Missing workspace/state dir/tool/reference: `BLOCKED`, no write.
- Capture with any failed read is never saved as baseline.
- Unknown identity or firmware mismatch cannot select a reference: `BLOCKED`.
- No baseline: experiment `BLOCKED`. Baseline missing on an already healthy device: `ERROR` (history is not fabricated).
- Config differs from baseline before a write: `BLOCKED` (stale; capture again).
- At most one `set` per run. Healthy device at target: verify only (`NOOP`); baseline and `device/state.json` stay byte-identical.
- Verification: baud == target, faults empty, probe ok, original logs preserved, exactly one `baud changed: <old> -> <target>` entry. Any failed check is `FAIL`.
- Interpretation of the fault, unfamiliar faults, and explaining why historic logs are not an active fault stay with the engineer.
