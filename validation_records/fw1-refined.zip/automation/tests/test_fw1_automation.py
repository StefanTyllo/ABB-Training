"""Checks for the FW1 automation, run against disposable workspaces.

Each test builds a throwaway workspace in a temp dir (copy of fw1/device.py and
expected.json plus ``init --case transfer``), so the demo evidence and state are
never touched.  Run: python3 -m unittest discover -v automation/tests
"""
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
AUTOMATION = HERE.parent
DEMO = AUTOMATION.parent
FIXTURES = HERE / "fixtures"
sys.path.insert(0, str(AUTOMATION))
import capture_state as cs  # noqa: E402
import experiment as ex  # noqa: E402


def make_workspace(case="transfer", expected=None):
    """Create a disposable prepared workspace; returns its Path."""
    root = Path(tempfile.mkdtemp(prefix="fw1-check-"))
    (root / "fw1").mkdir()
    shutil.copy(DEMO / "fw1" / "device.py", root / "fw1" / "device.py")
    shutil.copy(expected or DEMO / "fw1" / "expected.json", root / "fw1" / "expected.json")
    (root / "case.json").write_text(json.dumps({"lab": "fw1", "case": case}))
    subprocess.run([sys.executable, str(root / "fw1" / "device.py"), "--workdir",
                    str(root / "device"), "init", "--case", case], check=True, capture_output=True)
    (root / "evidence").mkdir()
    return root


def run_cli(script, root, *extra):
    """Run an automation script; returns CompletedProcess."""
    return subprocess.run([sys.executable, str(AUTOMATION / script), "--workspace", str(root), *extra],
                          capture_output=True, text=True)


def device(root, *args):
    """Call the low-level tool directly and return parsed JSON."""
    out = subprocess.run([sys.executable, str(root / "fw1" / "device.py"), "--workdir",
                          str(root / "device"), *args], capture_output=True, text=True, check=True)
    return json.loads(out.stdout)


class Fw1AutomationChecks(unittest.TestCase):
    def setUp(self):
        self.dirs = []

    def tearDown(self):
        for d in self.dirs:
            shutil.rmtree(d, ignore_errors=True)

    def workspace(self, **kw):
        root = make_workspace(**kw)
        self.dirs.append(root)
        return root

    def test_valid_capture_saves_complete_baseline(self):
        root = self.workspace()
        res = run_cli("capture_state.py", root, "--save-baseline")
        self.assertEqual(res.returncode, 0, res.stdout + res.stderr)
        baseline = json.loads((root / "evidence" / "baseline.json").read_text())
        self.assertEqual(set(baseline), {"identity", "firmware", "config", "faults", "logs"})
        self.assertEqual(baseline["config"]["baud"], 9600)
        self.assertIn("LINK_TIMEOUT", baseline["faults"])

    def test_missing_state_directory_is_blocked(self):
        root = self.workspace()
        shutil.rmtree(root / "device")
        for script in ("capture_state.py", "experiment.py", "guardrails.py"):
            res = run_cli(script, root)
            self.assertEqual(res.returncode, 2, f"{script}: {res.stdout}")
            self.assertIn("BLOCKED", res.stdout)

    def test_nonexistent_workspace_is_blocked(self):
        res = run_cli("guardrails.py", HERE / "does-not-exist")
        self.assertEqual(res.returncode, 2)

    def test_failed_read_prevents_baseline(self):
        root = self.workspace()
        paths = cs.resolve_paths(root)["paths"]
        capture = cs.capture_state(paths)
        capture["complete"], capture["failed_reads"] = False, ["logs"]
        result = cs.write_baseline(paths, capture)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertFalse((root / "evidence" / "baseline.json").exists())

    def test_unknown_identity_cannot_select_reference(self):
        root = self.workspace(expected=FIXTURES / "expected_unknown_identity.json")
        paths = cs.resolve_paths(root)["paths"]
        result = cs.select_reference(paths["reference"], {"device_id": "SIM-083"}, {"version": "1.4.2"})
        self.assertEqual(result["status"], "BLOCKED")
        before = (root / "device" / "state.json").read_bytes()
        res = run_cli("guardrails.py", root)
        self.assertNotEqual(res.returncode, 0, res.stdout)
        self.assertEqual(before, (root / "device" / "state.json").read_bytes())

    def test_experiment_without_baseline_is_rejected(self):
        root = self.workspace()
        res = run_cli("experiment.py", root)
        self.assertEqual(res.returncode, 2, res.stdout)
        self.assertIn("baseline", res.stdout)
        self.assertEqual(device(root, "read", "--field", "config"), {"baud": 9600})

    def test_stale_baseline_is_rejected(self):
        root = self.workspace()
        run_cli("capture_state.py", root, "--save-baseline")
        device(root, "set", "--parameter", "baud", "--value", "4800")  # drift after baseline
        res = run_cli("experiment.py", root)
        self.assertEqual(res.returncode, 2, res.stdout)
        self.assertIn("stale baseline", res.stdout)
        self.assertEqual(device(root, "read", "--field", "config"), {"baud": 4800})

    def test_correct_change_restores_probe_and_rerun_is_idempotent(self):
        root = self.workspace()
        run_cli("capture_state.py", root, "--save-baseline")
        self.assertFalse(device(root, "probe")["ok"])
        res = run_cli("experiment.py", root)
        self.assertEqual(res.returncode, 0, res.stdout)
        self.assertTrue(device(root, "probe")["ok"])
        self.assertEqual(device(root, "read", "--field", "faults"), [])
        logs = device(root, "logs")
        self.assertEqual(logs, ["boot: link timeout", "baud changed: 9600 -> 38400"])
        state_file, baseline = root / "device" / "state.json", root / "evidence" / "baseline.json"
        snapshot = (state_file.read_bytes(), baseline.read_bytes())
        res = run_cli("guardrails.py", root)
        self.assertEqual(res.returncode, 0, res.stdout)
        self.assertEqual(snapshot, (state_file.read_bytes(), baseline.read_bytes()))

    def test_target_comes_from_reference_not_hardcoded(self):
        root = self.workspace(expected=FIXTURES / "expected_altered_baud.json")
        res = run_cli("guardrails.py", root)
        self.assertEqual(res.returncode, 0, res.stdout)
        self.assertEqual(device(root, "read", "--field", "config"), {"baud": 57600})

    def test_guardrails_refuses_to_fabricate_baseline_on_repaired_device(self):
        root = self.workspace()
        device(root, "set", "--parameter", "baud", "--value", "38400")
        res = run_cli("guardrails.py", root)
        self.assertEqual(res.returncode, 1, res.stdout)
        self.assertFalse((root / "evidence" / "baseline.json").exists())

    def test_failed_verification_is_reported_as_fail(self):
        baseline = {"identity": {"device_id": "X"}, "firmware": {"version": "1"},
                    "config": {"baud": 9600}, "faults": ["LINK_TIMEOUT"], "logs": ["boot: link timeout"]}
        after = dict(baseline, probe={"ok": False, "status": "timeout"})
        verdict = ex.compare_before_after(baseline, after, 38400)
        self.assertEqual(verdict["status"], "FAIL")
        self.assertFalse(next(c for c in verdict["checks"] if c["name"] == "probe_ok")["pass"])


RECORD_KEYS = {"argv", "timestamp_utc", "returncode", "stdout_raw", "stderr", "parsed", "valid"}
CAPTURE_NAMES = {"identity", "firmware", "config", "faults", "logs", "probe"}


class Fw1EvidenceRetentionChecks(unittest.TestCase):
    """Retained raw evidence. Tests marked SUBPROCESS run the CLI end to end on a
    disposable workspace; UNIT tests call functions in-process (device.py is
    still a real subprocess there, only the persistence step is patched).
    Nothing here touches the active device under the workspace root."""

    def setUp(self):
        self.root = make_workspace()
        self.addCleanup(shutil.rmtree, self.root, ignore_errors=True)
        self.ev = self.root / "evidence"

    def assert_full_capture(self, capture):
        self.assertIs(capture["complete"], True)
        self.assertIn("workspace", capture["input_identity"])
        self.assertTrue(capture["timestamp_utc"])
        self.assertEqual(set(capture["records"]), CAPTURE_NAMES)
        for name, rec in capture["records"].items():
            self.assertEqual(set(rec), RECORD_KEYS, name)
            self.assertEqual(rec["returncode"], 0)
            self.assertTrue(rec["valid"])
            self.assertEqual(json.loads(rec["stdout_raw"]), rec["parsed"])

    def test_subprocess_guardrails_retains_raw_evidence_in_order(self):
        res = run_cli("guardrails.py", self.root)
        self.assertEqual(res.returncode, 0, res.stdout + res.stderr)
        before = json.loads((self.ev / "capture-before.json").read_text())
        after = json.loads((self.ev / "capture-after.json").read_text())
        mutation = json.loads((self.ev / "mutation.json").read_text())
        self.assert_full_capture(before)
        self.assert_full_capture(after)
        self.assertEqual(before["records"]["config"]["parsed"], {"baud": 9600})
        self.assertEqual(after["records"]["config"]["parsed"], {"baud": 38400})
        self.assertEqual(set(mutation), RECORD_KEYS)
        self.assertEqual(mutation["argv"][-5:], ["set", "--parameter", "baud", "--value", "38400"])
        self.assertTrue(mutation["valid"])
        self.assertLess(before["timestamp_utc"], mutation["timestamp_utc"])
        self.assertLess(mutation["timestamp_utc"], after["timestamp_utc"])

    def test_unit_before_capture_is_on_disk_when_set_runs(self):
        seen = {}
        real = cs.run_primitive

        def spy(paths, args):
            if args[0] == "set":
                seen["before_exists"] = (self.ev / "capture-before.json").is_file()
            return real(paths, args)

        cs.run_primitive = spy
        try:
            run_cli("capture_state.py", self.root, "--save-baseline")
            result = ex.run_experiment(self.root)
        finally:
            cs.run_primitive = real
        self.assertEqual(result["status"], "OK", result)
        self.assertTrue(seen["before_exists"])

    def test_unit_persistence_failure_blocks_before_any_write(self):
        run_cli("capture_state.py", self.root, "--save-baseline")
        state = self.root / "device" / "state.json"
        snapshot = state.read_bytes()
        calls = []
        real_run, real_save = cs.run_primitive, cs.write_evidence_once

        def spy(paths, args):
            calls.append(args[0])
            return real_run(paths, args)

        def failing(path, document):
            return {"status": "ERROR", "path": str(path), "reason": "injected failure"}

        cs.run_primitive, cs.write_evidence_once = spy, failing
        try:
            result = ex.run_experiment(self.root)
        finally:
            cs.run_primitive, cs.write_evidence_once = real_run, real_save
        self.assertEqual(result["status"], "BLOCKED", result)
        self.assertNotIn("set", calls)
        self.assertFalse(result["wrote_device"])
        self.assertEqual(snapshot, state.read_bytes())

    def test_subprocess_unwritable_before_path_means_no_mutation(self):
        run_cli("capture_state.py", self.root, "--save-baseline")
        (self.ev / "capture-before.json").mkdir()  # makes the exclusive create fail
        state = self.root / "device" / "state.json"
        snapshot = state.read_bytes()
        res = run_cli("experiment.py", self.root)
        self.assertEqual(res.returncode, 2, res.stdout)
        self.assertIn("capture-before.json", res.stdout)
        self.assertEqual(snapshot, state.read_bytes())
        self.assertFalse((self.ev / "mutation.json").exists())
        self.assertFalse((self.ev / "capture-after.json").exists())

    def test_subprocess_missing_baseline_retains_nothing_and_no_write(self):
        res = run_cli("experiment.py", self.root)
        self.assertEqual(res.returncode, 2, res.stdout)
        for name in ("capture-before.json", "capture-after.json", "mutation.json"):
            self.assertFalse((self.ev / name).exists(), name)
        self.assertEqual(device(self.root, "read", "--field", "config"), {"baud": 9600})

    def test_subprocess_stale_baseline_retains_nothing_and_no_write(self):
        run_cli("capture_state.py", self.root, "--save-baseline")
        device(self.root, "set", "--parameter", "baud", "--value", "4800")
        res = run_cli("experiment.py", self.root)
        self.assertEqual(res.returncode, 2, res.stdout)
        self.assertIn("stale baseline", res.stdout)
        for name in ("capture-before.json", "capture-after.json", "mutation.json"):
            self.assertFalse((self.ev / name).exists(), name)
        self.assertEqual(device(self.root, "read", "--field", "config"), {"baud": 4800})

    def test_subprocess_rerun_preserves_originals_and_keeps_verification_separate(self):
        self.assertEqual(run_cli("guardrails.py", self.root).returncode, 0)
        names = ("baseline.json", "capture-before.json", "capture-after.json", "mutation.json")
        snapshot = {n: (self.ev / n).read_bytes() for n in names}
        state = (self.root / "device" / "state.json").read_bytes()
        res = run_cli("guardrails.py", self.root)
        self.assertEqual(res.returncode, 0, res.stdout)
        self.assertEqual(snapshot, {n: (self.ev / n).read_bytes() for n in names})
        self.assertEqual(state, (self.root / "device" / "state.json").read_bytes())
        verification = json.loads((self.ev / "verification-latest.json").read_text())
        self.assert_full_capture(verification["capture"])
        self.assertEqual(verification["verification"]["status"], "OK")
        result = json.loads((self.ev / "guardrails-result.json").read_text())
        self.assertEqual(result["original_artifacts_preserved"]["changed"], [])


if __name__ == "__main__":
    unittest.main()
