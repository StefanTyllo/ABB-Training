# FW1 independent assessment

Scripted Copilot rehearsal; not a classroom pilot or statistical comparison.

| Submission | Result | Grader exit | Protected inputs |
|---|---|---:|---|
| demo | PASS | 0 | unchanged |
| transfer-md | PASS | 0 | unchanged |
| transfer-code | PASS | 0 | unchanged |
