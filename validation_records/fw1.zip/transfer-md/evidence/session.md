# FW1 transfer (Markdown workflow) session

## Inputs validated
Workspace, fw1/device.py, device/state.json, fw1/expected.json, case.json (transfer), evidence/ all present. No init run.
Note: first attempt, which redirected outputs to /tmp, was denied by the environment; no device command ran. Re-ran without redirects.

## Pre-change observations (no writes)
- identity: `{"device_id": "SIM-083"}`
- firmware: `{"version": "1.4.2"}`
- config: `{"baud": 9600}`
- faults: `["LINK_TIMEOUT"]`
- logs: `["boot: link timeout"]`
- probe: `{"ok": false, "status": "timeout"}` (exit 0, failure judged from JSON)
Baseline saved to evidence/baseline.json (identity, firmware, config, faults, logs) before any write.

## Reference match
expected.json entry with device_id SIM-083 and firmware 1.4.2 (matches observed) gives baud 38400. Selected by observed identity, not by memory.

## Hypothesis
Active LINK_TIMEOUT fault + failed probe + baud 9600 != 38400 with matching firmware => configuration mismatch, not a software defect.

## Change
Re-read config: `{"baud": 9600}` equals baseline (not stale).
`python fw1/device.py --workdir device set --parameter baud --value 38400` -> `{"parameter": "baud", "old": 9600, "new": 38400}`, exit 0. One change only.

## Post-change verification
- config: `{"baud": 38400}`
- faults: `[]`
- logs: `["boot: link timeout", "baud changed: 9600 -> 38400"]`
- probe: `{"ok": true, "status": "reply"}`

## Why the old log entry is not an active fault
Logs are append-only history of the original boot incident; the fault register is current state and is now empty, with a successful probe.

## Result
PASS: recovered by one justified configuration change; no blocked or failed operations apart from the denied /tmp redirect noted above. No rerun write performed.
