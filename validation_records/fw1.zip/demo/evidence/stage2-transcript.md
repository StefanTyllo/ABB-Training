# Copilot CLI Session

> [!NOTE]
> - **Session ID:** `80fba447-f6f6-4130-b686-37e892b6f7cd`  
> - **Started:** 10/14/2026, 3:47:26 PM  
> - **Duration:** 1m 20s  
> - **Exported:** 10/14/2026, 3:48:46 PM  

---

<sub>2s</sub>

### User

You are performing a scripted CI rehearsal of the ABB training lab.
Your working directory is /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo. Stay in this workspace. Do not read instructor files,
external graders, other workspaces, or CI orchestration. They are independent assessment.
Read task-card.md, CI_CONTRACT.md, and the local requirements/report contract.
Use actual terminal tools; do not claim unexecuted results. Do not print environment variables
or credentials. Preserve source authorities and supplied adapters. Expected engineering failure
or blocked results must remain visible. This is a scripted rehearsal, not a human learner pilot.
STAGE 2: Review evidence/session.md and workflow.md. Abstract the observed
process for reuse. Replace incident-specific IDs, paths, versions and values with named validated inputs.
Preserve genuine engineering invariants and authority rules. Specify missing-input behavior and untested
branches. Remove duplicate instructions. Save workflow.md and an identical workflow-md-only.md checkpoint.
Do not create automation or change the completed task artifacts.


---

<sub>4s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo && ls -la && cat task-card.md CI_CONTRACT.md && ls evidence**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo && ls -la && cat task-card.md CI_CONTRACT.md && ls evidence

<details>
<summary>153 lines</summary>

````
total 48
drwxr-xr-x 5 runner runner 4096 Oct 14 15:47 .
drwxr-xr-x 5 runner runner 4096 Oct 14 15:46 ..
-rw-r--r-- 1 runner runner 5336 Oct 14 15:46 CI_CONTRACT.md
-rw-r--r-- 1 runner runner   31 Oct 14 15:46 case.json
drwxr-xr-x 2 runner runner 4096 Oct 14 15:46 device
drwxr-xr-x 2 runner runner 4096 Oct 14 15:47 evidence
drwxr-xr-x 2 runner runner 4096 Oct 14 15:46 fw1
-rw-r--r-- 1 runner runner 2838 Oct 14 15:46 requirements.md
-rw-r--r-- 1 runner runner 4854 Oct 14 15:46 task-card.md
-rw-r--r-- 1 runner runner 3240 Oct 14 15:47 workflow.md

# FW1 Capture state before troubleshooting

**Task card.** Restore communication with the simulated device. Explain the cause using observations collected before the change, make one justified configuration change, and verify recovery. Do not repair the simulator's implementation.

**Prepare from the training root**
```bash
python materials/prepare_lab.py fw1 demo work/fw1-demo
cd work/fw1-demo
```
Read `requirements.md`. Start the agent here and use the Stage 1 start prompt. The state is already initialized under `device/`. Reinitialization is unnecessary and refuses existing state.

**Allowed changes:** device configuration through `fw1/device.py set`, plus the common workflow, automation, and evidence files. Do not edit `device/state.json`, the simulator, or `fw1/expected.json` directly.

## Stage 1 Guided operations
Run these one at a time, explaining the question each answers:
```bash
python fw1/device.py --workdir device read --field identity
python fw1/device.py --workdir device read --field firmware
python fw1/device.py --workdir device read --field config
python fw1/device.py --workdir device read --field faults
python fw1/device.py --workdir device logs
python fw1/device.py --workdir device probe
python -m json.tool fw1/expected.json
```

| Decision point | Explanation the participant must supply |
| --- | --- |
| Before any write | Which observations constitute the baseline, and where will they be saved? |
| After the probe | What supports a configuration hypothesis rather than a software repair? |
| Before changing baud | Which expected entry belongs to the observed device identity? |
| After the change | Which current observations demonstrate recovery? |

Use the tool's help to construct a single `set --parameter baud --value` operation from the observed reference. Save pre-change evidence before executing it. Then repeat configuration, faults, and probe. Historical logs may retain the old incident; explain why that differs from an active fault.

**Demonstration complete:** identity-matched reference used; baseline retained; one recorded configuration change; current fault cleared and probe successful. Now use the shared documentation prompt, then continue on the next page.


# FW1 Extract the reusable operations

## Stage 2 Abstraction focus
Inputs are the device tool path, state-directory path, expected-configuration path, and evidence destination. Resolve the expected settings from the observed identity. Do not carry the demo device ID or baud value into the reusable workflow.

## Stage 3 Deterministic boundary
| Move into code | Retain as reasoning |
| --- | --- |
| Capture identity, firmware, configuration, faults, logs, and probe output | Decide which evidence supports the fault hypothesis |
| Validate required observations and identity/reference match | Decide whether an unfamiliar fault warrants a different investigation |
| Compare before/after values and probe status | Explain why the observed change demonstrates recovery |

## Stage 4 Required implementation behavior
Create `automation/capture_state.py` and a controlled experiment entry point with documented arguments. Capture must invoke the existing low-level tool, preserve raw results, and add timestamp and input identity. It must fail if any required read fails; a partial capture cannot become a baseline marked complete.

The experiment operation must require a valid baseline for the same device and compare the current configuration with that baseline before writing. If they differ, return blocked and request a new capture. It must apply at most one allowed parameter change, then capture and compare again. This is enforcement inside the learner's entry point; direct simulator access remains available in this teaching fixture.

**Required checks:** valid capture; missing/nonexistent state directory produces blocked; unknown identity cannot select a reference; experiment without a baseline is rejected; stale baseline is rejected; correct change restores the probe. Use disposable prepared cases for checks that mutate state.

**Transfer preparation, from the training root**
```bash
python materials/prepare_lab.py fw1 transfer work/fw1-transfer-md
python materials/prepare_lab.py fw1 transfer work/fw1-transfer-code
```
Use the shared replay procedure. The transfer has a different identity and required baud. The learner's code must discover both from current evidence. Do not copy `device/` from the demo.

**Assessment:** the facilitator checks actual before/after records, the device-matched reference, and a fresh successful probe. Automated starter smoke tests validate the fixture, not the learner's reasoning or baseline capture.

**Debrief:** which terminal operations stopped requiring the model to reconstruct commands? Which diagnosis decisions still depended on engineering interpretation?
# Firmware CI contract

The runner creates one workspace per case with `training_kit/prepare_lab.py`.
`case.json` contains `lab` (`fw1` or `fw2`) and `case` (`demo` or `transfer`).
Use only that workspace's paths and inputs; do not hard-code the demo identity,
baud, packet sequence, absolute paths, or receive-chunk boundaries.

Follow the training method: manually walk through the demo with Copilot CLI
explaining why; document the observed workflow in `workflow.md`; abstract incident
specifics; identify deterministic steps; then generate verbose automation.
Stage 1 is the manual walkthrough: do not create reusable automation yet.
Keep explanatory comments and useful action/result output in that automation.
An independent reviewer evaluates the explanation and workflow quality; runtime
checks alone do not establish those qualities or prove when evidence was captured.

## Common automation entry point

Create `automation/guardrails.py`, runnable as:

```bash
python3 automation/guardrails.py --workspace /absolute/path/to/workspace
```

It must return 0 after successful completion and verification, and nonzero on
failure. Resolve all input/output paths from `--workspace`, not the caller's cwd.
Do not require interactive input. It must work after Copilot completes the task
in either the demo or a separately prepared transfer workspace, and be idempotent:
a repeat invocation preserves
the original baseline and does not perform an additional device write or change
the repaired parser sources. The runner copies only `automation/` and
`workflow.md` from the demo into a freshly prepared transfer workspace. All helper
code required by automation must therefore live under `automation/`. Copilot
performs the transfer task before the grader runs; copying helpers does not
replace that fresh investigation and repair.

After Copilot completes the task, the independent grader invokes automation,
validates the completed result using trusted
checks, invokes it again, and validates preservation and results. The grader
does not fix or patch starter sources. Do not modify grader/instructor files.

## FW1

Inputs are `fw1/device.py`, `fw1/expected.json`, `case.json`, and
`device/state.json`. Leave the simulator, expected settings, and case metadata
unchanged. Use device CLI primitives for mutations, not direct state-file edits.
Before the first mutation, write `evidence/baseline.json` containing these keys,
each holding the unmodified JSON output of the corresponding primitive:

| Key | Primitive |
| --- | --- |
| `identity` | `read --field identity` |
| `firmware` | `read --field firmware` |
| `config` | `read --field config` |
| `faults` | `read --field faults` |
| `logs` | `logs` |

All calls use `--workdir <workspace>/device`. Baseline must show original baud
9600, LINK_TIMEOUT, and the original boot log, with matching device identity and
firmware. Never overwrite or reformat an existing baseline. Missing baseline on
an already repaired device is an error: do not fabricate historic evidence.
Use the case and expected settings to derive the target baud. Final config must
match the target, faults must be empty, and probe must succeed. The original boot
log remains, followed by exactly one intended `9600 -> target` change. Running
automation again must preserve state and baseline byte-for-byte.
The grader runs the helper after Copilot has completed the device task, including
capturing the baseline and applying any justified change.

## FW2

Inputs are `fw2/parser.c`, `fw2/parser.h`, `fw2/main.c`, `case.json`, and
`requirements.md`. Repair the parser implementation and use the documented public
API/CLI. Copilot performs a fresh repair in each case. The reusable helper only
builds the candidate, replays protocol cases, compares results, and reports
verification; it must not apply the repair or carry a corrected parser in its
helpers. Preserve `main.c`, `parser.h`,
and case metadata. Do not replace the CLI with hard-coded fixture responses.
An executable supplied by automation is not trusted: the grader rebuilds
`parser.c` with the trusted original CLI/header and runs the instructor's external
50-case stream grader plus malformed input checks. Repeat automation must leave
parser source bytes unchanged. FW2 does not require FW1's baseline JSON.

## Independent evaluation

From the repository root:

```bash
python3 training_ci/grade_firmware.py --lab fw1 --workspace /path/to/fw1-demo
python3 training_ci/grade_firmware.py --lab fw2 --workspace /path/to/fw2-demo
python3 training_ci/grade_firmware.py --lab fw1 --workspace /path/to/fw1-transfer --mode md-only
```

Repeat for each transfer workspace after copying the two common artifacts and
having Copilot complete the fresh task.
The grader prints a JSON result to stdout, a terminal summary to stderr, and saves
`evidence/grade_firmware.json`; it exits 0 on pass and 1 on failed checks.
`--mode code` is the default and invokes/requires automation as described above.
`--mode md-only` requires `workflow.md` and grades the existing baseline/device
state or parser with the same independent result checks, but neither requires nor
invokes automation. The runner uses fresh, separate MD-only and code transfer
workspaces. Learners must not access grader/instructor sources; the runner records
protected-file hashes independently.
baseline.json
session.md
stage1-execution.json
stage1-prompt.txt
stage1-response.txt
stage1-transcript.md
stage2-prompt.txt
stage2-response.txt
<shellId: 0 completed with exit code 0>
````

</details>


---

<sub>6s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo && cat workflow.md requirements.md; echo ====; cat evidence/session.md; ls automation 2>&1**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo && cat workflow.md requirements.md; echo ====; cat evidence/session.md; ls automation 2>&1

<details>
<summary>97 lines</summary>

```
# FW1 workflow: restore a simulated device link by configuration

## Prerequisites
- Workspace has `fw1/device.py`, `fw1/expected.json`, `case.json`, `device/state.json`, `evidence/`.
- Device tool: `python fw1/device.py --workdir <workspace>/device <primitive>`. Do not edit state, simulator or the reference directly. Do not re-init.
- Inputs: tool path, state dir, expected-config path, evidence dir. Do not carry the device ID or baud over from another case.

## Steps
1. **Check inputs.** Confirm that the state directory and `state.json` exist. If not, the result is blocked; stop and report it.
2. **Read the baseline, with no writes:** `read --field identity`, `read --field firmware`, `read --field config`, `read --field faults`, `logs`, `probe`. Each prints one JSON value. Any failed read means the baseline is incomplete: stop.
3. **Save the baseline** to `evidence/baseline.json` with keys identity, firmware, config, faults and logs, holding the raw outputs. Do this before the first write, and never overwrite it. Record the probe too (in the session log).
4. **Pick the reference by observed identity:** look up `device_id` in `fw1/expected.json`. If it is unknown, or the firmware differs from the reference, stop (blocked) and investigate. Do not guess an entry.
5. **Form the hypothesis.** The evidence is: active fault LINK_TIMEOUT, probe `ok:false`/`timeout`, and a config baud differing from the reference baud. That points to a configuration mismatch, not software. This step requires engineering judgement. An unfamiliar fault, or a baud that already matches, means a different investigation; don't write.
6. **Confirm the baseline is still current**, i.e. config still equals the baseline value, before writing.
7. **One change:** `set --parameter baud --value <reference baud>` (valid range 1200..115200). Check the old/new JSON.
8. **Verify:** repeat `read --field config`, `read --field faults`, `logs` and `probe`.
9. **Record** commands, outputs and rationale in `evidence/session.md`.

## Branches and recovery
- Probe `ok:true` and no fault at the start: there is nothing to repair. Do not write. If no baseline exists, do not fabricate one.
- `set` rejected (nonzero exit, stderr): state is unchanged. Re-read the config, check the value and range, and retry once at most.
- After the write the probe still fails: do not stack more changes. Capture the new observations and re-examine the hypothesis (identity/reference match).
- Wrong value written: the baseline preserves the original; the log keeps every change. Correct it with one documented `set` and explain it.
- A probe exits 0 even when it fails: judge it from the JSON.

## Evidence
`evidence/baseline.json` (pre-change); `evidence/session.md` (commands, rationale, post-change outputs). The logs retain `boot: link timeout` and add exactly one `baud changed: <old> -> <target>`.

## Completion criteria
- The baseline was saved before the write, with the original baud, LINK_TIMEOUT and the boot log.
- The reference was matched to the observed identity.
- Exactly one recorded `set` was made.
- The config baud equals the reference, faults are `[]`, and the probe is `ok:true`.
- The old boot log is explained as history, not an active fault.
# Exercise contracts

## FW1

- Each invocation handles one primitive and prints one JSON value to stdout on
  success. Invalid commands/parameters/values report stderr and exit nonzero.
- `--workdir PATH` precedes the subcommand; default is `.device` relative to cwd.
  Commands persist mutable state in `PATH/state.json`. Reads/probes do not mutate.
- `init --case demo|transfer` creates state once. Both cases start at baud 9600.
  Demo is SIM-017 / expected 19200; transfer is SIM-083 / expected 38400.
  Both use firmware 1.4.2. `fw1/expected.json` is the fixed configuration reference:
  exercise code must not change it. This separation is logical, not security.
- `read --field identity|firmware|config|faults`, `logs`, and `probe` expose
  independent observations. A mismatch produces LINK_TIMEOUT and a failed probe;
  matching baud produces no active fault and a successful probe. Historical boot
  timeout remains in logs after recovery; logs are not the current fault register.
- `set --parameter baud --value INT` accepts 1200..115200 inclusive; all other
  parameter names and out-of-range values fail without modifying state. Accepted
  writes append a log entry. Capturing before/after evidence is learner work.
- Simulator scope: one operator, local files, deterministic link comparison.
  No hardware timing, authentication, concurrency, retries, or crash recovery.

## FW2

- A packet is exactly six bytes: `A5 02 sequence low high checksum`.
  Sequence is unsigned 8-bit; low/high encode a signed two's-complement 16-bit
  little-endian value. Checksum is XOR of the preceding five bytes.
- `Parser` is initialized to zero once per stream. Every feed call continues
  that stream. Calls may contain zero bytes, partial packets, many packets, or
  noise. Partial state survives chunk boundaries. There is no timeout behavior.
- Resynchronization: discard leading bytes until A5. Once a second byte exists,
  reject any length other than 02 by discarding only the leading A5 and rescanning.
  Wait for six bytes for a candidate with valid header. On checksum failure,
  discard only its first byte and rescan all remaining bytes, preserving a possible
  partial candidate. On success, emit once and consume all six bytes. A5 inside a
  valid payload/sequence/checksum is ordinary data. At end-of-stream, incomplete
  data emits nothing. A fresh process starts a fresh stream.
- CLI arguments are chunks of contiguous, even-length hexadecimal (either case).
  Empty chunks are accepted; maximum is 4096 bytes per argument. Reject malformed
  or longer chunks with nonzero exit and stderr before any stdout. No arguments
  emit `[]`. Successful output is a JSON array of `{sequence, value}` objects.
- Demo `A5 02 07 85 FF DA` means sequence 7, value -123. Transfer
  `A5 02 2A 00 F8 75` means sequence 42, value -2048.
====
# FW1 demo – Stage 1 session log (scripted CI rehearsal)

All commands run from the workspace root; `D="python fw1/device.py --workdir device"`.
Note: an initial attempt that also wrote raw copies to `evidence/raw/` was denied by the environment; no state changed. I instead saved the baseline once in `evidence/baseline.json`.

## Baseline (before any write)
Rationale: the baseline is every independent observation (identity, firmware, config, faults, logs, probe). It is saved to `evidence/baseline.json` before the first mutation so before/after can be compared.

| # | Command | Result | Observation |
|---|---|---|---|
| 1 | `$D read --field identity` | `{"device_id": "SIM-017"}` | Which reference entry applies |
| 2 | `$D read --field firmware` | `{"version": "1.4.2"}` | Matches expected firmware |
| 3 | `$D read --field config` | `{"baud": 9600}` | Current setting |
| 4 | `$D read --field faults` | `["LINK_TIMEOUT"]` | Active fault register |
| 5 | `$D logs` | `["boot: link timeout"]` | Historical event |
| 6 | `$D probe` | `{"ok": false, "status": "timeout"}` (exit 0) | Link fails; probe exit code is 0 even on failure, so read the JSON |
| 7 | `python -m json.tool fw1/expected.json` | demo SIM-017 fw 1.4.2 baud 19200; transfer SIM-083 fw 1.4.2 baud 38400 | Reference |

## Hypothesis (after probe)
Rationale: LINK_TIMEOUT plus a failed probe with a baud that differs from the reference entry for the observed identity (SIM-017 -> 19200) supports a configuration mismatch. Firmware matches the reference, and there is no crash or software error, so no simulator repair is warranted. The SIM-083/38400 entry belongs to a different identity and is not used.

## Change
Rationale (before changing baud): select the entry by observed identity SIM-017, so the target is 19200. Help (`set --help`) shows `--parameter {baud} --value VALUE`. Baseline already saved.
8. `$D set --parameter baud --value 19200` -> `{"parameter": "baud", "old": 9600, "new": 19200}` exit 0. This is the only write.

## Verification (after change)
9. `$D read --field config` -> `{"baud": 19200}`
10. `$D read --field faults` -> `[]`
11. `$D logs` -> `["boot: link timeout", "baud changed: 9600 -> 19200"]`
12. `$D probe` -> `{"ok": true, "status": "reply"}`

Recovery is shown by the current config matching the reference, an empty fault register and a successful probe. The "boot: link timeout" log entry is history of the original incident, not an active fault; the logs are append-only, and the fault register is the current state.

Result: demonstration complete; no blocked or failed outcome remained. The simulator, `state.json` and `expected.json` were not edited directly.
ls: cannot access 'automation': No such file or directory
<shellId: 1 completed with exit code 2>
```

</details>


---

<sub>24s</sub>

### `create`

**create a new file at /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.new.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.new

```
Created file /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.new with 5798 characters
```


---

<sub>28s</sub>

### `edit`

**edit the file at /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.new.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.new

```
File /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.new updated with changes.
```


---

<sub>28s</sub>

### `bash` — Failed

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo && mv workflow.new workflow.md && cp workflow.md workflow-md-only.md && cmp workflow.md workflow-md-only.md && echo identical && git status --short .**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo && mv workflow.new workflow.md && cp workflow.md workflow-md-only.md && cmp workflow.md workflow-md-only.md && echo identical && git status --short .

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>32s</sub>

### `bash` — Failed

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo && cp workflow.new workflow.md && cp workflow.new workflow-md-only.md && rm workflow.new && cmp workflow.md workflow-md-only.md && echo identical**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo && cp workflow.new workflow.md && cp workflow.new workflow-md-only.md && rm workflow.new && cmp workflow.md workflow-md-only.md && echo identical

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>36s</sub>

### `view`

**view the file at /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.new.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.new

<details>
<summary>50 lines</summary>

```
# Workflow: restore a simulated device link by one justified configuration change

Derived from one observed run (a single happy path). Steps marked **UNTESTED** were not exercised in that run; treat them as intended behavior to verify, not proven behavior.

## Named inputs (validate before any device command)
| Input | Meaning | Missing/invalid behavior |
|---|---|---|
| `WORKSPACE` | Absolute workspace root; resolve every other path from it, never from the caller's cwd | BLOCKED |
| `TOOL` | `<WORKSPACE>/fw1/device.py` | BLOCKED |
| `STATE_DIR` | `<WORKSPACE>/device`, must contain `state.json` | BLOCKED; never run `init` (it refuses existing state and would fabricate a device) |
| `REFERENCE` | `<WORKSPACE>/fw1/expected.json`, read-only fixed authority | BLOCKED |
| `CASE` | `<WORKSPACE>/case.json`, read-only metadata | Not needed to select the reference; if absent, continue and note it |
| `EVIDENCE_DIR` | `<WORKSPACE>/evidence`, must be writable | BLOCKED if it cannot be created or written |

BLOCKED means: stop, make no device write, and report which input failed. Do not substitute a default or a value from another case.
Call the tool as `python TOOL --workdir STATE_DIR <primitive>`. Each primitive prints one JSON value to stdout; failures print to stderr and exit nonzero.

## Authority rules (invariants)
- The device identity observed now selects the reference entry. Never use identity, baud or firmware remembered from another case or the training text.
- Do not edit `state.json`, the simulator, the reference, or case metadata. Mutate only with `set`.
- The fault register is the current state. Logs are append-only history and may keep the original incident after recovery.
- A probe may exit 0 while failing. Judge it from its JSON (`ok`, `status`), not the exit code.
- The baseline is written once, before the first mutation, and is never overwritten or reformatted.

## Steps
1. **Validate inputs** (table above). Any failure: BLOCKED.
2. **Capture the observations, no writes.** Run `read --field identity`, `read --field firmware`, `read --field config`, `read --field faults`, `logs`, `probe`. If any call fails or does not return valid JSON, the capture is incomplete: stop and report; do not save it as a baseline.
3. **Save the baseline** to `EVIDENCE_DIR/baseline.json` with keys `identity`, `firmware`, `config`, `faults`, `logs`, each holding the unmodified output of its primitive. Record the probe result in the session log. If a baseline file already exists, keep it untouched. If none exists and the device is already repaired, report an error: do not fabricate history.
4. **Select the reference from the observed identity.** Look up the observed device id in `REFERENCE`. Unknown id, or observed firmware different from the entry's firmware: BLOCKED; investigate and never guess or pick the nearest entry. Take `target_baud` only from the matched entry.
5. **Form the hypothesis (engineering judgement, not automatable).** Support for a configuration fault: an active fault in the register, a failed probe, and `config.baud != target_baud` with matching firmware. Absent a software error, this points to configuration rather than simulator repair. Stop without writing if the fault is not one you can tie to baud, or if the baud already equals `target_baud` while the link fails. That needs a different investigation.
6. **Healthy start.** Probe `ok:true` and empty fault register: nothing to repair, no write.
7. **Confirm the baseline is current.** Re-read `config`; it must still equal `baseline.config`. If it differs, the baseline is stale: BLOCKED, request a new capture. Do not write.
8. **Make one change:** `set --parameter baud --value <target_baud>` (accepted range 1200..115200 inclusive). Save the old/new JSON it returns. Make at most one change per run.
9. **Verify with fresh reads:** `read --field config`, `read --field faults`, `logs`, `probe`. Compare to baseline.
10. **Record** commands, outputs, rationale, and any denied or failed operation in `EVIDENCE_DIR/session.md`. Report failures and BLOCKED outcomes as they are. Do not soften them.

## Branches and recovery
| Situation | Behavior | Status |
|---|---|---|
| Missing/nonexistent state dir or input | BLOCKED, no writes | UNTESTED |
| A baseline read fails | Incomplete, no write | UNTESTED |
| Unknown identity or firmware mismatch | BLOCKED | UNTESTED |
| Config differs from baseline before writing | BLOCKED, new capture needed | UNTESTED |
| Device already healthy | No write | UNTESTED |
| `set` rejected (nonzero exit) | State is unchanged. Re-read config, check value and range, retry once at most | UNTESTED |
| Probe still fails after the write | Make no further change. Capture observations and re-examine the hypothesis and reference match. Report failure | UNTESTED |
| Wrong value written | Baseline keeps the original, logs keep every change. Correct with one documented `set` and explain | UNTESTED |
| Writing extra evidence under a subdirectory was denied by the environment | No device state changed. Save only the required files | Observed |

Only the single successful path (steps 1-5, 7-10) was observed.

## Completion criteria
- Baseline saved before the write, holding the original config, active fault, history and identity/firmware.
- Reference entry matched to the observed identity.
- Exactly one recorded `set`, whose log entry reads `baud changed: <baseline baud> -> <target_baud>`. Earlier log entries are preserved.
- Current `config.baud == target_baud`, faults are `[]`, probe is `ok:true`.
- Reasoning given for why an old log entry is history and not an active fault.
- Rerunning leaves the baseline and device state unchanged and makes no further write.
```

</details>


---

<sub>48s</sub>

### `create`

**create a new file at /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow-md-only.md.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow-md-only.md

```
Created file /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow-md-only.md with 5725 characters
```


---

<sub>51s</sub>

### `view`

**view the file at /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.md.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.md

<details>
<summary>29 lines</summary>

```
# FW1 workflow: restore a simulated device link by configuration

## Prerequisites
- Workspace has `fw1/device.py`, `fw1/expected.json`, `case.json`, `device/state.json`, `evidence/`.
- Device tool: `python fw1/device.py --workdir <workspace>/device <primitive>`. Do not edit state, simulator or the reference directly. Do not re-init.
- Inputs: tool path, state dir, expected-config path, evidence dir. Do not carry the device ID or baud over from another case.

## Steps
1. **Check inputs.** Confirm that the state directory and `state.json` exist. If not, the result is blocked; stop and report it.
2. **Read the baseline, with no writes:** `read --field identity`, `read --field firmware`, `read --field config`, `read --field faults`, `logs`, `probe`. Each prints one JSON value. Any failed read means the baseline is incomplete: stop.
3. **Save the baseline** to `evidence/baseline.json` with keys identity, firmware, config, faults and logs, holding the raw outputs. Do this before the first write, and never overwrite it. Record the probe too (in the session log).
4. **Pick the reference by observed identity:** look up `device_id` in `fw1/expected.json`. If it is unknown, or the firmware differs from the reference, stop (blocked) and investigate. Do not guess an entry.
5. **Form the hypothesis.** The evidence is: active fault LINK_TIMEOUT, probe `ok:false`/`timeout`, and a config baud differing from the reference baud. That points to a configuration mismatch, not software. This step requires engineering judgement. An unfamiliar fault, or a baud that already matches, means a different investigation; don't write.
6. **Confirm the baseline is still current**, i.e. config still equals the baseline value, before writing.
7. **One change:** `set --parameter baud --value <reference baud>` (valid range 1200..115200). Check the old/new JSON.
8. **Verify:** repeat `read --field config`, `read --field faults`, `logs` and `probe`.
9. **Record** commands, outputs and rationale in `evidence/session.md`.

## Branches and recovery
- Probe `ok:true` and no fault at the start: there is nothing to repair. Do not write. If no baseline exists, do not fabricate one.
- `set` rejected (nonzero exit, stderr): state is unchanged. Re-read the config, check the value and range, and retry once at most.
- After the write the probe still fails: do not stack more changes. Capture the new observations and re-examine the hypothesis (identity/reference match).
- Wrong value written: the baseline preserves the original; the log keeps every change. Correct it with one documented `set` and explain it.
- A probe exits 0 even when it fails: judge it from the JSON.

## Evidence
`evidence/baseline.json` (pre-change); `evidence/session.md` (commands, rationale, post-change outputs). The logs retain `boot: link timeout` and add exactly one `baud changed: <old> -> <target>`.

## Completion criteria
- The baseline was saved before the write, with the original baud, LINK_TIMEOUT and the boot log.
- The reference was matched to the observed identity.
- Exactly one recorded `set` was made.
- The config baud equals the reference, faults are `[]`, and the probe is `ok:true`.
- The old boot log is explained as history, not an active fault.
```

</details>


---

<sub>1m 9s</sub>

### `edit`

**edit the file at /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.md.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.md

```
File /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.md updated with changes.
```


---

<sub>1m 9s</sub>

### `edit`

**edit the file at /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.md.**

/home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.md

```
File /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.md updated with changes.
```


---

<sub>1m 12s</sub>

### `bash` — Failed

**cd /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo && cmp workflow.md workflow-md-only.md && echo identical; rm -f workflow.new; ls**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo && cmp workflow.md workflow-md-only.md && echo identical; rm -f workflow.new; ls

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>1m 14s</sub>

### Copilot

Bash is unavailable, so I'll check with the view tool.

---

<sub>1m 14s</sub>

### `grep`

**^## **

"^## " in workflow*

```
/home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.new:5
/home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow.md:5
/home/runner/work/ABB-Training/ABB-Training/runs/fw1/demo/workflow-md-only.md:5
```


---

<sub>1m 20s</sub>

### Copilot

I rewrote `workflow.md` as a reusable workflow and saved `workflow-md-only.md` with the same intended text. I could not confirm the two files are byte-identical. Bash was denied in this run, so the `cmp` check never ran. I only confirmed that each file has the same number of `##` section headings.

I also could not delete a leftover scratch file, `workflow.new`, which is a draft copy of the same text. Please remove it.

- **Inputs:** the workflow now uses named inputs (workspace, tool, state directory, reference file, evidence directory). Each has defined behavior when missing: blocked, no writes, and no `init`. The demo's device ID, baud value and fault name are gone.
- **Kept:**
  - The observed identity selects the reference entry.
  - The baseline is written once, before the first write, and is never overwritten.
  - The baseline is checked as still current before writing.
  - There is at most one `set` per run.
  - The probe is judged from its JSON, not its exit code.
  - Logs are history; the fault register is the current state.
  - The simulator, state file, reference and case metadata are never edited directly.
- **Untested branches:** a table lists each as UNTESTED, because the demo only showed the successful path. The branches are:
  - a missing input
  - an unknown identity
  - a firmware mismatch
  - a stale baseline
  - a device that is already healthy
  - a rejected `set`
  - a probe that still fails after the write
  - a wrong value written
- **Observed:** the denied write of extra raw copies under `evidence/raw/` is recorded as observed, with no device state changed.
- **Duplicates:** the separate Evidence section is gone and its content is merged into the completion criteria.

No automation was created, and no completed task artifacts were changed.

---

<sub>Generated by [GitHub Copilot CLI](https://github.com/features/copilot/cli)</sub>
