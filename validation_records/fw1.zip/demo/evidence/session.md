# FW1 demo – Stage 1 session log (scripted CI rehearsal)

All commands run from the workspace root; `D="python fw1/device.py --workdir device"`.
Note: an initial attempt that also wrote raw copies to `evidence/raw/` was denied by the environment; no state changed. I instead saved the baseline once in `evidence/baseline.json`.

## Baseline (before any write)
Rationale: the baseline is every independent observation (identity, firmware, config, faults, logs, probe). It is saved to `evidence/baseline.json` before the first mutation so before/after can be compared.

| # | Command | Result | Observation |
|---|---|---|---|
| 1 | `$D read --field identity` | `{"device_id": "SIM-017"}` | Which reference entry applies |
| 2 | `$D read --field firmware` | `{"version": "1.4.2"}` | Matches expected firmware |
| 3 | `$D read --field config` | `{"baud": 9600}` | Current setting |
| 4 | `$D read --field faults` | `["LINK_TIMEOUT"]` | Active fault register |
| 5 | `$D logs` | `["boot: link timeout"]` | Historical event |
| 6 | `$D probe` | `{"ok": false, "status": "timeout"}` (exit 0) | Link fails; probe exit code is 0 even on failure, so read the JSON |
| 7 | `python -m json.tool fw1/expected.json` | demo SIM-017 fw 1.4.2 baud 19200; transfer SIM-083 fw 1.4.2 baud 38400 | Reference |

## Hypothesis (after probe)
Rationale: LINK_TIMEOUT plus a failed probe with a baud that differs from the reference entry for the observed identity (SIM-017 -> 19200) supports a configuration mismatch. Firmware matches the reference, and there is no crash or software error, so no simulator repair is warranted. The SIM-083/38400 entry belongs to a different identity and is not used.

## Change
Rationale (before changing baud): select the entry by observed identity SIM-017, so the target is 19200. Help (`set --help`) shows `--parameter {baud} --value VALUE`. Baseline already saved.
8. `$D set --parameter baud --value 19200` -> `{"parameter": "baud", "old": 9600, "new": 19200}` exit 0. This is the only write.

## Verification (after change)
9. `$D read --field config` -> `{"baud": 19200}`
10. `$D read --field faults` -> `[]`
11. `$D logs` -> `["boot: link timeout", "baud changed: 9600 -> 19200"]`
12. `$D probe` -> `{"ok": true, "status": "reply"}`

Recovery is shown by the current config matching the reference, an empty fault register and a successful probe. The "boot: link timeout" log entry is history of the original incident, not an active fault; the logs are append-only, and the fault register is the current state.

Result: demonstration complete; no blocked or failed outcome remained. The simulator, `state.json` and `expected.json` were not edited directly.
