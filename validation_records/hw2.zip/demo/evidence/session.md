# Stage 1 session log (scripted CI rehearsal, HW2 demo)

Workspace: runs/hw2/demo. Facilitator rationale is taken from the task card.

| # | Rationale | Command | Observation |
|---|---|---|---|
| 1 | Read the task and contracts first | cat task-card.md CI_CONTRACT.md; view REPORT_CONTRACT.md | Eight equations, the report schema, and the generator CLI. Combined shell commands were sometimes denied for lack of interactive approval, so I used view and single-purpose commands. |
| 2 | Inspect the authority | view source/circuit.json | Rt=100000, Rb=10000, t=0.01, C=1e-7, Vin=30.0, ADC=3.3, board DIVIDER-ALPHA, rev D3 |
| 3 | Inspect the existing calibration | view derived/calibration.json | rev D2, inverse_gain 10.0, digest all zeros |
| 4 | Review the generator before running it | view tools/generate_calibration.py | Emits only nominal inverse_gain and provenance; does not assess limits |
| 5 | Nominal gain = Rb/(Rt+Rb) | python3 -c (reads source) | 0.09090909090909091 |
| 6 | Maximum gain = Rb(1+t)/(Rt(1-t)+Rb(1+t)). Output is highest when the upper resistor is at its minimum and the lower at its maximum, since both changes raise Rb/(Rt+Rb). | python3 -c | 0.0925756186984418 |
| 7 | r_th = Rt*Rb/(Rt+Rb); inverse gain = (Rt+Rb)/Rb | python3 -c | 9090.90909090909 ; 11.0 |
| 8 | Nominal/worst ADC voltage, cutoff 1/(2*pi*r_th*C), margin = limit - worst | python3 -c | 2.7272727272727275 ; 2.777268560953254 ; 175.0704374010849 ; 0.5227314390467459 |
| 9 | Compare stale calibration with the current inputs by canonical digest | python3 -c (sha256 of canonical json) | 16e661ed...aa1cc1 (differs from the zero digest); rev D2 vs D3; 10.0 vs 11.0. Stale. |
| 10 | Limit evaluation | reasoning on the values above | 2.7773 V <= 3.3 V, so pass with 0.5227 V margin |
| 11 | Regenerate with the existing tool | python3 tools/generate_calibration.py --config source/circuit.json --output derived/calibration.json --replace | rc=0. New file is rev D3, inverse_gain 11.0, digest 16e661ed...aa1cc1 |
| 12 | Record the result | create report.json, workflow.md | Written |

source/circuit.json and tools/ were not modified. Not run: instructor checker (out of scope).
