# Copilot CLI Session

> [!NOTE]
> - **Session ID:** `184ca072-491a-46d0-9eef-27979cc64c78`  
> - **Started:** 10/14/2026, 3:48:59 PM  
> - **Duration:** 37s  
> - **Exported:** 10/14/2026, 3:49:37 PM  

---

<sub>1s</sub>

### User

You are performing a scripted CI rehearsal of the ABB training lab.
Your working directory is /home/runner/work/ABB-Training/ABB-Training/runs/hw2/demo. Stay in this workspace. Do not read instructor files,
external graders, other workspaces, or CI orchestration. They are independent assessment.
Read task-card.md, CI_CONTRACT.md, and the local requirements/report contract.
Use actual terminal tools; do not claim unexecuted results. Do not print environment variables
or credentials. Preserve source authorities and supplied adapters. Expected engineering failure
or blocked results must remain visible. This is a scripted rehearsal, not a human learner pilot.
STAGE 3: Review each workflow step. Write extraction-map.md with purpose,
inputs, operation, expected output, failure condition, and disposition (deterministic code, model judgment,
human decision). Prioritize collection, parsing, calculation, comparison, validation, reporting. Give every
proposed function an input/output contract. Do not implement reusable automation until stage 4.


---

<sub>2s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/demo && ls -la && cat task-card.md CI_CONTRACT.md**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/demo && ls -la && cat task-card.md CI_CONTRACT.md

<details>
<summary>129 lines</summary>

````
total 68
drwxr-xr-x 6 runner runner 4096 Oct 14 15:48 .
drwxr-xr-x 5 runner runner 4096 Oct 14 15:46 ..
-rw-r--r-- 1 runner runner 9431 Oct 14 15:46 CI_CONTRACT.md
-rw-r--r-- 1 runner runner 4043 Oct 14 15:46 REPORT_CONTRACT.md
drwxr-xr-x 2 runner runner 4096 Oct 14 15:46 derived
drwxr-xr-x 2 runner runner 4096 Oct 14 15:48 evidence
-rw-r--r-- 1 runner runner 1726 Oct 14 15:47 report.json
drwxr-xr-x 2 runner runner 4096 Oct 14 15:46 source
-rw-r--r-- 1 runner runner 4807 Oct 14 15:46 task-card.md
drwxr-xr-x 2 runner runner 4096 Oct 14 15:46 tools
-rw-r--r-- 1 runner runner 6954 Oct 14 15:48 workflow-md-only.md
-rw-r--r-- 1 runner runner 6954 Oct 14 15:48 workflow.md

# HW2 Calculate limits and refresh calibration

**Task card.** Review an idealized voltage-divider input against its ADC voltage limit, then regenerate stale nominal calibration from the current inputs. Report the design assessment independently of whether the file generator ran successfully.

**Prepare from the training root**
```bash
python materials/prepare_lab.py hw2 demo work/hw2-demo
cd work/hw2-demo
python -m json.tool source/circuit.json
python -m json.tool derived/calibration.json
```
**Model contract:** ideal source; upper resistor Rt and lower resistor Rb; nominal capacitor C from divider node to ground; ideal high-impedance ADC. Independent resistor tolerances are +/-t. No ADC loading, sampling transient, leakage, temperature drift, or capacitor tolerance is included. Source values use SI units. These assumptions bound the exercise.

**Allowed changes:** `derived/calibration.json`, `report.json`, and common artifacts. Preserve source/circuit.json and tools/. Use REPORT_CONTRACT.md for report fields and precision.

## Stage 1 Guided operations
Calculate one quantity at a time in the terminal, explaining the equation before running it. Read values from the actual source, even when using a short Python expression.

| Quantity | Required equation |
| --- | --- |
| Nominal gain | Rb / (Rt + Rb) |
| Maximum gain | Rb*(1+t) / (Rt*(1-t) + Rb*(1+t)) |
| Nominal / maximum ADC voltage | Maximum input voltage multiplied by the corresponding gain |
| Equivalent resistance | Rt*Rb / (Rt+Rb) |
| Nominal cutoff | 1 / (2*pi*equivalent resistance*C) |
| Inverse gain | (Rt+Rb) / Rb |
| ADC margin | ADC limit minus maximum ADC voltage |

Explain why upper-resistor minimum and lower-resistor maximum maximize output. Compare the existing coefficient and provenance with current inputs. Then invoke the existing generator:
```bash
python tools/generate_calibration.py --config source/circuit.json \
  --output derived/calibration.json --replace
```
**Demonstration complete:** all eight quantities recorded, voltage limit evaluated, calibration regenerated and checked, report.json written with assumptions and evidence. Now document the observed workflow.


# HW2 Extract calculations and freshness checks

## Stage 2 Abstraction focus
All component values, tolerance, maximum input, ADC limit, and file paths are inputs. Equations and model assumptions remain explicit. Do not turn the demo's coefficient into a universal constant.

## Stage 3 Deterministic boundary
| Move into code | Retain as reasoning |
| --- | --- |
| Validate positive finite values, units, and allowed tolerance | Decide whether the ideal circuit model applies to a real design |
| Calculate quantities and intermediate values | Investigate behavior outside the model's scope |
| Compare worst-case voltage with the limit | Select a new design when a limit is exceeded |
| Regenerate calibration and compare source digest | Approve changes to engineering assumptions |

## Stage 4 Required implementation behavior
Create a calculation entry point that accepts a source JSON path and report destination. Give each equation a named function or clearly named intermediate values. Log units, substituted values, calculated results, source revision, and limits. Use the existing calibration generator; do not recreate its file format inconsistently.

Validate freshness using the canonical source digest specified in REPORT_CONTRACT.md. A design-limit failure must remain visible even if nominal calibration was regenerated correctly. The exercise asks for assessment of the supplied design, not redesign to force a pass.

**Required checks:** valid demo; worst-case limit violation; invalid/missing input; changed input invalidates old calibration provenance; regeneration is repeatable for identical input. The source JSON must remain unchanged.

**Transfer preparation, from the training root**
```bash
python materials/prepare_lab.py hw2 transfer work/hw2-transfer-md
python materials/prepare_lab.py hw2 transfer work/hw2-transfer-code
```
The upper resistor changes. Use current inputs for every calculation. Correct transfer behavior produces a design assessment of fail when the worst-case voltage exceeds the stated limit, while recording accurate recalculation and calibration provenance.

**Facilitator check**, from the training root:
```bash
python materials/hardware/instructor/check.py \
  --lab hw2 --case demo --workspace work/hw2-demo
```
Change case/workspace for transfer. The check validates numerical results and artifact provenance; it does not certify physical hardware. Compare the documented assumptions and engineering explanation as part of assessment.

**Debrief:** which parts of the calculation previously consumed model reasoning despite having a fully specified deterministic answer?
# Generated hardware guardrails: CI contract

This contract is for the code-implementation stage after the guided task, workflow extraction, abstraction, and deterministic-boundary review. It specifies the entry point evaluated by CI; it does not replace those learning stages. Implement the calculations/comparisons yourself using the supplied sources and low-level calibration tool. Do not read, copy, modify, or invoke instructor answers or graders from learner code.

## Entry point and ownership

Create `automation/guardrails.py` runnable with Python 3 and its standard library:

```bash
python automation/guardrails.py --workspace /absolute/path/to/prepared/workspace
```

Resolve every data/output path against `--workspace`, not the current directory. Infer the lab from its source files: HW1 has `source/approval.json`, `source/bom.csv`, and `source/schematic.json`; HW2 has `source/circuit.json`. Reject ambiguous or missing required input. The board ID must come from source data. The fixed synthetic fixture bookkeeping is `SENSE-ALPHA` / `DIVIDER-ALPHA` = `demo`, and `SENSE-BETA` / `DIVIDER-BETA` = `transfer`. This map sets the report's `case` only; never use identity, case, filenames, or cached answers to select engineering results. Calculate and compare actual source values.

Allowed outputs are `report.json`, `evidence/`, learner code/checks under `automation/`, and the lab's single derived artifact: HW1 `derived/netlist.json`, HW2 `derived/calibration.json`. Preserve all source files, supplied tools, and REPORT_CONTRACT.md. No network or external packages are needed. Tests requiring altered inputs must create disposable fixtures under `automation/tests/`; they must not edit the prepared source inputs.

| Engineering assessment | Helper exit code | Meaning |
|---|---:|---|
| `pass` | 0 | Assessment is complete and the task's engineering criteria pass |
| `fail` | 1 | Assessment is complete but the circuit exceeds its stated design limit or another engineering criterion fails |
| `blocked` | 2 | Missing/invalid authority or input prevents assessment |

The external grader returns 0 for a faithful accepted assessment, including expected engineering `fail` and `blocked`. Its default `--mode code` invokes your helper twice, runs the existing independent instructor checker after each invocation, and requires unchanged bytes in `report.json` and the derived artifact on the second invocation. `--mode md-only` checks the already-completed report and derived artifact once using the same instructor checker; it neither requires nor executes a helper and does not impose the code-run idempotence check. Use MD-only mode for the fresh Markdown-only transfer and code mode for the demonstration after stage 4 and fresh code-assisted transfer. Logs under `evidence/` may grow. Do not add timestamps, run counters, transient command output, or changing absolute paths to stable task artifacts.

Retain initial discrepancy findings, evidence, and `changed_files` as a cumulative task audit on repeat runs for the same source inputs. A resolved discrepancy remains documented; `changed_files` records artifacts changed during this task, not only writes in the latest invocation. Preserve evidence of the original values before correction. Validate any reused report against current source identity/revision/content and verify the current derived artifact; do not blindly trust an old `pass` or stale report. If the same task is already correctly reconciled and assessed, preserve its stable report. Start a new report when source inputs change, retaining prior evidence separately.

## Exact task report

Write UTF-8 `report.json` as a JSON object matching the prepared `REPORT_CONTRACT.md`. This task report is distinct from optional operation-event logs.

| Field | Required content |
|---|---|
| `schema_version` | Integer 1 |
| `lab` | `hw1` or `hw2` |
| `case` | `demo` or `transfer`, using fixture bookkeeping above |
| `board_id` | The actual source board ID |
| `status` | Engineering `pass`, `fail`, or `blocked` |
| `findings` | Array of objects containing `code`, nonempty `evidence`, nonempty `explanation`; include `ref` for component findings |
| `changed_files` | Array of relative derived artifact paths changed during the task; no report, logs, code, or workflow files |
| `assumptions` | Nonempty array describing source authority or model limits |
| `calculations` | HW2 only: all eight numeric fields below, retaining at least 10 significant digits |

Finding evidence must identify actual source/export fields and observed before/after values. Informative messages or equivalent-unit notation are findings without being engineering failures. Do not fabricate findings on a clean unrelated input.

## HW1 behavior

Read `approval.json` for the expected board, approved revision, and approved source list. BOM is authoritative for component identity, kind, and value; the schematic is authoritative for pins and corroborates values. Every source must independently declare the expected board and revision. Missing source revision blocks before modifying the netlist; an approval's expected revision is not evidence for an absent source revision. Conflicting approved facts require resolution by the authority, not a guessed export correction.

Match components by reference designator and pins by pin number, not file order. Parse quantities dimensionally: `kOhm` = 1000 ohms, `Ohm` = ohms, `nF` = 1e-9 F, `uF` = 1e-6 F, `F` = F. Reject unsupported units; IC identifiers remain literal strings. Detect missing/duplicate references and mismatched pin sets. Correct only discrepancies fully supported by valid source evidence, preserving all unrelated data and equivalent notation.

Required seeded-demo finding codes are `value_mismatch`, `pin_mapping_mismatch`, and `equivalent_notation`; after reconciliation the engineering status is `pass`, exit 0, and `changed_files` is `["derived/netlist.json"]`. The seeded transfer is blocked by missing source revision: include `missing_source_revision`, explain which approved source is needed, leave the netlist byte-for-byte unchanged, use `changed_files: []`, status `blocked`, and exit 2. Do not invent recovery evidence. These seeded outcomes are acceptance expectations; derive them from the actual evidence.

## HW2 behavior

Input fields are SI numbers: `r_top_ohm` (Rt), `r_bottom_ohm` (Rb), `resistor_tolerance_fraction` (t), `c_farad` (C), `vin_max_v`, and `adc_max_v`, plus nonempty board/revision. Validate finite positive values and `0 < t < 1`, matching the supplied generator's supported input domain. The model uses an ideal source, unloaded divider, ideal high-impedance ADC, independent resistor tolerances, and nominal capacitor from ADC node to ground; it excludes loading, sampling transients, leakage, temperature drift, and capacitor tolerance.

| Calculation key | Equation |
|---|---|
| `nominal_gain` | `Rb / (Rt + Rb)` |
| `worst_case_gain` | `Rb*(1+t) / (Rt*(1-t) + Rb*(1+t))` |
| `nominal_adc_v` | `vin_max_v * nominal_gain` |
| `worst_case_adc_v` | `vin_max_v * worst_case_gain` |
| `r_th_ohm` | `Rt*Rb / (Rt+Rb)` |
| `cutoff_hz` | `1 / (2*pi*r_th_ohm*C)` |
| `inverse_gain` | `(Rt+Rb) / Rb` |
| `adc_margin_v` | `adc_max_v - worst_case_adc_v` |

The output is highest with upper resistor at minimum and lower resistor at maximum. Compare worst-case ADC voltage to the limit: equality passes; exceeding it fails. Preserve design failure after calibration regeneration; do not redesign sources to force a pass. Include `stale_calibration` for the seeded stale artifact, plus `adc_limit_exceeded` when the source calculation exceeds the limit.

Use the existing generator, preserving its implementation:

```bash
python tools/generate_calibration.py --config source/circuit.json --output derived/calibration.json --replace
```

Invoke this with the workspace as cwd, or pass absolute paths and use the same Python interpreter. Check the process result and verify output content. The output contains schema_version, board_id, source_revision, inverse_gain, and source_sha256. The digest is SHA-256 of UTF-8 `json.dumps(config, sort_keys=True, separators=(",", ":"), allow_nan=False)`, including every source field. This low-level tool emits nominal calibration; it does not assess worst-case safety. Both seeded cases require `changed_files: ["derived/calibration.json"]`; demo engineering assessment passes with exit 0, transfer fails the design limit with exit 1.

## External evaluation command

Run from the checkout containing `training_ci/` and `training_kit/` (or `materials/`):

```bash
python training_ci/grade_hardware.py --lab hw1 --workspace work/hw1-demo --mode code
python training_ci/grade_hardware.py --lab hw2 --workspace work/hw2-transfer-md --mode md-only
python training_ci/grade_hardware.py --lab hw2 --workspace work/hw2-transfer-code --mode code
```

The independent instructor checker validates authoritative inputs, exact report fields, component/value/pin agreement or blocked preservation, numerical results, and calibration provenance. Numeric acceptance uses relative tolerance 1e-8 and absolute tolerance 1e-9. The grader saves its commands, real stdout/stderr, return codes, and idempotence hashes to `evidence/grade_hardware.json`. Passing this check is CI evidence for the synthetic task, not physical hardware certification or a substitute for reviewing the learning artifacts.
<shellId: 0 completed with exit code 0>
````

</details>


---

<sub>4s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/demo && cat REPORT_CONTRACT.md workflow.md report.json; ls evidence derived source tools; cat source/circuit.json derived/calibration.json; diff workflow.md workflow-md-only.md && echo same; sed -n 1,200p tools/generate_calibration.py**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/demo && cat REPORT_CONTRACT.md workflow.md report.json; ls evidence derived source tools; cat source/circuit.json derived/calibration.json; diff workflow.md workflow-md-only.md && echo same; sed -n 1,200p tools/generate_calibration.py

<details>
<summary>220 lines</summary>

````
# Hardware report and calculation contract

Required equations, where `Rt` is the upper resistor, `Rb` the lower resistor, `t` the fractional tolerance, and `C` the shunt capacitor:

| Quantity / report key | Equation |
|---|---|
| `nominal_gain` | `Rb / (Rt + Rb)` |
| `worst_case_gain` | `Rb*(1+t) / (Rt*(1-t) + Rb*(1+t))` |
| `nominal_adc_v` | `vin_max_v * nominal_gain` |
| `worst_case_adc_v` | `vin_max_v * worst_case_gain` |
| `r_th_ohm` | `Rt*Rb / (Rt+Rb)` with ideal voltage source shorted |
| `cutoff_hz` | `1 / (2*pi*r_th_ohm*C)`; nominal only |
| `inverse_gain` | `(Rt+Rb) / Rb`; reconstruct input as `ADC_voltage * inverse_gain` |
| `adc_margin_v` | `adc_max_v - worst_case_adc_v` |

The worst upper output voltage occurs at upper-resistor minimum and lower-resistor maximum. A nominal-only pass is insufficient. Report `pass` only when worst-case voltage does not exceed the ADC maximum; otherwise report `fail`. Do not modify the circuit to force a pass.

The seeded calibration coefficient is stale. Compare it and its source revision/digest to the current config. After the manual review, run the existing low-level emitter:

```bash
python3 tools/generate_calibration.py --config source/circuit.json --output derived/calibration.json --replace
python3 -m json.tool derived/calibration.json
```

This generator emits nominal `inverse_gain` plus provenance only. It does not assess voltage limits or decide pass/fail. Its Python interface is `calibration_from_config(config: dict) -> dict`; its CLI is identical in both workflow arms. `--replace` explicitly authorizes replacing a derived file; omission refuses an existing output. Invalid nonpositive or nonfinite required values fail before replacement. It also refuses output equal to input and symlink output.

`source_sha256` is SHA-256 over the UTF-8 encoding of `json.dumps(config, sort_keys=True, separators=(",", ":"), allow_nan=False)`. The digest includes all config fields. This canonicalization ignores JSON whitespace and object-key order, but not changes to numeric representation such as `30` versus `30.0`. Regeneration is deterministic and creates no timestamps. Record a failed transfer circuit honestly even after the nominal coefficient is regenerated.


## Required `report.json` contract

Create this file manually after inspection, then let the later automation produce the same schema. There is no prefilled report in a starter.

| Key | Required value / shape |
|---|---|
| `schema_version` | Integer `1` |
| `lab`, `case` | `hw1` or `hw2`; `demo` or `transfer` |
| `board_id` | Actual source board ID, never hardcoded from demo |
| `status` | Engineering assessment: `pass`, `fail`, or `blocked` |
| `findings` | Array of objects with `code`, nonempty `evidence`, nonempty `explanation`; add `ref` for component findings |
| `changed_files` | Relative derived artifact paths changed; excludes the report, workflow documents, session evidence, and automation implementation |
| `assumptions` | Nonempty array documenting authority/model limits |
| `calculations` | HW2 only: object containing all eight numeric keys from the equations table; retain at least 10 significant digits |

Evidence should point to exact fields or rows, for example `source/schematic.json:components[ref=U1].pins` and the before/after export values. HW1 findings use `value_mismatch`, `pin_mapping_mismatch`, and `equivalent_notation`; blocked transfer uses `missing_source_revision` and explains what authoritative evidence is needed. HW2 uses `stale_calibration` and, when appropriate, `adc_limit_exceeded`. A resolved discrepancy remains in findings so the audit trail explains the changes. HW1 successful reconciliation lists `derived/netlist.json`; blocked reconciliation lists no changed artifacts. HW2 lists `derived/calibration.json` after regeneration. The report's `status` describes the engineering assessment. The instructor check passes when the submission faithfully reports and handles that assessment, including a design `fail` or evidence `blocked` outcome.

# Workflow: ideal voltage-divider ADC limit check and calibration refresh

Reusable for any prepared workspace of this task type. Every concrete value below is a named input read from the workspace at run time; none is a constant of this procedure.

## Named inputs
| Name | Meaning | Validation |
|---|---|---|
| `WORKSPACE` | Prepared workspace root; resolve all paths against it | exists; contains the files below |
| `SOURCE` | `source/circuit.json`, the sole authority for design values | exists, valid JSON object |
| `Rt`, `Rb` (`r_top_ohm`, `r_bottom_ohm`) | Upper / lower resistor, ohms | finite, > 0 |
| `t` (`resistor_tolerance_fraction`) | Independent resistor tolerance | finite, 0 < t < 1 |
| `C` (`c_farad`) | Nominal shunt capacitor, farads | finite, > 0 |
| `Vin_max` (`vin_max_v`), `ADC_max` (`adc_max_v`) | Max input voltage / ADC limit, volts | finite, > 0 |
| `BOARD`, `REVISION` | Identity and revision from SOURCE | nonempty strings |
| `CALIBRATION` | `derived/calibration.json`, the single derived artifact | may be absent or stale |
| `GENERATOR` | `tools/generate_calibration.py`, supplied, never edited | exists |
| `REPORT_CONTRACT` | `REPORT_CONTRACT.md` for report schema and precision | exists |

Numbers are SI units. Take `case` (demo/transfer) only from the contract's fixture bookkeeping for the board ID, never use it or the board ID to pick engineering results.

## Authority and invariants
- SOURCE is authority. Never edit `source/`, `tools/`, or `REPORT_CONTRACT.md`. Never change the design to force a pass.
- Allowed writes: `CALIBRATION`, `report.json`, `evidence/`, and workflow/automation files when the stage calls for them.
- Model: ideal source, unloaded divider, ideal high-impedance ADC, independent resistor tolerances, nominal capacitor from divider node to ground. Loading, sampling transients, leakage, temperature drift and capacitor tolerance are out of scope. Whether the model fits a real design is an engineer's judgment, not a result of this procedure.
- Maximum output occurs with the upper resistor at its minimum (Rt(1-t)) and the lower at its maximum (Rb(1+t)); both raise Rb/(Rt+Rb). A nominal-only pass is insufficient.
- Digest: `source_sha256` = SHA-256 of UTF-8 `json.dumps(config, sort_keys=True, separators=(",", ":"), allow_nan=False)` over every source field. Numeric representation counts (`30` differs from `30.0`).
- Design assessment is independent of whether regeneration succeeded. A design failure stays visible after a correct regeneration.
- Report only executed results; keep any unrun check labelled as not run.

## Steps
1. Read the task card and `REPORT_CONTRACT`. Confirm the equations and model limits.
2. Read SOURCE and validate every named input (table above). On any missing or invalid input go to "Missing or invalid input".
3. Read the existing `CALIBRATION` and record its revision, `inverse_gain` and `source_sha256` as the before values (keep them for the report). If absent, record "absent".
4. Read `GENERATOR` before running it. Confirm it emits only nominal `inverse_gain` plus provenance and does not judge limits.
5. Compute from SOURCE values, one quantity at a time, stating the equation first, and record unrounded results:
   - `nominal_gain = Rb / (Rt + Rb)`
   - `worst_case_gain = Rb*(1+t) / (Rt*(1-t) + Rb*(1+t))`
   - `nominal_adc_v = Vin_max * nominal_gain`
   - `worst_case_adc_v = Vin_max * worst_case_gain`
   - `r_th_ohm = Rt*Rb / (Rt+Rb)`
   - `cutoff_hz = 1 / (2*pi*r_th_ohm*C)` (nominal only)
   - `inverse_gain = (Rt+Rb) / Rb`
   - `adc_margin_v = ADC_max - worst_case_adc_v`
6. Compute the canonical digest. Compare digest, revision and `inverse_gain` with the before values. Any difference, or an absent file, is `stale_calibration`; all three equal means current.
7. Evaluate the limit: `worst_case_adc_v <= ADC_max` is `pass` (equality passes); otherwise `fail` plus an `adc_limit_exceeded` finding.
8. Regenerate with the supplied tool (cwd = `WORKSPACE`, or absolute paths with the same interpreter):
   `python3 tools/generate_calibration.py --config source/circuit.json --output derived/calibration.json --replace`
   `--replace` authorizes replacing only this derived file; without it an existing output is refused.
9. Verify: return code 0; `board_id` and `source_revision` equal SOURCE; `inverse_gain` equals step 5; digest equals step 6. Optionally run it again and confirm identical bytes.
10. Write `report.json` per `REPORT_CONTRACT`: `status` = step 7; findings with before/after evidence naming exact fields; `changed_files` = `["derived/calibration.json"]` only if the file changed during the task; assumptions; all eight calculations with at least 10 significant digits.
11. Log commands, observations and rationale to `evidence/`. Confirm SOURCE and `tools/` are unchanged.

## Missing or invalid input
- Any required file, field, nonempty string, finite positive value or `0 < t < 1` is missing or invalid: status `blocked`. Do not run the generator, do not modify `CALIBRATION`, `changed_files` is `[]`, and the report names each missing or invalid field and what authority must supply it. Do not guess or default values.
- Generator nonzero exit or output failing step 9: status `blocked`, include its error text, do not hand-edit the derived file, source stays unchanged.
- If a combined shell command is refused, use separate single-purpose commands or the file viewer.

## Branches
| Condition | Handling | Tested? |
|---|---|---|
| Stale calibration and worst case within limit | `stale_calibration`, regenerate, `pass` | Observed once (one fixture) |
| Calibration already current | No stale finding, no claimed change; keep any prior cumulative findings and `changed_files` | Not tested |
| Worst case exceeds limit | `fail` with `adc_limit_exceeded`, still regenerate, report both | Not tested |
| Worst case equals limit | `pass` | Not tested |
| Invalid or missing input | `blocked` as above | Not tested |
| Generator error or refusal (no `--replace`, output equals input, symlink output) | `blocked` as above | Not tested |
| Repeat run with unchanged source | Keep the report stable, retain original before-values, verify the current artifact instead of trusting an old `pass` | Not tested |
| Source changed since the last report | Start a new report; keep prior evidence separately | Not tested |
| Instructor checker | Run only when separately authorized | Not run |

## Evidence to keep
Raw output of each of the eight quantities, before and after calibration contents, both digests, generator return code, report content.

## Completion criteria
- Eight values recorded and the limit evaluated against current SOURCE.
- Calibration revision, `inverse_gain` and digest match current SOURCE.
- Report is valid against `REPORT_CONTRACT`, status reflects the engineering result, and failures or blocks are not hidden.
- SOURCE and `tools/` unchanged; regeneration repeatable for identical input.
{
  "schema_version": 1,
  "lab": "hw2",
  "case": "demo",
  "board_id": "DIVIDER-ALPHA",
  "status": "pass",
  "findings": [
    {
      "code": "stale_calibration",
      "evidence": "derived/calibration.json before regeneration: source_revision=D2, inverse_gain=10.0, source_sha256=000...0 (64 zeros). source/circuit.json: source_revision=D3, (r_top_ohm+r_bottom_ohm)/r_bottom_ohm=11.0, canonical sha256=16e661ed90b7a489a6ad5a83cdcfaeab9c3c7405775c3eafb25a0a2502aa1cc1. After regeneration: D3, 11.0, matching digest.",
      "explanation": "The existing calibration had an old revision, a wrong coefficient and a placeholder digest, so it did not describe the current source. It was regenerated with tools/generate_calibration.py."
    }
  ],
  "changed_files": ["derived/calibration.json"],
  "assumptions": [
    "source/circuit.json is the authority; values are SI units.",
    "Ideal source, unloaded divider, ideal high-impedance ADC, nominal capacitor from ADC node to ground.",
    "Independent resistor tolerances of +/-t; worst case uses minimum upper resistor and maximum lower resistor.",
    "No ADC loading, sampling transient, leakage, temperature drift, or capacitor tolerance is modeled.",
    "Worst-case ADC voltage 2.777268560953254 V does not exceed the 3.3 V limit, so no adc_limit_exceeded finding. The result is for the idealized model only, not physical hardware."
  ],
  "calculations": {
    "nominal_gain": 0.09090909090909091,
    "worst_case_gain": 0.0925756186984418,
    "nominal_adc_v": 2.7272727272727275,
    "worst_case_adc_v": 2.777268560953254,
    "r_th_ohm": 9090.90909090909,
    "cutoff_hz": 175.0704374010849,
    "inverse_gain": 11.0,
    "adc_margin_v": 0.5227314390467459
  }
}
derived:
calibration.json

evidence:
session.md
stage1-execution.json
stage1-prompt.txt
stage1-response.txt
stage1-transcript.md
stage2-execution.json
stage2-prompt.txt
stage2-response.txt
stage2-transcript.md
stage3-prompt.txt
stage3-response.txt

source:
circuit.json

tools:
generate_calibration.py
{
  "schema_version": 1,
  "board_id": "DIVIDER-ALPHA",
  "source_revision": "D3",
  "r_top_ohm": 100000,
  "r_bottom_ohm": 10000,
  "resistor_tolerance_fraction": 0.01,
  "c_farad": 1e-07,
  "vin_max_v": 30.0,
  "adc_max_v": 3.3,
  "model": "Ideal DC source, unloaded divider, ideal capacitor from ADC node to ground. Resistor tolerances independent; capacitor nominal only."
}
{
  "schema_version": 1,
  "board_id": "DIVIDER-ALPHA",
  "source_revision": "D3",
  "inverse_gain": 11.0,
  "source_sha256": "16e661ed90b7a489a6ad5a83cdcfaeab9c3c7405775c3eafb25a0a2502aa1cc1"
}
same
#!/usr/bin/env python3
"""Low-level nominal calibration emitter; does not assess circuit safety or tolerance."""
import argparse
import hashlib
import json
import math
from pathlib import Path


def calibration_from_config(config):
    """Emit nominal inverse gain and a digest of the complete source configuration."""
    required = ("r_top_ohm", "r_bottom_ohm", "resistor_tolerance_fraction", "c_farad", "vin_max_v", "adc_max_v")
    for key in required:
        value = config[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
            raise ValueError(f"{key} must be a finite positive number")
    if config["resistor_tolerance_fraction"] >= 1:
        raise ValueError("resistor_tolerance_fraction must be less than 1")
    if not isinstance(config["board_id"], str) or not config["board_id"]:
        raise ValueError("board_id must be a nonempty string")
    if not isinstance(config["source_revision"], str) or not config["source_revision"]:
        raise ValueError("source_revision must be a nonempty string")
    canonical = json.dumps(config, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    inverse_gain = (config["r_top_ohm"] + config["r_bottom_ohm"]) / config["r_bottom_ohm"]
    return {"schema_version": 1, "board_id": config["board_id"], "source_revision": config["source_revision"],
            "inverse_gain": inverse_gain, "source_sha256": hashlib.sha256(canonical).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--replace", action="store_true", help="explicitly replace an existing derived output")
    args = parser.parse_args()
    if args.output.resolve() == args.config.resolve():
        parser.error("source configuration cannot be the output")
    if args.output.exists() and not args.replace:
        parser.error("output exists; use --replace for an authorized derived artifact")
    if args.output.is_symlink():
        parser.error("refusing symlink output")
    try:
        result = calibration_from_config(json.loads(args.config.read_text(encoding="utf-8")))
        encoded = json.dumps(result, indent=2, allow_nan=False) + "\n"
    except (KeyError, ValueError, TypeError, OSError) as exc:
        parser.error(str(exc))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w" if args.replace else "x", encoding="utf-8") as stream:
        stream.write(encoded)
    print(f"Wrote nominal calibration to {args.output}")


if __name__ == "__main__":
    main()
<shellId: 1 completed with exit code 0>
````

</details>


---

<sub>34s</sub>

### `create`

**create a new file at /home/runner/work/ABB-Training/ABB-Training/runs/hw2/demo/extraction-map.md.**

/home/runner/work/ABB-Training/ABB-Training/runs/hw2/demo/extraction-map.md

```
Created file /home/runner/work/ABB-Training/ABB-Training/runs/hw2/demo/extraction-map.md with 9062 characters
```


---

<sub>37s</sub>

### Copilot

I wrote `extraction-map.md` in the demo workspace. It is the only file I changed, and I wrote no automation code. I reviewed `workflow.md` and the contract files by reading them only, so no calculations, generator runs or checks were executed in this stage.

- **Step table:** it covers each workflow step with purpose, inputs, operation, expected output, failure condition and a disposition (deterministic code, model judgment or human decision).
- **Function contracts:** every proposed function has an input and output contract. They are ordered as collection, parsing, calculation, comparison, validation, then reporting.
- **Stays with humans:** judging whether the ideal model fits a real design, redesign after a limit failure, and approving changes to assumptions.
- **Gaps for stage 4:** the fail, equality, invalid-input, generator-refusal, repeat-run and changed-source branches are marked "not tested" in `workflow.md`. The existing `report.json` holds the original stale-calibration values only as free text, so stage 4 should preserve them and recompute rather than trust the old `pass`.

---

<sub>Generated by [GitHub Copilot CLI](https://github.com/features/copilot/cli)</sub>
