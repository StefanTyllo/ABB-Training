#!/usr/bin/env python3
"""HW2 guardrails: voltage-divider ADC limit check and calibration freshness.

Usage: python automation/guardrails.py --workspace /absolute/path/to/workspace

Exit codes: 0 = pass, 1 = design limit failed, 2 = blocked (bad/missing input
or generator/verification failure). All paths resolve against --workspace.
The supplied tools/generate_calibration.py is invoked, never reimplemented.
"""
import argparse
import hashlib
import json
import math
import subprocess
import sys
from pathlib import Path

CALIBRATION_REL = "derived/calibration.json"
REPORT_REL = "report.json"
LOG_REL = "evidence/guardrails.log"
EVIDENCE_REL = "evidence/guardrails-evidence.json"
# Fixture bookkeeping only: sets the report "case", never an engineering result.
CASE_BY_BOARD = {"SENSE-ALPHA": "demo", "DIVIDER-ALPHA": "demo",
                 "SENSE-BETA": "transfer", "DIVIDER-BETA": "transfer"}
NUMERIC_FIELDS = ("r_top_ohm", "r_bottom_ohm", "resistor_tolerance_fraction",
                  "c_farad", "vin_max_v", "adc_max_v")
TEXT_FIELDS = ("board_id", "source_revision")
CALC_KEYS = ("nominal_gain", "worst_case_gain", "nominal_adc_v", "worst_case_adc_v",
             "r_th_ohm", "cutoff_hz", "inverse_gain", "adc_margin_v")
BASE_ASSUMPTIONS = [
    "source/circuit.json is the authority; values are SI units.",
    "Ideal source, unloaded divider, ideal high-impedance ADC, nominal capacitor from ADC node to ground.",
    "Independent resistor tolerances of +/-t; worst case uses minimum upper resistor and maximum lower resistor.",
    "No ADC loading, sampling transient, leakage, temperature drift, or capacitor tolerance is modeled.",
]


class InputError(Exception):
    """Missing or invalid authority/input that blocks assessment."""


class Logger:
    """Collects log lines; appended to the evidence log at the end of a run."""

    def __init__(self):
        self.lines = []

    def __call__(self, message):
        self.lines.append(message)
        print(message)


# ---------------------------------------------------------------- collection
def load_json(path):
    """Parse a JSON object from path or raise InputError."""
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise InputError(f"cannot read JSON {path}: {exc}")
    if not isinstance(data, dict):
        raise InputError(f"{path} must contain a JSON object")
    return data


def detect_lab(workspace):
    """Return 'hw2' iff source/circuit.json exists and no HW1 source files do."""
    has_hw2 = (workspace / "source" / "circuit.json").is_file()
    hw1 = [n for n in ("approval.json", "bom.csv", "schematic.json")
           if (workspace / "source" / n).exists()]
    if has_hw2 and not hw1:
        return "hw2"
    if not has_hw2 and not hw1:
        raise InputError("source/circuit.json is missing; cannot infer lab")
    raise InputError("ambiguous or non-HW2 source files: " + ", ".join(hw1 or ["circuit.json"]))


def read_calibration(path):
    """Return the parsed existing calibration, or None when absent/unreadable."""
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


# ---------------------------------------------------------------- validation
def validate_config(cfg):
    """Return a list of problems (empty when valid). Never raises on bad data."""
    problems = []
    for key in NUMERIC_FIELDS:
        value = cfg.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            problems.append(f"{key}: missing or not a number (observed {value!r})")
        elif not math.isfinite(value) or value <= 0:
            problems.append(f"{key}: must be finite and > 0 (observed {value!r})")
    t = cfg.get("resistor_tolerance_fraction")
    if isinstance(t, (int, float)) and not isinstance(t, bool) and math.isfinite(t) and t >= 1:
        problems.append(f"resistor_tolerance_fraction: must satisfy 0 < t < 1 (observed {t!r})")
    for key in TEXT_FIELDS:
        value = cfg.get(key)
        if not isinstance(value, str) or not value.strip():
            problems.append(f"{key}: must be a nonempty string (observed {value!r})")
    return problems


# --------------------------------------------------------------- calculations
def nominal_gain(rt, rb):
    """Rb / (Rt + Rb), dimensionless."""
    return rb / (rt + rb)


def worst_case_gain(rt, rb, tol):
    """Maximum gain: upper resistor at Rt(1-t), lower at Rb(1+t)."""
    rb_max = rb * (1 + tol)
    rt_min = rt * (1 - tol)
    return rb_max / (rt_min + rb_max)


def adc_voltage(vin_max_v, gain):
    """ADC node volts = maximum input volts * gain."""
    return vin_max_v * gain


def thevenin_resistance(rt, rb):
    """Rt*Rb / (Rt+Rb) ohms, ideal source shorted."""
    return rt * rb / (rt + rb)


def cutoff_hz(r_th_ohm, c_farad):
    """Nominal RC cutoff 1 / (2*pi*R*C) in hertz."""
    return 1 / (2 * math.pi * r_th_ohm * c_farad)


def inverse_gain(rt, rb):
    """(Rt+Rb) / Rb, used to reconstruct input from ADC voltage."""
    return (rt + rb) / rb


def adc_margin(adc_max_v, worst_case_adc_v):
    """Signed margin in volts; negative when the limit is exceeded."""
    return adc_max_v - worst_case_adc_v


def calculate_all(cfg, log):
    """Compute the eight contract quantities with logged substituted values."""
    rt, rb, tol = cfg["r_top_ohm"], cfg["r_bottom_ohm"], cfg["resistor_tolerance_fraction"]
    cap, vin, adc = cfg["c_farad"], cfg["vin_max_v"], cfg["adc_max_v"]
    log(f"inputs: Rt={rt!r} ohm, Rb={rb!r} ohm, t={tol!r}, C={cap!r} F, Vin_max={vin!r} V, ADC_max={adc!r} V")
    calc = {}
    calc["nominal_gain"] = nominal_gain(rt, rb)
    log(f"nominal_gain = {rb!r}/({rt!r}+{rb!r}) = {calc['nominal_gain']!r}")
    rt_min, rb_max = rt * (1 - tol), rb * (1 + tol)
    calc["worst_case_gain"] = worst_case_gain(rt, rb, tol)
    log(f"worst_case_gain: Rt_min={rt_min!r} ohm, Rb_max={rb_max!r} ohm -> {calc['worst_case_gain']!r}")
    calc["nominal_adc_v"] = adc_voltage(vin, calc["nominal_gain"])
    log(f"nominal_adc_v = {vin!r} V * {calc['nominal_gain']!r} = {calc['nominal_adc_v']!r} V")
    calc["worst_case_adc_v"] = adc_voltage(vin, calc["worst_case_gain"])
    log(f"worst_case_adc_v = {vin!r} V * {calc['worst_case_gain']!r} = {calc['worst_case_adc_v']!r} V")
    calc["r_th_ohm"] = thevenin_resistance(rt, rb)
    log(f"r_th_ohm = {rt!r}*{rb!r}/({rt!r}+{rb!r}) = {calc['r_th_ohm']!r} ohm")
    calc["cutoff_hz"] = cutoff_hz(calc["r_th_ohm"], cap)
    log(f"cutoff_hz = 1/(2*pi*{calc['r_th_ohm']!r}*{cap!r}) = {calc['cutoff_hz']!r} Hz")
    calc["inverse_gain"] = inverse_gain(rt, rb)
    log(f"inverse_gain = ({rt!r}+{rb!r})/{rb!r} = {calc['inverse_gain']!r}")
    calc["adc_margin_v"] = adc_margin(adc, calc["worst_case_adc_v"])
    log(f"adc_margin_v = {adc!r} - {calc['worst_case_adc_v']!r} = {calc['adc_margin_v']!r} V")
    if not all(math.isfinite(calc[k]) for k in CALC_KEYS):
        raise InputError("a calculated quantity is not finite: " + json.dumps(calc))
    return calc


def assess_limit(worst_case_adc_v, adc_max_v):
    """'pass' when worst case <= limit (equality passes), else 'fail'."""
    return "pass" if worst_case_adc_v <= adc_max_v else "fail"


# ------------------------------------------------------------------ freshness
def canonical_digest(cfg):
    """SHA-256 of the canonical JSON of the full source object (contract form)."""
    text = json.dumps(cfg, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def compare_calibration(before, cfg, calc, digest):
    """List mismatches between an existing calibration and current source."""
    if before is None:
        return ["calibration absent or unreadable"]
    diffs = []
    if before.get("board_id") != cfg["board_id"]:
        diffs.append(f"board_id {before.get('board_id')!r} != {cfg['board_id']!r}")
    if before.get("source_revision") != cfg["source_revision"]:
        diffs.append(f"source_revision {before.get('source_revision')!r} != {cfg['source_revision']!r}")
    gain = before.get("inverse_gain")
    if (isinstance(gain, bool) or not isinstance(gain, (int, float))
            or not math.isclose(gain, calc["inverse_gain"], rel_tol=1e-9, abs_tol=1e-12)):
        diffs.append(f"inverse_gain {gain!r} != {calc['inverse_gain']!r}")
    if before.get("source_sha256") != digest:
        diffs.append(f"source_sha256 {before.get('source_sha256')!r} != {digest!r}")
    return diffs


def run_generator(workspace, log):
    """Run the supplied generator with absolute paths and this interpreter."""
    cmd = [sys.executable, str(workspace / "tools" / "generate_calibration.py"),
           "--config", str(workspace / "source" / "circuit.json"),
           "--output", str(workspace / CALIBRATION_REL), "--replace"]
    log("generator command: python tools/generate_calibration.py --config source/circuit.json "
        "--output derived/calibration.json --replace")
    proc = subprocess.run(cmd, cwd=workspace, capture_output=True, text=True)
    output = (proc.stdout + proc.stderr).strip()
    log(f"generator returncode={proc.returncode} output={output!r}")
    return proc.returncode, output


def write_if_changed(path, text):
    """Write UTF-8 text only when bytes differ; return True if changed."""
    path = Path(path)
    data = text.encode("utf-8")
    if path.exists() and path.read_bytes() == data:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return True


def sha_of_file(path):
    """Hex SHA-256 of a file, or None if absent."""
    p = Path(path)
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None


def tree_hashes(root):
    """Map relative path -> sha256 for every file under root."""
    root = Path(root)
    if not root.is_dir():
        return {}
    return {str(p.relative_to(root)): sha_of_file(p) for p in sorted(root.rglob("*")) if p.is_file()}


# --------------------------------------------------------------------- report
def prior_report_matches(prior, cfg, calc, digest):
    """True when a previous report describes exactly the current source."""
    if not isinstance(prior, dict) or prior.get("schema_version") != 1:
        return False
    if prior.get("lab") != "hw2" or prior.get("board_id") != cfg["board_id"]:
        return False
    old = prior.get("calculations")
    if not isinstance(old, dict):
        return False
    for key in CALC_KEYS:
        value = old.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)) \
                or not math.isclose(value, calc[key], rel_tol=1e-9, abs_tol=1e-12):
            return False
    if not isinstance(prior.get("findings"), list) or not isinstance(prior.get("assumptions"), list):
        return False
    for finding in prior["findings"]:
        if finding.get("code") == "stale_calibration" and digest not in str(finding.get("evidence", "")):
            return False
    return True


def stale_finding(before, cfg, calc, digest, diffs):
    """Finding preserving the original (before) calibration values."""
    if before is None:
        before_text = "absent"
    else:
        before_text = (f"source_revision={before.get('source_revision')}, "
                       f"inverse_gain={before.get('inverse_gain')}, source_sha256={before.get('source_sha256')}")
    return {
        "code": "stale_calibration",
        "evidence": (f"{CALIBRATION_REL} before regeneration: {before_text}. source/circuit.json: "
                     f"source_revision={cfg['source_revision']}, (r_top_ohm+r_bottom_ohm)/r_bottom_ohm="
                     f"{calc['inverse_gain']!r}, canonical sha256={digest}. Mismatches: {'; '.join(diffs)}. "
                     f"After regeneration: {cfg['source_revision']}, {calc['inverse_gain']!r}, matching digest."),
        "explanation": ("The existing calibration did not describe the current source (revision, coefficient "
                        "or digest differed). It was regenerated with tools/generate_calibration.py."),
    }


def limit_finding(cfg, calc):
    """Finding recording a worst-case ADC limit violation."""
    return {
        "code": "adc_limit_exceeded",
        "evidence": (f"source/circuit.json:vin_max_v={cfg['vin_max_v']!r}, adc_max_v={cfg['adc_max_v']!r}; "
                     f"worst_case_adc_v={calc['worst_case_adc_v']!r} V exceeds the limit, "
                     f"adc_margin_v={calc['adc_margin_v']!r} V."),
        "explanation": ("Worst-case divider output (upper resistor at minimum, lower at maximum) exceeds the "
                        "ADC limit. The design is reported as failing; it was not modified to force a pass."),
    }


def build_report(cfg, calc, status, findings, changed, assumptions):
    """Assemble the contract report; no timestamps or absolute paths."""
    return {"schema_version": 1, "lab": "hw2", "case": CASE_BY_BOARD.get(cfg["board_id"], "demo"),
            "board_id": cfg["board_id"], "status": status, "findings": findings,
            "changed_files": changed, "assumptions": assumptions, "calculations": calc}


def blocked_report(cfg, problems):
    """Report for missing/invalid input; names each problem, no calculations."""
    board = cfg.get("board_id")
    if not isinstance(board, str) or not board:
        return None
    return {"schema_version": 1, "lab": "hw2", "case": CASE_BY_BOARD.get(board, "demo"), "board_id": board,
            "status": "blocked",
            "findings": [{"code": "invalid_input",
                          "evidence": "source/circuit.json: " + "; ".join(problems),
                          "explanation": "Assessment is blocked; the source authority must supply valid values. "
                                         "No value was guessed."}],
            "changed_files": [], "assumptions": BASE_ASSUMPTIONS + ["Assessment blocked; no result is claimed."]}


def dump_report(report):
    """Deterministic JSON text."""
    return json.dumps(report, indent=2, allow_nan=False) + "\n"


def archive_prior(workspace, prior_text, log):
    """Keep a superseded report separately under evidence/ (never overwritten)."""
    name = "report.superseded-" + hashlib.sha256(prior_text.encode("utf-8")).hexdigest()[:12] + ".json"
    write_if_changed(workspace / "evidence" / name, prior_text)
    log(f"previous report archived as evidence/{name}")


def write_evidence(workspace, data):
    """Machine-readable evidence (stable bytes for identical input)."""
    write_if_changed(workspace / EVIDENCE_REL, json.dumps(data, indent=2, sort_keys=True, allow_nan=False) + "\n")


# ----------------------------------------------------------------------- main
def block(workspace, cfg, problems, log, prior_text):
    """Write a blocked report (archiving any different prior) and return 2."""
    report = blocked_report(cfg, problems)
    if report is not None:
        text = dump_report(report)
        if prior_text is not None and prior_text != text:
            archive_prior(workspace, prior_text, log)
        write_if_changed(workspace / REPORT_REL, text)
    write_evidence(workspace, {"status": "blocked", "problems": problems})
    return 2


def run(workspace, log):
    """Execute the full assessment; return the exit code."""
    report_path = workspace / REPORT_REL
    before_hashes = {"source": tree_hashes(workspace / "source"), "tools": tree_hashes(workspace / "tools")}
    prior_text = report_path.read_text(encoding="utf-8") if report_path.is_file() else None
    cfg = {}
    try:
        log(f"lab inferred: {detect_lab(workspace)}")
        cfg = load_json(workspace / "source" / "circuit.json")
        problems = validate_config(cfg)
        if problems:
            raise InputError("; ".join(problems))
        if not (workspace / "tools" / "generate_calibration.py").is_file():
            raise InputError("tools/generate_calibration.py is missing")
    except InputError as exc:
        log(f"BLOCKED: expected valid HW2 source; observed: {exc}")
        return block(workspace, cfg, [str(exc)], log, prior_text)

    log(f"source revision={cfg['source_revision']} board={cfg['board_id']}")
    calc = calculate_all(cfg, log)
    digest = canonical_digest(cfg)
    log(f"canonical source sha256={digest}")
    calibration_path = workspace / CALIBRATION_REL
    before = read_calibration(calibration_path)
    before_bytes = calibration_path.read_bytes() if calibration_path.is_file() else None
    diffs = compare_calibration(before, cfg, calc, digest)
    log("freshness: expected current calibration matching source; observed " +
        ("STALE: " + "; ".join(diffs) if diffs else "current"))

    status = assess_limit(calc["worst_case_adc_v"], cfg["adc_max_v"])
    log(f"limit: expected worst_case_adc_v <= {cfg['adc_max_v']!r} V; observed "
        f"{calc['worst_case_adc_v']!r} V margin {calc['adc_margin_v']!r} V -> {status}")

    rc, output = run_generator(workspace, log)
    verify = []
    if rc != 0:
        verify.append(f"generator failed rc={rc}: {output}")
    else:
        after = read_calibration(calibration_path)
        verify = compare_calibration(after, cfg, calc, digest)
    if verify:
        log("BLOCKED: expected regenerated calibration to match source; observed: " + "; ".join(verify))
        return block(workspace, cfg, ["generator/verification: " + "; ".join(verify)], log, prior_text)
    log("verification: regenerated calibration matches source board, revision, inverse_gain and digest")
    changed_now = before_bytes != calibration_path.read_bytes()
    log(f"calibration bytes changed this run: {changed_now}")

    try:
        prior = json.loads(prior_text) if prior_text is not None else None
    except ValueError:
        prior = None
    findings, changed, assumptions = [], [], None
    if prior_report_matches(prior, cfg, calc, digest):
        log("prior report matches current source; retaining its cumulative audit")
        findings = [f for f in prior["findings"] if f.get("code") != "adc_limit_exceeded"]
        changed = [c for c in prior.get("changed_files", []) if c == CALIBRATION_REL]
        assumptions = [a for a in prior["assumptions"] if isinstance(a, str)]
    elif prior_text is not None:
        archive_prior(workspace, prior_text, log)
        log("prior report does not match current source; starting a new report")
    if diffs and not any(f.get("code") == "stale_calibration" for f in findings):
        findings.insert(0, stale_finding(before, cfg, calc, digest, diffs))
    if (diffs or changed_now) and CALIBRATION_REL not in changed:
        changed.append(CALIBRATION_REL)
    if status == "fail":
        findings.append(limit_finding(cfg, calc))
    if not assumptions:
        verdict = "does not exceed" if status == "pass" else "EXCEEDS"
        assumptions = BASE_ASSUMPTIONS + [
            f"Worst-case ADC voltage {calc['worst_case_adc_v']!r} V {verdict} the {cfg['adc_max_v']!r} V limit. "
            "The result is for the idealized model only, not physical hardware."]
    report = build_report(cfg, calc, status, findings, changed, assumptions)
    log(f"report.json written (changed={write_if_changed(report_path, dump_report(report))}) status={status}")

    after_hashes = {"source": tree_hashes(workspace / "source"), "tools": tree_hashes(workspace / "tools")}
    if after_hashes != before_hashes:
        log("BLOCKED: expected source/ and tools/ unchanged; observed a change")
        return 2
    log("source/ and tools/ unchanged")
    write_evidence(workspace, {"status": status, "source_sha256": digest, "calculations": calc,
                               "stale_mismatches": diffs, "generator_returncode": rc,
                               "calibration_sha256": sha_of_file(calibration_path),
                               "source_tree_sha256": after_hashes["source"],
                               "tools_tree_sha256": after_hashes["tools"]})
    return 0 if status == "pass" else 1


def main(argv=None):
    """CLI entry point."""
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--workspace", required=True, type=Path)
    args = parser.parse_args(argv)
    workspace = args.workspace.resolve()
    log = Logger()
    if not workspace.is_dir():
        print(f"BLOCKED: workspace {workspace} does not exist", file=sys.stderr)
        return 2
    try:
        code = run(workspace, log)
    finally:
        # Append-only log: may grow, not a stable artifact.
        (workspace / "evidence").mkdir(exist_ok=True)
        with (workspace / LOG_REL).open("a", encoding="utf-8") as stream:
            stream.write("--- run ---\n" + "\n".join(log.lines) + "\n")
    return code


if __name__ == "__main__":
    sys.exit(main())
