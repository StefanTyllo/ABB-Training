# HW2 automation

Standard library only. Run from anywhere; all paths resolve against `--workspace`.

## Commands
```bash
# Assess the workspace (regenerates derived/calibration.json via tools/generate_calibration.py, writes report.json)
python automation/guardrails.py --workspace /absolute/path/to/workspace

# Checks (disposable fixtures are created and removed under automation/tests/)
python -m unittest discover -s automation/tests -v
```

## Exit codes
| Code | Meaning |
|---|---|
| 0 | `pass`: worst-case ADC voltage <= limit (equality passes) |
| 1 | `fail`: limit exceeded; calibration is still regenerated and `adc_limit_exceeded` recorded |
| 2 | `blocked`: missing/invalid input, generator failure, or verification mismatch; derived file not hand-edited |

## Outputs
- `report.json`, `derived/calibration.json`: stable, byte-identical on repeat runs for the same source. A matching prior report keeps its original `stale_calibration` before-values and `changed_files`; a changed source starts a new report and archives the old one as `evidence/report.superseded-<hash>.json`.
- `evidence/guardrails-evidence.json`: machine-readable digest, calculations, mismatches, generator return code, file hashes.
- `evidence/guardrails.log`: append-only expected/observed log with units and substituted values. Stage 1-3 evidence is never touched.

## Checks (`automation/tests/test_guardrails.py`)
Valid demo with stale calibration; repeat-run byte stability; worst-case limit violation (nominal passes, worst case fails); equality at limit passes; nonpositive/tolerance/missing-field/missing-file blocks; generator failure blocks; changed input invalidates old provenance; changed source archives old report; numeric representation changes the digest; current calibration is not reported stale.
Not covered: generator refusals for symlink output or output equal to input.
