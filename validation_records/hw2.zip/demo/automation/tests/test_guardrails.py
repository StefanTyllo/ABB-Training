"""Checks for automation/guardrails.py using disposable fixtures under automation/tests/.

Run: python -m unittest discover -s automation/tests -v   (from the workspace)
The real source/, tools/ and derived/ are only read (to copy into fixtures).
"""
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
WORKSPACE = TESTS_DIR.parent.parent
GUARDRAILS = WORKSPACE / "automation" / "guardrails.py"
sys.path.insert(0, str(WORKSPACE / "automation"))
import guardrails  # noqa: E402

STALE_CALIBRATION = {"schema_version": 1, "board_id": "DIVIDER-ALPHA", "source_revision": "D2",
                     "inverse_gain": 10.0, "source_sha256": "0" * 64}


class GuardrailsCase(unittest.TestCase):
    """Base class building a throwaway workspace per test."""

    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="fixture-", dir=TESTS_DIR))
        self.addCleanup(shutil.rmtree, self.root, True)
        for name in ("source", "tools"):
            shutil.copytree(WORKSPACE / name, self.root / name)
        shutil.copy(WORKSPACE / "REPORT_CONTRACT.md", self.root)
        (self.root / "derived").mkdir()
        self.write_calibration(STALE_CALIBRATION)

    def write_calibration(self, data):
        (self.root / "derived" / "calibration.json").write_text(json.dumps(data, indent=2) + "\n")

    def edit_source(self, **changes):
        path = self.root / "source" / "circuit.json"
        cfg = json.loads(path.read_text())
        cfg.update(changes)
        path.write_text(json.dumps(cfg, indent=2) + "\n")
        return cfg

    def run_helper(self):
        return subprocess.run([sys.executable, str(GUARDRAILS), "--workspace", str(self.root)],
                              capture_output=True, text=True)

    def report(self):
        return json.loads((self.root / "report.json").read_text())

    def digest(self, rel):
        return hashlib.sha256((self.root / rel).read_bytes()).hexdigest()


class ValidDemo(GuardrailsCase):
    def test_valid_demo_passes_and_regenerates(self):
        source_before = self.digest("source/circuit.json")
        proc = self.run_helper()
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        report = self.report()
        self.assertEqual(report["status"], "pass")
        self.assertEqual(report["case"], "demo")
        self.assertEqual(report["changed_files"], ["derived/calibration.json"])
        self.assertEqual([f["code"] for f in report["findings"]], ["stale_calibration"])
        self.assertIn("source_revision=D2", report["findings"][0]["evidence"])
        self.assertAlmostEqual(report["calculations"]["worst_case_adc_v"], 2.777268560953254, places=12)
        self.assertAlmostEqual(report["calculations"]["cutoff_hz"], 175.0704374010849, places=9)
        cal = json.loads((self.root / "derived" / "calibration.json").read_text())
        self.assertEqual(cal["source_revision"], "D3")
        self.assertEqual(cal["inverse_gain"], 11.0)
        self.assertEqual(self.digest("source/circuit.json"), source_before)

    def test_repeat_run_is_byte_stable_and_keeps_audit(self):
        self.assertEqual(self.run_helper().returncode, 0)
        first = (self.digest("report.json"), self.digest("derived/calibration.json"))
        self.assertEqual(self.run_helper().returncode, 0)
        self.assertEqual((self.digest("report.json"), self.digest("derived/calibration.json")), first)
        report = self.report()
        self.assertEqual(report["changed_files"], ["derived/calibration.json"])
        self.assertEqual(report["findings"][0]["code"], "stale_calibration")


class LimitBranches(GuardrailsCase):
    def test_worst_case_violation_fails_visibly(self):
        # Nominal 2.727 V passes a 2.75 V limit but the 2.777 V worst case does not.
        self.edit_source(adc_max_v=2.75)
        proc = self.run_helper()
        self.assertEqual(proc.returncode, 1, proc.stdout)
        report = self.report()
        self.assertEqual(report["status"], "fail")
        codes = [f["code"] for f in report["findings"]]
        self.assertIn("adc_limit_exceeded", codes)
        self.assertIn("stale_calibration", codes)
        self.assertLess(report["calculations"]["adc_margin_v"], 0)
        self.assertLess(report["calculations"]["nominal_adc_v"], 2.75)
        self.assertEqual(report["changed_files"], ["derived/calibration.json"])

    def test_equality_with_limit_passes(self):
        cfg = json.loads((self.root / "source" / "circuit.json").read_text())
        exact = guardrails.adc_voltage(cfg["vin_max_v"], guardrails.worst_case_gain(
            cfg["r_top_ohm"], cfg["r_bottom_ohm"], cfg["resistor_tolerance_fraction"]))
        self.edit_source(adc_max_v=exact)
        proc = self.run_helper()
        self.assertEqual(proc.returncode, 0, proc.stdout)
        self.assertEqual(self.report()["calculations"]["adc_margin_v"], 0.0)


class InvalidInput(GuardrailsCase):
    def assert_blocked_untouched(self, proc):
        self.assertEqual(proc.returncode, 2, proc.stdout)
        report = self.report()
        self.assertEqual(report["status"], "blocked")
        self.assertEqual(report["changed_files"], [])
        self.assertNotIn("calculations", report)
        cal = json.loads((self.root / "derived" / "calibration.json").read_text())
        self.assertEqual(cal, STALE_CALIBRATION)

    def test_nonpositive_resistor_blocks(self):
        self.edit_source(r_bottom_ohm=0)
        proc = self.run_helper()
        self.assert_blocked_untouched(proc)
        self.assertIn("r_bottom_ohm", self.report()["findings"][0]["evidence"])

    def test_tolerance_of_one_blocks(self):
        self.edit_source(resistor_tolerance_fraction=1)
        self.assert_blocked_untouched(self.run_helper())

    def test_missing_field_blocks(self):
        path = self.root / "source" / "circuit.json"
        cfg = json.loads(path.read_text())
        del cfg["vin_max_v"]
        path.write_text(json.dumps(cfg))
        proc = self.run_helper()
        self.assert_blocked_untouched(proc)
        self.assertIn("vin_max_v", self.report()["findings"][0]["evidence"])

    def test_missing_source_file_blocks_without_report(self):
        (self.root / "source" / "circuit.json").unlink()
        proc = self.run_helper()
        self.assertEqual(proc.returncode, 2)
        self.assertFalse((self.root / "report.json").exists())

    def test_generator_failure_blocks(self):
        (self.root / "tools" / "generate_calibration.py").write_text("import sys; sys.exit(3)\n")
        proc = self.run_helper()
        self.assertEqual(proc.returncode, 2)
        self.assertEqual(self.report()["status"], "blocked")


class Provenance(GuardrailsCase):
    def test_changed_input_invalidates_old_calibration(self):
        self.assertEqual(self.run_helper().returncode, 0)
        cfg = json.loads((self.root / "source" / "circuit.json").read_text())
        old_cal = json.loads((self.root / "derived" / "calibration.json").read_text())
        self.assertEqual(old_cal["source_sha256"], guardrails.canonical_digest(cfg))
        cfg["r_top_ohm"] = 120000
        calc = guardrails.calculate_all(cfg, lambda _m: None)
        diffs = guardrails.compare_calibration(old_cal, cfg, calc, guardrails.canonical_digest(cfg))
        self.assertTrue(any("source_sha256" in d for d in diffs))
        self.assertTrue(any("inverse_gain" in d for d in diffs))

    def test_changed_source_starts_new_report_and_archives_old(self):
        self.assertEqual(self.run_helper().returncode, 0)
        old_report = (self.root / "report.json").read_text()
        self.edit_source(r_top_ohm=120000, adc_max_v=2.3)
        proc = self.run_helper()
        self.assertEqual(proc.returncode, 1)
        report = self.report()
        stale = [f for f in report["findings"] if f["code"] == "stale_calibration"]
        self.assertEqual(len(stale), 1)
        self.assertIn("source_sha256", stale[0]["evidence"])
        self.assertNotIn(old_report, json.dumps(report))
        archived = list((self.root / "evidence").glob("report.superseded-*.json"))
        self.assertEqual(len(archived), 1)
        self.assertEqual(archived[0].read_text(), old_report)

    def test_numeric_representation_changes_digest(self):
        cfg = json.loads((self.root / "source" / "circuit.json").read_text())
        other = dict(cfg, vin_max_v=int(cfg["vin_max_v"]))
        self.assertNotEqual(guardrails.canonical_digest(cfg), guardrails.canonical_digest(other))

    def test_current_calibration_is_not_reported_stale(self):
        cfg = json.loads((self.root / "source" / "circuit.json").read_text())
        subprocess.run([sys.executable, str(self.root / "tools" / "generate_calibration.py"),
                        "--config", str(self.root / "source" / "circuit.json"),
                        "--output", str(self.root / "derived" / "calibration.json"), "--replace"], check=True)
        self.assertEqual(self.run_helper().returncode, 0)
        report = self.report()
        self.assertEqual(report["findings"], [])
        self.assertEqual(report["changed_files"], [])
        self.assertEqual(cfg["board_id"], report["board_id"])


if __name__ == "__main__":
    unittest.main()
