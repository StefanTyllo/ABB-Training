# Workflow: ideal voltage-divider ADC limit check and calibration refresh

Reusable for any prepared workspace of this task type. Every concrete value below is a named input read from the workspace at run time; none is a constant of this procedure.

## Named inputs
| Name | Meaning | Validation |
|---|---|---|
| `WORKSPACE` | Prepared workspace root; resolve all paths against it | exists; contains the files below |
| `SOURCE` | `source/circuit.json`, the sole authority for design values | exists, valid JSON object |
| `Rt`, `Rb` (`r_top_ohm`, `r_bottom_ohm`) | Upper / lower resistor, ohms | finite, > 0 |
| `t` (`resistor_tolerance_fraction`) | Independent resistor tolerance | finite, 0 < t < 1 |
| `C` (`c_farad`) | Nominal shunt capacitor, farads | finite, > 0 |
| `Vin_max` (`vin_max_v`), `ADC_max` (`adc_max_v`) | Max input voltage / ADC limit, volts | finite, > 0 |
| `BOARD`, `REVISION` | Identity and revision from SOURCE | nonempty strings |
| `CALIBRATION` | `derived/calibration.json`, the single derived artifact | may be absent or stale |
| `GENERATOR` | `tools/generate_calibration.py`, supplied, never edited | exists |
| `REPORT_CONTRACT` | `REPORT_CONTRACT.md` for report schema and precision | exists |

Numbers are SI units. Take `case` (demo/transfer) only from the contract's fixture bookkeeping for the board ID, never use it or the board ID to pick engineering results.

## Authority and invariants
- SOURCE is authority. Never edit `source/`, `tools/`, or `REPORT_CONTRACT.md`. Never change the design to force a pass.
- Allowed writes: `CALIBRATION`, `report.json`, `evidence/`, and workflow/automation files when the stage calls for them.
- Model: ideal source, unloaded divider, ideal high-impedance ADC, independent resistor tolerances, nominal capacitor from divider node to ground. Loading, sampling transients, leakage, temperature drift and capacitor tolerance are out of scope. Whether the model fits a real design is an engineer's judgment, not a result of this procedure.
- Maximum output occurs with the upper resistor at its minimum (Rt(1-t)) and the lower at its maximum (Rb(1+t)); both raise Rb/(Rt+Rb). A nominal-only pass is insufficient.
- Digest: `source_sha256` = SHA-256 of UTF-8 `json.dumps(config, sort_keys=True, separators=(",", ":"), allow_nan=False)` over every source field. Numeric representation counts (`30` differs from `30.0`).
- Design assessment is independent of whether regeneration succeeded. A design failure stays visible after a correct regeneration.
- Report only executed results; keep any unrun check labelled as not run.

## Steps
1. Read the task card and `REPORT_CONTRACT`. Confirm the equations and model limits.
2. Read SOURCE and validate every named input (table above). On any missing or invalid input go to "Missing or invalid input".
3. Read the existing `CALIBRATION` and record its revision, `inverse_gain` and `source_sha256` as the before values (keep them for the report). If absent, record "absent".
4. Read `GENERATOR` before running it. Confirm it emits only nominal `inverse_gain` plus provenance and does not judge limits.
5. Compute from SOURCE values, one quantity at a time, stating the equation first, and record unrounded results:
   - `nominal_gain = Rb / (Rt + Rb)`
   - `worst_case_gain = Rb*(1+t) / (Rt*(1-t) + Rb*(1+t))`
   - `nominal_adc_v = Vin_max * nominal_gain`
   - `worst_case_adc_v = Vin_max * worst_case_gain`
   - `r_th_ohm = Rt*Rb / (Rt+Rb)`
   - `cutoff_hz = 1 / (2*pi*r_th_ohm*C)` (nominal only)
   - `inverse_gain = (Rt+Rb) / Rb`
   - `adc_margin_v = ADC_max - worst_case_adc_v`
6. Compute the canonical digest. Compare digest, revision and `inverse_gain` with the before values. Any difference, or an absent file, is `stale_calibration`; all three equal means current.
7. Evaluate the limit: `worst_case_adc_v <= ADC_max` is `pass` (equality passes); otherwise `fail` plus an `adc_limit_exceeded` finding.
8. Regenerate with the supplied tool (cwd = `WORKSPACE`, or absolute paths with the same interpreter):
   `python3 tools/generate_calibration.py --config source/circuit.json --output derived/calibration.json --replace`
   `--replace` authorizes replacing only this derived file; without it an existing output is refused.
9. Verify: return code 0; `board_id` and `source_revision` equal SOURCE; `inverse_gain` equals step 5; digest equals step 6. Optionally run it again and confirm identical bytes.
10. Write `report.json` per `REPORT_CONTRACT`: `status` = step 7; findings with before/after evidence naming exact fields; `changed_files` = `["derived/calibration.json"]` only if the file changed during the task; assumptions; all eight calculations with at least 10 significant digits.
11. Log commands, observations and rationale to `evidence/`. Confirm SOURCE and `tools/` are unchanged.

## Automated execution (stage 4)
Steps 2-11 are implemented by `automation/guardrails.py` (details in `automation/README.md`). The agent runs it, then reads results instead of recalculating by hand:
```bash
python automation/guardrails.py --workspace /absolute/path/to/workspace
python -m unittest discover -s automation/tests -v
```
- Exit 0 = `pass`, 1 = `fail` (design limit exceeded; still regenerated and reported with `adc_limit_exceeded`), 2 = `blocked` (invalid/missing input or generator/verification failure).
- Interpret results from `report.json` (status, findings, eight calculations), `evidence/guardrails-evidence.json` (machine-readable digest/hash evidence) and `evidence/guardrails.log` (expected vs observed lines with units and substituted values; append-only).
- A `pass` means only that the ideal-model worst case does not exceed the ADC limit; `adc_margin_v` is the headroom in volts. A `fail` is an engineering result to hand to the designer, never something to fix by editing source. Model applicability and redesign remain human decisions (steps 1 and 12 stay manual reasoning).
- Repeat runs on unchanged source keep `report.json` and `derived/calibration.json` byte-identical and retain the original `stale_calibration` before-values. A changed source starts a new report; the old one is archived as `evidence/report.superseded-<hash>.json`.
- Branch checks are in `automation/tests/test_guardrails.py` (the table below records them).

## Missing or invalid input
- Any required file, field, nonempty string, finite positive value or `0 < t < 1` is missing or invalid: status `blocked`. Do not run the generator, do not modify `CALIBRATION`, `changed_files` is `[]`, and the report names each missing or invalid field and what authority must supply it. Do not guess or default values.
- Generator nonzero exit or output failing step 9: status `blocked`, include its error text, do not hand-edit the derived file, source stays unchanged.
- If a combined shell command is refused, use separate single-purpose commands or the file viewer.

## Branches
| Condition | Handling | Tested? |
|---|---|---|
| Stale calibration and worst case within limit | `stale_calibration`, regenerate, `pass` | Observed once (one fixture) |
| Calibration already current | No stale finding, no claimed change; keep any prior cumulative findings and `changed_files` | Automated check |
| Worst case exceeds limit | `fail` with `adc_limit_exceeded`, still regenerate, report both | Automated check |
| Worst case equals limit | `pass` | Automated check |
| Invalid or missing input | `blocked` as above | Automated check |
| Generator error or refusal (no `--replace`, output equals input, symlink output) | `blocked` as above | Automated check (nonzero generator exit only; other refusals not run) |
| Repeat run with unchanged source | Keep the report stable, retain original before-values, verify the current artifact instead of trusting an old `pass` | Automated check |
| Source changed since the last report | Start a new report; keep prior evidence separately | Automated check |
| Instructor checker | Run only when separately authorized | Not run |

## Evidence to keep
Raw output of each of the eight quantities, before and after calibration contents, both digests, generator return code, report content.

## Completion criteria
- Eight values recorded and the limit evaluated against current SOURCE.
- Calibration revision, `inverse_gain` and digest match current SOURCE.
- Report is valid against `REPORT_CONTRACT`, status reflects the engineering result, and failures or blocks are not hidden.
- SOURCE and `tools/` unchanged; regeneration repeatable for identical input.
