# Extraction map: divider ADC limit check and calibration refresh

Basis: `workflow.md` (steps 1-11), `task-card.md`, `REPORT_CONTRACT.md`, `tools/generate_calibration.py`. Stage 3 is design only; no reusable automation is implemented here (stage 4). All values are inputs read from `source/circuit.json` at run time; none is a constant of the procedure.

Dispositions: **DC** = deterministic code, **MJ** = model judgment, **HD** = human decision.

## Step review

| # | Step | Purpose | Inputs | Operation | Expected output | Failure condition | Disposition |
|---|---|---|---|---|---|---|---|
| 1 | Read task card / contract | Learn equations, model limits, allowed writes | `task-card.md`, `REPORT_CONTRACT.md` | Read | Equation table, report schema | Contract file missing | MJ (reading); equations are then encoded as DC |
| 2 | Collect source | Obtain the sole design authority | `WORKSPACE`, `source/circuit.json` | Open, `json.loads` | dict | File absent, bad JSON, not an object | DC |
| 2a | Validate inputs | Reject unusable data before any compute or write | dict: `r_top_ohm`, `r_bottom_ohm`, `resistor_tolerance_fraction`, `c_farad`, `vin_max_v`, `adc_max_v`, `board_id`, `source_revision` | Per field: present, numeric (not bool), finite, > 0; `0<t<1`; ids nonempty strings | Empty error list, or list naming each bad field | Any field missing/invalid -> `blocked`, no generator run, no derived change | DC |
| 2b | Does the ideal model fit the real design? | Scope check | Model text, application | Engineering judgment | Accept/reject model | Loading, leakage, drift, sampling transient, C tolerance matter | HD (MJ may assist) |
| 3 | Collect existing calibration (before values) | Preserve pre-correction evidence | `derived/calibration.json` | Read, parse; record revision, `inverse_gain`, digest | before-dict or `absent` | Unparseable file is treated as stale/absent, not an error | DC |
| 4 | Review generator | Confirm it only emits nominal gain + provenance | `tools/generate_calibration.py` | Read once | Understanding that it does not judge limits | Generator absent | MJ (one-time review); runtime existence check is DC |
| 5 | Calculate eight quantities | Produce reported numbers | validated inputs | Contract equations; keep unrounded floats | 8 floats | Division by zero or non-finite result (excluded by 2a; re-check) | DC |
| 6a | Canonical digest | Provenance key | source dict | SHA-256 of `json.dumps(sort_keys, (",",":"), allow_nan=False)` | 64-hex string | Non-serializable value | DC |
| 6b | Freshness comparison | Detect stale calibration | before-dict, current revision, `inverse_gain`, digest | Equality on all three (digest/revision exact; gain with tolerance rel 1e-9) | `stale` or `current` | Absent file, or any mismatch -> `stale_calibration` | DC |
| 7 | Limit comparison | Engineering assessment | `worst_case_adc_v`, `adc_max_v` | `<=` (equality passes) | `pass`/`fail`; `adc_limit_exceeded` when fail | Exceeds limit -> `fail` (must stay visible) | DC |
| 7b | What to do on fail | Respond to a violated limit | Failed assessment | Choose new resistors/ADC/divider | New design | Redesign must NOT be done to force a pass | HD |
| 8 | Regenerate calibration | Refresh nominal artifact | config path, output path | Run supplied generator via `subprocess` with `--replace`, same interpreter | rc 0, new file | rc != 0 or refusal -> `blocked`, no hand-edit | DC (wraps supplied tool, not reimplemented) |
| 9 | Verify regeneration | Confirm artifact matches source | new calibration, step 5/6 values | Parse; compare `board_id`, `source_revision`, `inverse_gain`, digest | ok / list of mismatches | Any mismatch -> `blocked` with error text | DC |
| 9b | Repeatability | Idempotence | Output bytes after run 1 and run 2 | Hash compare | Identical | Differs (timestamps, ordering) | DC |
| 10 | Write report | Record assessment | all results above, prior report if any | Assemble JSON, stable key order, no timestamps; `changed_files` only if the derived file actually changed in this task | `report.json` | Report disagrees with recalculation; stale prior report trusted blindly | DC for structure/numbers; MJ for wording of explanations and assumptions |
| 10b | Reuse prior report | Cumulative audit | existing `report.json`, current digest | Reuse only if source identity/digest match and artifact verifies; else start new, keep old evidence separately | Stable or new report | Source changed since report | DC |
| 11 | Log evidence; confirm source and tools unchanged | Audit | commands, outputs, file hashes | Append to `evidence/`; hash `source/` and `tools/` before/after | Log; equal hashes | Hash change | DC |
| 12 | Interpret result | Explain why the worst-case extremes (Rt min, Rb max) give the maximum; engineering meaning of margin | numbers | Explanation | Narrative | n/a | MJ; approval of assumption changes is HD |

## Proposed functions (stage 4 candidates; priority: collection, parsing, calculation, comparison, validation, reporting)

| Function | Input contract | Output contract | Errors / notes |
|---|---|---|---|
| `load_json(path: Path) -> dict` | Existing file path inside workspace | Parsed JSON object | `InputError` if missing, invalid JSON, or not an object |
| `detect_lab(workspace: Path) -> str` | Workspace dir | `"hw2"` iff `source/circuit.json` exists (and HW1 files absent) | `InputError` if missing or ambiguous |
| `validate_config(cfg: dict) -> list[str]` | Parsed source | List of problem strings (empty = valid); checks all 8 fields, bool excluded, finite, `>0`, `0<t<1`, nonempty ids | Pure; never raises on bad data |
| `nominal_gain(rt, rb) -> float` | Ohms >0 | `rb/(rt+rb)` (dimensionless) | Pure |
| `worst_case_gain(rt, rb, t) -> float` | Ohms >0, `0<t<1` | `rb(1+t)/(rt(1-t)+rb(1+t))` | Pure |
| `adc_voltage(vin_max_v, gain) -> float` | Volts >0, gain in (0,1) | Volts = `vin*gain`; used for nominal and worst case | Pure |
| `thevenin_resistance(rt, rb) -> float` | Ohms >0 | `rt*rb/(rt+rb)` ohms | Pure |
| `cutoff_hz(r_th_ohm, c_farad) -> float` | Ohms >0, farads >0 | `1/(2*pi*r*c)` Hz, nominal only | Pure |
| `inverse_gain(rt, rb) -> float` | Ohms >0 | `(rt+rb)/rb` | Pure |
| `adc_margin(adc_max_v, worst_case_adc_v) -> float` | Volts | Signed volts, negative when exceeded | Pure |
| `calculate_all(cfg: dict) -> dict` | Validated config | Dict with exactly the eight contract keys, unrounded floats | Composes functions above |
| `canonical_digest(cfg: dict) -> str` | Any JSON-serializable dict | 64-char lowercase hex SHA-256 per contract | `ValueError` on NaN/inf |
| `read_calibration(path: Path) -> dict \| None` | Path | Parsed dict, or `None` if absent/unreadable | Does not raise for absent |
| `compare_calibration(before, cfg, calc, digest) -> list[str]` | before-dict or None, config, calculations, digest | Mismatch descriptions per field (empty = current); absent -> `["absent"]` | Pure |
| `assess_limit(worst_case_adc_v, adc_max_v) -> str` | Volts | `"pass"` if `<=`, else `"fail"` | Equality passes; no rounding |
| `run_generator(ws: Path) -> (int, str)` | Workspace with tools and source | `(returncode, combined output)` from the supplied tool, invoked with `sys.executable`, absolute paths, `--replace` | No shell; generator unmodified |
| `verify_calibration(path, cfg, calc, digest) -> list[str]` | Regenerated file | Mismatch list for `board_id`, `source_revision`, `inverse_gain`, `source_sha256` | Pure after read |
| `build_report(cfg, calc, status, findings, changed, assumptions) -> dict` | Results | Dict matching REPORT_CONTRACT; `case` from the fixture map only; no timestamps/paths | Blocked: `calculations` omitted, `changed_files: []` |
| `merge_prior_report(prior, new) -> dict` | Prior report whose source digest/identity matches, plus new results | Report retaining original stale/before findings and cumulative `changed_files` | Mismatched source -> new report; prior evidence kept separately |
| `write_if_changed(path, text) -> bool` | Path, UTF-8 text | True if bytes changed | Guarantees byte-stable repeat runs |
| `log_event(msg)` | Message with units, substituted values, results, revision, limits | Appended to `evidence/` log | Logs may grow; not part of stable artifacts |
| `main(argv) -> int` | `--workspace` absolute path | Exit 0 pass, 1 fail, 2 blocked | All paths resolved against workspace |

## Observed gaps in the current Markdown workflow (to fix in stage 4)

- Branches marked "Not tested": fail, equality, invalid input, generator refusal, repeat run, changed source. Stage 4 must test them with disposable fixtures under `automation/tests/`.
- A previous `report.json` already exists for this workspace (status `pass`, one `stale_calibration` finding); the "before" values live only in that report's text. Preserve them when merging, and recompute rather than trusting it.
- Judgment (HD) items stay outside code: model applicability, redesign when a limit is exceeded, and changes to engineering assumptions.
- `case` and `board_id` bookkeeping must never select engineering results.
