# Copilot CLI Session

> [!NOTE]
> - **Session ID:** `4600e98f-a0b2-4bd0-a3d7-472e1e878a29`  
> - **Started:** 10/14/2026, 3:53:28 PM  
> - **Duration:** 1m 8s  
> - **Exported:** 10/14/2026, 3:54:37 PM  

---

<sub>1s</sub>

### User

You are performing a scripted CI rehearsal of the ABB training lab.
Your working directory is /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code. Stay in this workspace. Do not read instructor files,
external graders, other workspaces, or CI orchestration. They are independent assessment.
Read task-card.md, CI_CONTRACT.md, and the local requirements/report contract.
Use actual terminal tools; do not claim unexecuted results. Do not print environment variables
or credentials. Preserve source authorities and supplied adapters. Expected engineering failure
or blocked results must remain visible. This is a scripted rehearsal, not a human learner pilot.
FRESH TRANSFER (Markdown plus code):
Read workflow.md and execute its process using this workspace's actual inputs. Record commands, observations,
failures and decisions in evidence/session.md. Do not copy demo outputs or implementation. Fresh parser/POM/
tests still need the task-specific repair or extension. Invoke the supplied automation and retain its actual feedback.
For browser labs the correct server is already running on port 8765. Do not stop it.
Use another free port for your own variant servers and pass BASE_URL to their tests. Complete the task or
faithfully report a required blocked/fail engineering assessment. Do not invent missing source authority.


---

<sub>2s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && ls -la && cat task-card.md CI_CONTRACT.md workflow.md**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && ls -la && cat task-card.md CI_CONTRACT.md workflow.md

<details>
<summary>14 lines</summary>

```
Output too large to read at once (22.8 KB). Saved to: /tmp/1791993211703-copilot-tool-output-7776-39b2f3a1-a22f-4995-94fc-b435c1ac309f.txt
Consider using tools like grep (for searching), head/tail (for viewing start/end), view with view_range (for specific sections), or jq (for JSON) to examine portions of the output.

Preview (first 500 chars):
total 64
drwxr-xr-x 7 runner runner 4096 Oct 14 15:53 .
drwxr-xr-x 5 runner runner 4096 Oct 14 15:46 ..
-rw-r--r-- 1 runner runner 9431 Oct 14 15:46 CI_CONTRACT.md
-rw-r--r-- 1 runner runner 4043 Oct 14 15:46 REPORT_CONTRACT.md
drwxr-xr-x 3 runner runner 4096 Oct 14 15:52 automation
drwxr-xr-x 2 runner runner 4096 Oct 14 15:46 derived
drwxr-xr-x 2 runner runner 4096 Oct 14 15:53 evidence
drwxr-xr-x 2 runner runner 4096 Oct 14 15:46 source
-rw-r--r-- 1 runner runner 4807 Oct 14 15:46 task-card.md
<shellId: 0 completed with exit code 0>
```

</details>


---

<sub>4s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && cat task-card.md; ls -R . | head -60**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && cat task-card.md; ls -R . | head -60

<details>
<summary>81 lines</summary>

````
# HW2 Calculate limits and refresh calibration

**Task card.** Review an idealized voltage-divider input against its ADC voltage limit, then regenerate stale nominal calibration from the current inputs. Report the design assessment independently of whether the file generator ran successfully.

**Prepare from the training root**
```bash
python materials/prepare_lab.py hw2 demo work/hw2-demo
cd work/hw2-demo
python -m json.tool source/circuit.json
python -m json.tool derived/calibration.json
```
**Model contract:** ideal source; upper resistor Rt and lower resistor Rb; nominal capacitor C from divider node to ground; ideal high-impedance ADC. Independent resistor tolerances are +/-t. No ADC loading, sampling transient, leakage, temperature drift, or capacitor tolerance is included. Source values use SI units. These assumptions bound the exercise.

**Allowed changes:** `derived/calibration.json`, `report.json`, and common artifacts. Preserve source/circuit.json and tools/. Use REPORT_CONTRACT.md for report fields and precision.

## Stage 1 Guided operations
Calculate one quantity at a time in the terminal, explaining the equation before running it. Read values from the actual source, even when using a short Python expression.

| Quantity | Required equation |
| --- | --- |
| Nominal gain | Rb / (Rt + Rb) |
| Maximum gain | Rb*(1+t) / (Rt*(1-t) + Rb*(1+t)) |
| Nominal / maximum ADC voltage | Maximum input voltage multiplied by the corresponding gain |
| Equivalent resistance | Rt*Rb / (Rt+Rb) |
| Nominal cutoff | 1 / (2*pi*equivalent resistance*C) |
| Inverse gain | (Rt+Rb) / Rb |
| ADC margin | ADC limit minus maximum ADC voltage |

Explain why upper-resistor minimum and lower-resistor maximum maximize output. Compare the existing coefficient and provenance with current inputs. Then invoke the existing generator:
```bash
python tools/generate_calibration.py --config source/circuit.json \
  --output derived/calibration.json --replace
```
**Demonstration complete:** all eight quantities recorded, voltage limit evaluated, calibration regenerated and checked, report.json written with assumptions and evidence. Now document the observed workflow.


# HW2 Extract calculations and freshness checks

## Stage 2 Abstraction focus
All component values, tolerance, maximum input, ADC limit, and file paths are inputs. Equations and model assumptions remain explicit. Do not turn the demo's coefficient into a universal constant.

## Stage 3 Deterministic boundary
| Move into code | Retain as reasoning |
| --- | --- |
| Validate positive finite values, units, and allowed tolerance | Decide whether the ideal circuit model applies to a real design |
| Calculate quantities and intermediate values | Investigate behavior outside the model's scope |
| Compare worst-case voltage with the limit | Select a new design when a limit is exceeded |
| Regenerate calibration and compare source digest | Approve changes to engineering assumptions |

## Stage 4 Required implementation behavior
Create a calculation entry point that accepts a source JSON path and report destination. Give each equation a named function or clearly named intermediate values. Log units, substituted values, calculated results, source revision, and limits. Use the existing calibration generator; do not recreate its file format inconsistently.

Validate freshness using the canonical source digest specified in REPORT_CONTRACT.md. A design-limit failure must remain visible even if nominal calibration was regenerated correctly. The exercise asks for assessment of the supplied design, not redesign to force a pass.

**Required checks:** valid demo; worst-case limit violation; invalid/missing input; changed input invalidates old calibration provenance; regeneration is repeatable for identical input. The source JSON must remain unchanged.

**Transfer preparation, from the training root**
```bash
python materials/prepare_lab.py hw2 transfer work/hw2-transfer-md
python materials/prepare_lab.py hw2 transfer work/hw2-transfer-code
```
The upper resistor changes. Use current inputs for every calculation. Correct transfer behavior produces a design assessment of fail when the worst-case voltage exceeds the stated limit, while recording accurate recalculation and calibration provenance.

**Facilitator check**, from the training root:
```bash
python materials/hardware/instructor/check.py \
  --lab hw2 --case demo --workspace work/hw2-demo
```
Change case/workspace for transfer. The check validates numerical results and artifact provenance; it does not certify physical hardware. Compare the documented assumptions and engineering explanation as part of assessment.

**Debrief:** which parts of the calculation previously consumed model reasoning despite having a fully specified deterministic answer?
.:
CI_CONTRACT.md
REPORT_CONTRACT.md
automation
derived
evidence
source
task-card.md
tools
workflow.md

./automation:
README.md
guardrails.py
tests

./automation/tests:
test_guardrails.py

./derived:
calibration.json

./evidence:
replay-prompt.txt
replay-response.txt

./source:
circuit.json

./tools:
generate_calibration.py
<shellId: 1 completed with exit code 0>
````

</details>


---

<sub>4s</sub>

### `view`

**view the file at /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/CI_CONTRACT.md.**

/home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/CI_CONTRACT.md

<details>
<summary>60 lines</summary>

````
# Generated hardware guardrails: CI contract

This contract is for the code-implementation stage after the guided task, workflow extraction, abstraction, and deterministic-boundary review. It specifies the entry point evaluated by CI; it does not replace those learning stages. Implement the calculations/comparisons yourself using the supplied sources and low-level calibration tool. Do not read, copy, modify, or invoke instructor answers or graders from learner code.

## Entry point and ownership

Create `automation/guardrails.py` runnable with Python 3 and its standard library:

```bash
python automation/guardrails.py --workspace /absolute/path/to/prepared/workspace
```

Resolve every data/output path against `--workspace`, not the current directory. Infer the lab from its source files: HW1 has `source/approval.json`, `source/bom.csv`, and `source/schematic.json`; HW2 has `source/circuit.json`. Reject ambiguous or missing required input. The board ID must come from source data. The fixed synthetic fixture bookkeeping is `SENSE-ALPHA` / `DIVIDER-ALPHA` = `demo`, and `SENSE-BETA` / `DIVIDER-BETA` = `transfer`. This map sets the report's `case` only; never use identity, case, filenames, or cached answers to select engineering results. Calculate and compare actual source values.

Allowed outputs are `report.json`, `evidence/`, learner code/checks under `automation/`, and the lab's single derived artifact: HW1 `derived/netlist.json`, HW2 `derived/calibration.json`. Preserve all source files, supplied tools, and REPORT_CONTRACT.md. No network or external packages are needed. Tests requiring altered inputs must create disposable fixtures under `automation/tests/`; they must not edit the prepared source inputs.

| Engineering assessment | Helper exit code | Meaning |
|---|---:|---|
| `pass` | 0 | Assessment is complete and the task's engineering criteria pass |
| `fail` | 1 | Assessment is complete but the circuit exceeds its stated design limit or another engineering criterion fails |
| `blocked` | 2 | Missing/invalid authority or input prevents assessment |

The external grader returns 0 for a faithful accepted assessment, including expected engineering `fail` and `blocked`. Its default `--mode code` invokes your helper twice, runs the existing independent instructor checker after each invocation, and requires unchanged bytes in `report.json` and the derived artifact on the second invocation. `--mode md-only` checks the already-completed report and derived artifact once using the same instructor checker; it neither requires nor executes a helper and does not impose the code-run idempotence check. Use MD-only mode for the fresh Markdown-only transfer and code mode for the demonstration after stage 4 and fresh code-assisted transfer. Logs under `evidence/` may grow. Do not add timestamps, run counters, transient command output, or changing absolute paths to stable task artifacts.

Retain initial discrepancy findings, evidence, and `changed_files` as a cumulative task audit on repeat runs for the same source inputs. A resolved discrepancy remains documented; `changed_files` records artifacts changed during this task, not only writes in the latest invocation. Preserve evidence of the original values before correction. Validate any reused report against current source identity/revision/content and verify the current derived artifact; do not blindly trust an old `pass` or stale report. If the same task is already correctly reconciled and assessed, preserve its stable report. Start a new report when source inputs change, retaining prior evidence separately.

## Exact task report

Write UTF-8 `report.json` as a JSON object matching the prepared `REPORT_CONTRACT.md`. This task report is distinct from optional operation-event logs.

| Field | Required content |
|---|---|
| `schema_version` | Integer 1 |
| `lab` | `hw1` or `hw2` |
| `case` | `demo` or `transfer`, using fixture bookkeeping above |
| `board_id` | The actual source board ID |
| `status` | Engineering `pass`, `fail`, or `blocked` |
| `findings` | Array of objects containing `code`, nonempty `evidence`, nonempty `explanation`; include `ref` for component findings |
| `changed_files` | Array of relative derived artifact paths changed during the task; no report, logs, code, or workflow files |
| `assumptions` | Nonempty array describing source authority or model limits |
| `calculations` | HW2 only: all eight numeric fields below, retaining at least 10 significant digits |

Finding evidence must identify actual source/export fields and observed before/after values. Informative messages or equivalent-unit notation are findings without being engineering failures. Do not fabricate findings on a clean unrelated input.

## HW1 behavior

Read `approval.json` for the expected board, approved revision, and approved source list. BOM is authoritative for component identity, kind, and value; the schematic is authoritative for pins and corroborates values. Every source must independently declare the expected board and revision. Missing source revision blocks before modifying the netlist; an approval's expected revision is not evidence for an absent source revision. Conflicting approved facts require resolution by the authority, not a guessed export correction.

Match components by reference designator and pins by pin number, not file order. Parse quantities dimensionally: `kOhm` = 1000 ohms, `Ohm` = ohms, `nF` = 1e-9 F, `uF` = 1e-6 F, `F` = F. Reject unsupported units; IC identifiers remain literal strings. Detect missing/duplicate references and mismatched pin sets. Correct only discrepancies fully supported by valid source evidence, preserving all unrelated data and equivalent notation.

Required seeded-demo finding codes are `value_mismatch`, `pin_mapping_mismatch`, and `equivalent_notation`; after reconciliation the engineering status is `pass`, exit 0, and `changed_files` is `["derived/netlist.json"]`. The seeded transfer is blocked by missing source revision: include `missing_source_revision`, explain which approved source is needed, leave the netlist byte-for-byte unchanged, use `changed_files: []`, status `blocked`, and exit 2. Do not invent recovery evidence. These seeded outcomes are acceptance expectations; derive them from the actual evidence.

## HW2 behavior

Input fields are SI numbers: `r_top_ohm` (Rt), `r_bottom_ohm` (Rb), `resistor_tolerance_fraction` (t), `c_farad` (C), `vin_max_v`, and `adc_max_v`, plus nonempty board/revision. Validate finite positive values and `0 < t < 1`, matching the supplied generator's supported input domain. The model uses an ideal source, unloaded divider, ideal high-impedance ADC, independent resistor tolerances, and nominal capacitor from ADC node to ground; it excludes loading, sampling transients, leakage, temperature drift, and capacitor tolerance.

| Calculation key | Equation |
|---|---|
| `nominal_gain` | `Rb / (Rt + Rb)` |
| `worst_case_gain` | `Rb*(1+t) / (Rt*(1-t) + Rb*(1+t))` |
| `nominal_adc_v` | `vin_max_v * nominal_gain` |
| `worst_case_adc_v` | `vin_max_v * worst_case_gain` |
| `r_th_ohm` | `Rt*Rb / (Rt+Rb)` |
| `cutoff_hz` | `1 / (2*pi*r_th_ohm*C)` |
| `inverse_gain` | `(Rt+Rb) / Rb` |
| `adc_margin_v` | `adc_max_v - worst_case_adc_v` |

The output is highest with upper resistor at minimum and lower resistor at maximum. Compare worst-case ADC voltage to the limit: equality passes; exceeding it fails. Preserve design failure after calibration regeneration; do not redesign sources to force a pass. Include `stale_calibration` for the seeded stale artifact, plus `adc_limit_exceeded` when the source calculation exceeds the limit.

Use the existing generator, preserving its implementation:

```bash
python tools/generate_calibration.py --config source/circuit.json --output derived/calibration.json --replace
```

Invoke this with the workspace as cwd, or pass absolute paths and use the same Python interpreter. Check the process result and verify output content. The output contains schema_version, board_id, source_revision, inverse_gain, and source_sha256. The digest is SHA-256 of UTF-8 `json.dumps(config, sort_keys=True, separators=(",", ":"), allow_nan=False)`, including every source field. This low-level tool emits nominal calibration; it does not assess worst-case safety. Both seeded cases require `changed_files: ["derived/calibration.json"]`; demo engineering assessment passes with exit 0, transfer fails the design limit with exit 1.

## External evaluation command

Run from the checkout containing `training_ci/` and `training_kit/` (or `materials/`):

```bash
python training_ci/grade_hardware.py --lab hw1 --workspace work/hw1-demo --mode code
python training_ci/grade_hardware.py --lab hw2 --workspace work/hw2-transfer-md --mode md-only
python training_ci/grade_hardware.py --lab hw2 --workspace work/hw2-transfer-code --mode code
```

The independent instructor checker validates authoritative inputs, exact report fields, component/value/pin agreement or blocked preservation, numerical results, and calibration provenance. Numeric acceptance uses relative tolerance 1e-8 and absolute tolerance 1e-9. The grader saves its commands, real stdout/stderr, return codes, and idempotence hashes to `evidence/grade_hardware.json`. Passing this check is CI evidence for the synthetic task, not physical hardware certification or a substitute for reviewing the learning artifacts.
````

</details>


---

<sub>4s</sub>

### `view`

**view the file at /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/REPORT_CONTRACT.md.**

/home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/REPORT_CONTRACT.md

<details>
<summary>33 lines</summary>

````
# Hardware report and calculation contract

Required equations, where `Rt` is the upper resistor, `Rb` the lower resistor, `t` the fractional tolerance, and `C` the shunt capacitor:

| Quantity / report key | Equation |
|---|---|
| `nominal_gain` | `Rb / (Rt + Rb)` |
| `worst_case_gain` | `Rb*(1+t) / (Rt*(1-t) + Rb*(1+t))` |
| `nominal_adc_v` | `vin_max_v * nominal_gain` |
| `worst_case_adc_v` | `vin_max_v * worst_case_gain` |
| `r_th_ohm` | `Rt*Rb / (Rt+Rb)` with ideal voltage source shorted |
| `cutoff_hz` | `1 / (2*pi*r_th_ohm*C)`; nominal only |
| `inverse_gain` | `(Rt+Rb) / Rb`; reconstruct input as `ADC_voltage * inverse_gain` |
| `adc_margin_v` | `adc_max_v - worst_case_adc_v` |

The worst upper output voltage occurs at upper-resistor minimum and lower-resistor maximum. A nominal-only pass is insufficient. Report `pass` only when worst-case voltage does not exceed the ADC maximum; otherwise report `fail`. Do not modify the circuit to force a pass.

The seeded calibration coefficient is stale. Compare it and its source revision/digest to the current config. After the manual review, run the existing low-level emitter:

```bash
python3 tools/generate_calibration.py --config source/circuit.json --output derived/calibration.json --replace
python3 -m json.tool derived/calibration.json
```

This generator emits nominal `inverse_gain` plus provenance only. It does not assess voltage limits or decide pass/fail. Its Python interface is `calibration_from_config(config: dict) -> dict`; its CLI is identical in both workflow arms. `--replace` explicitly authorizes replacing a derived file; omission refuses an existing output. Invalid nonpositive or nonfinite required values fail before replacement. It also refuses output equal to input and symlink output.

`source_sha256` is SHA-256 over the UTF-8 encoding of `json.dumps(config, sort_keys=True, separators=(",", ":"), allow_nan=False)`. The digest includes all config fields. This canonicalization ignores JSON whitespace and object-key order, but not changes to numeric representation such as `30` versus `30.0`. Regeneration is deterministic and creates no timestamps. Record a failed transfer circuit honestly even after the nominal coefficient is regenerated.


## Required `report.json` contract

Create this file manually after inspection, then let the later automation produce the same schema. There is no prefilled report in a starter.

| Key | Required value / shape |
|---|---|
| `schema_version` | Integer `1` |
| `lab`, `case` | `hw1` or `hw2`; `demo` or `transfer` |
| `board_id` | Actual source board ID, never hardcoded from demo |
| `status` | Engineering assessment: `pass`, `fail`, or `blocked` |
| `findings` | Array of objects with `code`, nonempty `evidence`, nonempty `explanation`; add `ref` for component findings |
| `changed_files` | Relative derived artifact paths changed; excludes the report, workflow documents, session evidence, and automation implementation |
| `assumptions` | Nonempty array documenting authority/model limits |
| `calculations` | HW2 only: object containing all eight numeric keys from the equations table; retain at least 10 significant digits |

Evidence should point to exact fields or rows, for example `source/schematic.json:components[ref=U1].pins` and the before/after export values. HW1 findings use `value_mismatch`, `pin_mapping_mismatch`, and `equivalent_notation`; blocked transfer uses `missing_source_revision` and explains what authoritative evidence is needed. HW2 uses `stale_calibration` and, when appropriate, `adc_limit_exceeded`. A resolved discrepancy remains in findings so the audit trail explains the changes. HW1 successful reconciliation lists `derived/netlist.json`; blocked reconciliation lists no changed artifacts. HW2 lists `derived/calibration.json` after regeneration. The report's `status` describes the engineering assessment. The instructor check passes when the submission faithfully reports and handles that assessment, including a design `fail` or evidence `blocked` outcome.
````

</details>


---

<sub>7s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && cat workflow.md; echo ----; cat automation/README.md; echo ----; cat automation/guardrails.py; echo ----; cat automation/tests/test_guardrails.py; echo ----; cat source/circuit.json derived/calibration.json; cat tools/generate_calibration.py; ls evidence; head -c 600 evidence/replay-prompt.txt**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && cat workflow.md; echo ----; cat automation/README.md; echo ----; cat automation/guardrails.py; echo ----; cat automation/tests/test_guardrails.py; echo ----; cat source/circuit.json derived/calibration.json; cat tools/generate_calibration.py; ls evidence; head -c 600 evidence/replay-prompt.txt

<details>
<summary>11 lines</summary>

```
Output too large to read at once (43.5 KB). Saved to: /tmp/1791993216571-copilot-tool-output-7776-d800a944-5301-4adf-9bc6-7e83b2e2989a.txt
Consider using tools like grep (for searching), head/tail (for viewing start/end), view with view_range (for specific sections), or jq (for JSON) to examine portions of the output.

Preview (first 500 chars):
# Workflow: ideal voltage-divider ADC limit check and calibration refresh

Reusable for any prepared workspace of this task type. Every concrete value below is a named input read from the workspace at run time; none is a constant of this procedure.

## Named inputs
| Name | Meaning | Validation |
|---|---|---|
| `WORKSPACE` | Prepared workspace root; resolve all paths against it | exists; contains the files below |
| `SOURCE` | `source/circuit.json`, the sole authority for design values | exists
<shellId: 2 completed with exit code 0>
```

</details>


---

<sub>9s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && wc -c workflow.md automation/* automation/tests/* evidence/*; cat workflow.md | head -c 9000**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && wc -c workflow.md automation/* automation/tests/* evidence/*; cat workflow.md | head -c 9000

<details>
<summary>90 lines</summary>

````
8507 workflow.md
wc: automation/tests: Is a directory
   1878 automation/README.md
  20913 automation/guardrails.py
      0 automation/tests
   9290 automation/tests/test_guardrails.py
   1345 evidence/replay-prompt.txt
      0 evidence/replay-response.txt
  41933 total
# Workflow: ideal voltage-divider ADC limit check and calibration refresh

Reusable for any prepared workspace of this task type. Every concrete value below is a named input read from the workspace at run time; none is a constant of this procedure.

## Named inputs
| Name | Meaning | Validation |
|---|---|---|
| `WORKSPACE` | Prepared workspace root; resolve all paths against it | exists; contains the files below |
| `SOURCE` | `source/circuit.json`, the sole authority for design values | exists, valid JSON object |
| `Rt`, `Rb` (`r_top_ohm`, `r_bottom_ohm`) | Upper / lower resistor, ohms | finite, > 0 |
| `t` (`resistor_tolerance_fraction`) | Independent resistor tolerance | finite, 0 < t < 1 |
| `C` (`c_farad`) | Nominal shunt capacitor, farads | finite, > 0 |
| `Vin_max` (`vin_max_v`), `ADC_max` (`adc_max_v`) | Max input voltage / ADC limit, volts | finite, > 0 |
| `BOARD`, `REVISION` | Identity and revision from SOURCE | nonempty strings |
| `CALIBRATION` | `derived/calibration.json`, the single derived artifact | may be absent or stale |
| `GENERATOR` | `tools/generate_calibration.py`, supplied, never edited | exists |
| `REPORT_CONTRACT` | `REPORT_CONTRACT.md` for report schema and precision | exists |

Numbers are SI units. Take `case` (demo/transfer) only from the contract's fixture bookkeeping for the board ID, never use it or the board ID to pick engineering results.

## Authority and invariants
- SOURCE is authority. Never edit `source/`, `tools/`, or `REPORT_CONTRACT.md`. Never change the design to force a pass.
- Allowed writes: `CALIBRATION`, `report.json`, `evidence/`, and workflow/automation files when the stage calls for them.
- Model: ideal source, unloaded divider, ideal high-impedance ADC, independent resistor tolerances, nominal capacitor from divider node to ground. Loading, sampling transients, leakage, temperature drift and capacitor tolerance are out of scope. Whether the model fits a real design is an engineer's judgment, not a result of this procedure.
- Maximum output occurs with the upper resistor at its minimum (Rt(1-t)) and the lower at its maximum (Rb(1+t)); both raise Rb/(Rt+Rb). A nominal-only pass is insufficient.
- Digest: `source_sha256` = SHA-256 of UTF-8 `json.dumps(config, sort_keys=True, separators=(",", ":"), allow_nan=False)` over every source field. Numeric representation counts (`30` differs from `30.0`).
- Design assessment is independent of whether regeneration succeeded. A design failure stays visible after a correct regeneration.
- Report only executed results; keep any unrun check labelled as not run.

## Steps
1. Read the task card and `REPORT_CONTRACT`. Confirm the equations and model limits.
2. Read SOURCE and validate every named input (table above). On any missing or invalid input go to "Missing or invalid input".
3. Read the existing `CALIBRATION` and record its revision, `inverse_gain` and `source_sha256` as the before values (keep them for the report). If absent, record "absent".
4. Read `GENERATOR` before running it. Confirm it emits only nominal `inverse_gain` plus provenance and does not judge limits.
5. Compute from SOURCE values, one quantity at a time, stating the equation first, and record unrounded results:
   - `nominal_gain = Rb / (Rt + Rb)`
   - `worst_case_gain = Rb*(1+t) / (Rt*(1-t) + Rb*(1+t))`
   - `nominal_adc_v = Vin_max * nominal_gain`
   - `worst_case_adc_v = Vin_max * worst_case_gain`
   - `r_th_ohm = Rt*Rb / (Rt+Rb)`
   - `cutoff_hz = 1 / (2*pi*r_th_ohm*C)` (nominal only)
   - `inverse_gain = (Rt+Rb) / Rb`
   - `adc_margin_v = ADC_max - worst_case_adc_v`
6. Compute the canonical digest. Compare digest, revision and `inverse_gain` with the before values. Any difference, or an absent file, is `stale_calibration`; all three equal means current.
7. Evaluate the limit: `worst_case_adc_v <= ADC_max` is `pass` (equality passes); otherwise `fail` plus an `adc_limit_exceeded` finding.
8. Regenerate with the supplied tool (cwd = `WORKSPACE`, or absolute paths with the same interpreter):
   `python3 tools/generate_calibration.py --config source/circuit.json --output derived/calibration.json --replace`
   `--replace` authorizes replacing only this derived file; without it an existing output is refused.
9. Verify: return code 0; `board_id` and `source_revision` equal SOURCE; `inverse_gain` equals step 5; digest equals step 6. Optionally run it again and confirm identical bytes.
10. Write `report.json` per `REPORT_CONTRACT`: `status` = step 7; findings with before/after evidence naming exact fields; `changed_files` = `["derived/calibration.json"]` only if the file changed during the task; assumptions; all eight calculations with at least 10 significant digits.
11. Log commands, observations and rationale to `evidence/`. Confirm SOURCE and `tools/` are unchanged.

## Automated execution (stage 4)
Steps 2-11 are implemented by `automation/guardrails.py` (details in `automation/README.md`). The agent runs it, then reads results instead of recalculating by hand:
```bash
python automation/guardrails.py --workspace /absolute/path/to/workspace
python -m unittest discover -s automation/tests -v
```
- Exit 0 = `pass`, 1 = `fail` (design limit exceeded; still regenerated and reported with `adc_limit_exceeded`), 2 = `blocked` (invalid/missing input or generator/verification failure).
- Interpret results from `report.json` (status, findings, eight calculations), `evidence/guardrails-evidence.json` (machine-readable digest/hash evidence) and `evidence/guardrails.log` (expected vs observed lines with units and substituted values; append-only).
- A `pass` means only that the ideal-model worst case does not exceed the ADC limit; `adc_margin_v` is the headroom in volts. A `fail` is an engineering result to hand to the designer, never something to fix by editing source. Model applicability and redesign remain human decisions (steps 1 and 12 stay manual reasoning).
- Repeat runs on unchanged source keep `report.json` and `derived/calibration.json` byte-identical and retain the original `stale_calibration` before-values. A changed source starts a new report; the old one is archived as `evidence/report.superseded-<hash>.json`.
- Branch checks are in `automation/tests/test_guardrails.py` (the table below records them).

## Missing or invalid input
- Any required file, field, nonempty string, finite positive value or `0 < t < 1` is missing or invalid: status `blocked`. Do not run the generator, do not modify `CALIBRATION`, `changed_files` is `[]`, and the report names each missing or invalid field and what authority must supply it. Do not guess or default values.
- Generator nonzero exit or output failing step 9: status `blocked`, include its error text, do not hand-edit the derived file, source stays unchanged.
- If a combined shell command is refused, use separate single-purpose commands or the file viewer.

## Branches
| Condition | Handling | Tested? |
|---|---|---|
| Stale calibration and worst case within limit | `stale_calibration`, regenerate, `pass` | Observed once (one fixture) |
| Calibration already current | No stale finding, no claimed change; keep any prior cumulative findings and `changed_files` | Automated check |
| Worst case exceeds limit | `fail` with `adc_limit_exceeded`, still regenerate, report both | Automated check |
| Worst case equals limit | `pass` | Automated check |
| Invalid or missing input | `blocked` as above | Automated check |
| Generator error or refusal (no `--replace`, output equals input, symlink output) | `blocked` as above | Automated check (nonzero generator exit only; other refusals not run) |
| Repeat run with unchanged source | Keep the report stable, retain original before-values, verify the current artifact instead of trusting an old `pass` | Automated check |
| Source changed since the last report | Start a new report; keep prior evidence separately | Automated check |
| Instructor checker | Run only when separately authorized | Not run |

## Evidence to keep
Raw output of each of the eight quantities, before and after calibration contents, both digests, generator return code, report content.

## Completion criteria
- Eight values recorded and the limit evaluated against current SOURCE.
- Calibration revision, `inverse_gain` and digest match current SOURCE.
- Report is valid against `REPORT_CONTRACT`, status reflects the engineering result, and failures or blocks are not hidden.
- SOURCE and `tools/` unchanged; regeneration repeatable for identical input.
<shellId: 3 completed with exit code 0>
````

</details>


---

<sub>11s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && cat source/circuit.json derived/calibration.json; cat tools/generate_calibration.py; cat evidence/replay-prompt.txt; cat automation/README.md; git status --short | head**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && cat source/circuit.json derived/calibration.json; cat tools/generate_calibration.py; cat evidence/replay-prompt.txt; cat automation/README.md; git status --short | head

<details>
<summary>104 lines</summary>

````
{
  "schema_version": 1,
  "board_id": "DIVIDER-BETA",
  "source_revision": "D3",
  "r_top_ohm": 82000,
  "r_bottom_ohm": 10000,
  "resistor_tolerance_fraction": 0.01,
  "c_farad": 1e-07,
  "vin_max_v": 30.0,
  "adc_max_v": 3.3,
  "model": "Ideal DC source, unloaded divider, ideal capacitor from ADC node to ground. Resistor tolerances independent; capacitor nominal only."
}
{
  "schema_version": 1,
  "board_id": "DIVIDER-BETA",
  "source_revision": "D2",
  "inverse_gain": 10.0,
  "source_sha256": "0000000000000000000000000000000000000000000000000000000000000000"
}
#!/usr/bin/env python3
"""Low-level nominal calibration emitter; does not assess circuit safety or tolerance."""
import argparse
import hashlib
import json
import math
from pathlib import Path


def calibration_from_config(config):
    """Emit nominal inverse gain and a digest of the complete source configuration."""
    required = ("r_top_ohm", "r_bottom_ohm", "resistor_tolerance_fraction", "c_farad", "vin_max_v", "adc_max_v")
    for key in required:
        value = config[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
            raise ValueError(f"{key} must be a finite positive number")
    if config["resistor_tolerance_fraction"] >= 1:
        raise ValueError("resistor_tolerance_fraction must be less than 1")
    if not isinstance(config["board_id"], str) or not config["board_id"]:
        raise ValueError("board_id must be a nonempty string")
    if not isinstance(config["source_revision"], str) or not config["source_revision"]:
        raise ValueError("source_revision must be a nonempty string")
    canonical = json.dumps(config, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    inverse_gain = (config["r_top_ohm"] + config["r_bottom_ohm"]) / config["r_bottom_ohm"]
    return {"schema_version": 1, "board_id": config["board_id"], "source_revision": config["source_revision"],
            "inverse_gain": inverse_gain, "source_sha256": hashlib.sha256(canonical).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--replace", action="store_true", help="explicitly replace an existing derived output")
    args = parser.parse_args()
    if args.output.resolve() == args.config.resolve():
        parser.error("source configuration cannot be the output")
    if args.output.exists() and not args.replace:
        parser.error("output exists; use --replace for an authorized derived artifact")
    if args.output.is_symlink():
        parser.error("refusing symlink output")
    try:
        result = calibration_from_config(json.loads(args.config.read_text(encoding="utf-8")))
        encoded = json.dumps(result, indent=2, allow_nan=False) + "\n"
    except (KeyError, ValueError, TypeError, OSError) as exc:
        parser.error(str(exc))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w" if args.replace else "x", encoding="utf-8") as stream:
        stream.write(encoded)
    print(f"Wrote nominal calibration to {args.output}")


if __name__ == "__main__":
    main()
You are performing a scripted CI rehearsal of the ABB training lab.
Your working directory is /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code. Stay in this workspace. Do not read instructor files,
external graders, other workspaces, or CI orchestration. They are independent assessment.
Read task-card.md, CI_CONTRACT.md, and the local requirements/report contract.
Use actual terminal tools; do not claim unexecuted results. Do not print environment variables
or credentials. Preserve source authorities and supplied adapters. Expected engineering failure
or blocked results must remain visible. This is a scripted rehearsal, not a human learner pilot.
FRESH TRANSFER (Markdown plus code):
Read workflow.md and execute its process using this workspace's actual inputs. Record commands, observations,
failures and decisions in evidence/session.md. Do not copy demo outputs or implementation. Fresh parser/POM/
tests still need the task-specific repair or extension. Invoke the supplied automation and retain its actual feedback.
For browser labs the correct server is already running on port 8765. Do not stop it.
Use another free port for your own variant servers and pass BASE_URL to their tests. Complete the task or
faithfully report a required blocked/fail engineering assessment. Do not invent missing source authority.
# HW2 automation

Standard library only. Run from anywhere; all paths resolve against `--workspace`.

## Commands
```bash
# Assess the workspace (regenerates derived/calibration.json via tools/generate_calibration.py, writes report.json)
python automation/guardrails.py --workspace /absolute/path/to/workspace

# Checks (disposable fixtures are created and removed under automation/tests/)
python -m unittest discover -s automation/tests -v
```

## Exit codes
| Code | Meaning |
|---|---|
| 0 | `pass`: worst-case ADC voltage <= limit (equality passes) |
| 1 | `fail`: limit exceeded; calibration is still regenerated and `adc_limit_exceeded` recorded |
| 2 | `blocked`: missing/invalid input, generator failure, or verification mismatch; derived file not hand-edited |

## Outputs
- `report.json`, `derived/calibration.json`: stable, byte-identical on repeat runs for the same source. A matching prior report keeps its original `stale_calibration` before-values and `changed_files`; a changed source starts a new report and archives the old one as `evidence/report.superseded-<hash>.json`.
- `evidence/guardrails-evidence.json`: machine-readable digest, calculations, mismatches, generator return code, file hashes.
- `evidence/guardrails.log`: append-only expected/observed log with units and substituted values. Stage 1-3 evidence is never touched.

## Checks (`automation/tests/test_guardrails.py`)
Valid demo with stale calibration; repeat-run byte stability; worst-case limit violation (nominal passes, worst case fails); equality at limit passes; nonpositive/tolerance/missing-field/missing-file blocks; generator failure blocks; changed input invalidates old provenance; changed source archives old report; numeric representation changes the digest; current calibration is not reported stale.
Not covered: generator refusals for symlink output or output equal to input.
?? ../../
<shellId: 4 completed with exit code 0>
````

</details>


---

<sub>11s</sub>

### `view`

**view the file at /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/automation/guardrails.py.**

/home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/automation/guardrails.py

```
File too large to read at once (20.4 KB). Consider using the grep tool to search within the file, or view with view_range to read specific sections.
```


---

<sub>14s</sub>

### `view`

**view the file at /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/automation/guardrails.py.**

/home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/automation/guardrails.py (lines 1-250)

<details>
<summary>201 lines</summary>

```
#!/usr/bin/env python3
"""HW2 guardrails: voltage-divider ADC limit check and calibration freshness.

Usage: python automation/guardrails.py --workspace /absolute/path/to/workspace

Exit codes: 0 = pass, 1 = design limit failed, 2 = blocked (bad/missing input
or generator/verification failure). All paths resolve against --workspace.
The supplied tools/generate_calibration.py is invoked, never reimplemented.
"""
import argparse
import hashlib
import json
import math
import subprocess
import sys
from pathlib import Path

CALIBRATION_REL = "derived/calibration.json"
REPORT_REL = "report.json"
LOG_REL = "evidence/guardrails.log"
EVIDENCE_REL = "evidence/guardrails-evidence.json"
# Fixture bookkeeping only: sets the report "case", never an engineering result.
CASE_BY_BOARD = {"SENSE-ALPHA": "demo", "DIVIDER-ALPHA": "demo",
                 "SENSE-BETA": "transfer", "DIVIDER-BETA": "transfer"}
NUMERIC_FIELDS = ("r_top_ohm", "r_bottom_ohm", "resistor_tolerance_fraction",
                  "c_farad", "vin_max_v", "adc_max_v")
TEXT_FIELDS = ("board_id", "source_revision")
CALC_KEYS = ("nominal_gain", "worst_case_gain", "nominal_adc_v", "worst_case_adc_v",
             "r_th_ohm", "cutoff_hz", "inverse_gain", "adc_margin_v")
BASE_ASSUMPTIONS = [
    "source/circuit.json is the authority; values are SI units.",
    "Ideal source, unloaded divider, ideal high-impedance ADC, nominal capacitor from ADC node to ground.",
    "Independent resistor tolerances of +/-t; worst case uses minimum upper resistor and maximum lower resistor.",
    "No ADC loading, sampling transient, leakage, temperature drift, or capacitor tolerance is modeled.",
]


class InputError(Exception):
    """Missing or invalid authority/input that blocks assessment."""


class Logger:
    """Collects log lines; appended to the evidence log at the end of a run."""

    def __init__(self):
        self.lines = []

    def __call__(self, message):
        self.lines.append(message)
        print(message)


# ---------------------------------------------------------------- collection
def load_json(path):
    """Parse a JSON object from path or raise InputError."""
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise InputError(f"cannot read JSON {path}: {exc}")
    if not isinstance(data, dict):
        raise InputError(f"{path} must contain a JSON object")
    return data


def detect_lab(workspace):
    """Return 'hw2' iff source/circuit.json exists and no HW1 source files do."""
    has_hw2 = (workspace / "source" / "circuit.json").is_file()
    hw1 = [n for n in ("approval.json", "bom.csv", "schematic.json")
           if (workspace / "source" / n).exists()]
    if has_hw2 and not hw1:
        return "hw2"
    if not has_hw2 and not hw1:
        raise InputError("source/circuit.json is missing; cannot infer lab")
    raise InputError("ambiguous or non-HW2 source files: " + ", ".join(hw1 or ["circuit.json"]))


def read_calibration(path):
    """Return the parsed existing calibration, or None when absent/unreadable."""
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


# ---------------------------------------------------------------- validation
def validate_config(cfg):
    """Return a list of problems (empty when valid). Never raises on bad data."""
    problems = []
    for key in NUMERIC_FIELDS:
        value = cfg.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            problems.append(f"{key}: missing or not a number (observed {value!r})")
        elif not math.isfinite(value) or value <= 0:
            problems.append(f"{key}: must be finite and > 0 (observed {value!r})")
    t = cfg.get("resistor_tolerance_fraction")
    if isinstance(t, (int, float)) and not isinstance(t, bool) and math.isfinite(t) and t >= 1:
        problems.append(f"resistor_tolerance_fraction: must satisfy 0 < t < 1 (observed {t!r})")
    for key in TEXT_FIELDS:
        value = cfg.get(key)
        if not isinstance(value, str) or not value.strip():
            problems.append(f"{key}: must be a nonempty string (observed {value!r})")
    return problems


# --------------------------------------------------------------- calculations
def nominal_gain(rt, rb):
    """Rb / (Rt + Rb), dimensionless."""
    return rb / (rt + rb)


def worst_case_gain(rt, rb, tol):
    """Maximum gain: upper resistor at Rt(1-t), lower at Rb(1+t)."""
    rb_max = rb * (1 + tol)
    rt_min = rt * (1 - tol)
    return rb_max / (rt_min + rb_max)


def adc_voltage(vin_max_v, gain):
    """ADC node volts = maximum input volts * gain."""
    return vin_max_v * gain


def thevenin_resistance(rt, rb):
    """Rt*Rb / (Rt+Rb) ohms, ideal source shorted."""
    return rt * rb / (rt + rb)


def cutoff_hz(r_th_ohm, c_farad):
    """Nominal RC cutoff 1 / (2*pi*R*C) in hertz."""
    return 1 / (2 * math.pi * r_th_ohm * c_farad)


def inverse_gain(rt, rb):
    """(Rt+Rb) / Rb, used to reconstruct input from ADC voltage."""
    return (rt + rb) / rb


def adc_margin(adc_max_v, worst_case_adc_v):
    """Signed margin in volts; negative when the limit is exceeded."""
    return adc_max_v - worst_case_adc_v


def calculate_all(cfg, log):
    """Compute the eight contract quantities with logged substituted values."""
    rt, rb, tol = cfg["r_top_ohm"], cfg["r_bottom_ohm"], cfg["resistor_tolerance_fraction"]
    cap, vin, adc = cfg["c_farad"], cfg["vin_max_v"], cfg["adc_max_v"]
    log(f"inputs: Rt={rt!r} ohm, Rb={rb!r} ohm, t={tol!r}, C={cap!r} F, Vin_max={vin!r} V, ADC_max={adc!r} V")
    calc = {}
    calc["nominal_gain"] = nominal_gain(rt, rb)
    log(f"nominal_gain = {rb!r}/({rt!r}+{rb!r}) = {calc['nominal_gain']!r}")
    rt_min, rb_max = rt * (1 - tol), rb * (1 + tol)
    calc["worst_case_gain"] = worst_case_gain(rt, rb, tol)
    log(f"worst_case_gain: Rt_min={rt_min!r} ohm, Rb_max={rb_max!r} ohm -> {calc['worst_case_gain']!r}")
    calc["nominal_adc_v"] = adc_voltage(vin, calc["nominal_gain"])
    log(f"nominal_adc_v = {vin!r} V * {calc['nominal_gain']!r} = {calc['nominal_adc_v']!r} V")
    calc["worst_case_adc_v"] = adc_voltage(vin, calc["worst_case_gain"])
    log(f"worst_case_adc_v = {vin!r} V * {calc['worst_case_gain']!r} = {calc['worst_case_adc_v']!r} V")
    calc["r_th_ohm"] = thevenin_resistance(rt, rb)
    log(f"r_th_ohm = {rt!r}*{rb!r}/({rt!r}+{rb!r}) = {calc['r_th_ohm']!r} ohm")
    calc["cutoff_hz"] = cutoff_hz(calc["r_th_ohm"], cap)
    log(f"cutoff_hz = 1/(2*pi*{calc['r_th_ohm']!r}*{cap!r}) = {calc['cutoff_hz']!r} Hz")
    calc["inverse_gain"] = inverse_gain(rt, rb)
    log(f"inverse_gain = ({rt!r}+{rb!r})/{rb!r} = {calc['inverse_gain']!r}")
    calc["adc_margin_v"] = adc_margin(adc, calc["worst_case_adc_v"])
    log(f"adc_margin_v = {adc!r} - {calc['worst_case_adc_v']!r} = {calc['adc_margin_v']!r} V")
    if not all(math.isfinite(calc[k]) for k in CALC_KEYS):
        raise InputError("a calculated quantity is not finite: " + json.dumps(calc))
    return calc


def assess_limit(worst_case_adc_v, adc_max_v):
    """'pass' when worst case <= limit (equality passes), else 'fail'."""
    return "pass" if worst_case_adc_v <= adc_max_v else "fail"


# ------------------------------------------------------------------ freshness
def canonical_digest(cfg):
    """SHA-256 of the canonical JSON of the full source object (contract form)."""
    text = json.dumps(cfg, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def compare_calibration(before, cfg, calc, digest):
    """List mismatches between an existing calibration and current source."""
    if before is None:
        return ["calibration absent or unreadable"]
    diffs = []
    if before.get("board_id") != cfg["board_id"]:
        diffs.append(f"board_id {before.get('board_id')!r} != {cfg['board_id']!r}")
    if before.get("source_revision") != cfg["source_revision"]:
        diffs.append(f"source_revision {before.get('source_revision')!r} != {cfg['source_revision']!r}")
    gain = before.get("inverse_gain")
    if (isinstance(gain, bool) or not isinstance(gain, (int, float))
            or not math.isclose(gain, calc["inverse_gain"], rel_tol=1e-9, abs_tol=1e-12)):
        diffs.append(f"inverse_gain {gain!r} != {calc['inverse_gain']!r}")
    if before.get("source_sha256") != digest:
        diffs.append(f"source_sha256 {before.get('source_sha256')!r} != {digest!r}")
    return diffs


def run_generator(workspace, log):
    """Run the supplied generator with absolute paths and this interpreter."""
    cmd = [sys.executable, str(workspace / "tools" / "generate_calibration.py"),
           "--config", str(workspace / "source" / "circuit.json"),
           "--output", str(workspace / CALIBRATION_REL), "--replace"]
    log("generator command: python tools/generate_calibration.py --config source/circuit.json "
        "--output derived/calibration.json --replace")
    proc = subprocess.run(cmd, cwd=workspace, capture_output=True, text=True)
    output = (proc.stdout + proc.stderr).strip()
    log(f"generator returncode={proc.returncode} output={output!r}")
    return proc.returncode, output


def write_if_changed(path, text):
    """Write UTF-8 text only when bytes differ; return True if changed."""
    path = Path(path)
    data = text.encode("utf-8")
    if path.exists() and path.read_bytes() == data:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return True


def sha_of_file(path):
    """Hex SHA-256 of a file, or None if absent."""
    p = Path(path)
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None


def tree_hashes(root):
    """Map relative path -> sha256 for every file under root."""
    root = Path(root)
    if not root.is_dir():
        return {}
    return {str(p.relative_to(root)): sha_of_file(p) for p in sorted(root.rglob("*")) if p.is_file()}


# --------------------------------------------------------------------- report
def prior_report_matches(prior, cfg, calc, digest):
    """True when a previous report describes exactly the current source."""
    if not isinstance(prior, dict) or prior.get("schema_version") != 1:
        return False
    if prior.get("lab") != "hw2" or prior.get("board_id") != cfg["board_id"]:
        return False
    old = prior.get("calculations")
    if not isinstance(old, dict):
        return False
    for key in CALC_KEYS:
```

</details>


---

<sub>16s</sub>

### `view`

**view the file at /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/automation/guardrails.py.**

/home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/automation/guardrails.py (lines 250-480)

<details>
<summary>176 lines</summary>

```
    for key in CALC_KEYS:
        value = old.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)) \
                or not math.isclose(value, calc[key], rel_tol=1e-9, abs_tol=1e-12):
            return False
    if not isinstance(prior.get("findings"), list) or not isinstance(prior.get("assumptions"), list):
        return False
    for finding in prior["findings"]:
        if finding.get("code") == "stale_calibration" and digest not in str(finding.get("evidence", "")):
            return False
    return True


def stale_finding(before, cfg, calc, digest, diffs):
    """Finding preserving the original (before) calibration values."""
    if before is None:
        before_text = "absent"
    else:
        before_text = (f"source_revision={before.get('source_revision')}, "
                       f"inverse_gain={before.get('inverse_gain')}, source_sha256={before.get('source_sha256')}")
    return {
        "code": "stale_calibration",
        "evidence": (f"{CALIBRATION_REL} before regeneration: {before_text}. source/circuit.json: "
                     f"source_revision={cfg['source_revision']}, (r_top_ohm+r_bottom_ohm)/r_bottom_ohm="
                     f"{calc['inverse_gain']!r}, canonical sha256={digest}. Mismatches: {'; '.join(diffs)}. "
                     f"After regeneration: {cfg['source_revision']}, {calc['inverse_gain']!r}, matching digest."),
        "explanation": ("The existing calibration did not describe the current source (revision, coefficient "
                        "or digest differed). It was regenerated with tools/generate_calibration.py."),
    }


def limit_finding(cfg, calc):
    """Finding recording a worst-case ADC limit violation."""
    return {
        "code": "adc_limit_exceeded",
        "evidence": (f"source/circuit.json:vin_max_v={cfg['vin_max_v']!r}, adc_max_v={cfg['adc_max_v']!r}; "
                     f"worst_case_adc_v={calc['worst_case_adc_v']!r} V exceeds the limit, "
                     f"adc_margin_v={calc['adc_margin_v']!r} V."),
        "explanation": ("Worst-case divider output (upper resistor at minimum, lower at maximum) exceeds the "
                        "ADC limit. The design is reported as failing; it was not modified to force a pass."),
    }


def build_report(cfg, calc, status, findings, changed, assumptions):
    """Assemble the contract report; no timestamps or absolute paths."""
    return {"schema_version": 1, "lab": "hw2", "case": CASE_BY_BOARD.get(cfg["board_id"], "demo"),
            "board_id": cfg["board_id"], "status": status, "findings": findings,
            "changed_files": changed, "assumptions": assumptions, "calculations": calc}


def blocked_report(cfg, problems):
    """Report for missing/invalid input; names each problem, no calculations."""
    board = cfg.get("board_id")
    if not isinstance(board, str) or not board:
        return None
    return {"schema_version": 1, "lab": "hw2", "case": CASE_BY_BOARD.get(board, "demo"), "board_id": board,
            "status": "blocked",
            "findings": [{"code": "invalid_input",
                          "evidence": "source/circuit.json: " + "; ".join(problems),
                          "explanation": "Assessment is blocked; the source authority must supply valid values. "
                                         "No value was guessed."}],
            "changed_files": [], "assumptions": BASE_ASSUMPTIONS + ["Assessment blocked; no result is claimed."]}


def dump_report(report):
    """Deterministic JSON text."""
    return json.dumps(report, indent=2, allow_nan=False) + "\n"


def archive_prior(workspace, prior_text, log):
    """Keep a superseded report separately under evidence/ (never overwritten)."""
    name = "report.superseded-" + hashlib.sha256(prior_text.encode("utf-8")).hexdigest()[:12] + ".json"
    write_if_changed(workspace / "evidence" / name, prior_text)
    log(f"previous report archived as evidence/{name}")


def write_evidence(workspace, data):
    """Machine-readable evidence (stable bytes for identical input)."""
    write_if_changed(workspace / EVIDENCE_REL, json.dumps(data, indent=2, sort_keys=True, allow_nan=False) + "\n")


# ----------------------------------------------------------------------- main
def block(workspace, cfg, problems, log, prior_text):
    """Write a blocked report (archiving any different prior) and return 2."""
    report = blocked_report(cfg, problems)
    if report is not None:
        text = dump_report(report)
        if prior_text is not None and prior_text != text:
            archive_prior(workspace, prior_text, log)
        write_if_changed(workspace / REPORT_REL, text)
    write_evidence(workspace, {"status": "blocked", "problems": problems})
    return 2


def run(workspace, log):
    """Execute the full assessment; return the exit code."""
    report_path = workspace / REPORT_REL
    before_hashes = {"source": tree_hashes(workspace / "source"), "tools": tree_hashes(workspace / "tools")}
    prior_text = report_path.read_text(encoding="utf-8") if report_path.is_file() else None
    cfg = {}
    try:
        log(f"lab inferred: {detect_lab(workspace)}")
        cfg = load_json(workspace / "source" / "circuit.json")
        problems = validate_config(cfg)
        if problems:
            raise InputError("; ".join(problems))
        if not (workspace / "tools" / "generate_calibration.py").is_file():
            raise InputError("tools/generate_calibration.py is missing")
    except InputError as exc:
        log(f"BLOCKED: expected valid HW2 source; observed: {exc}")
        return block(workspace, cfg, [str(exc)], log, prior_text)

    log(f"source revision={cfg['source_revision']} board={cfg['board_id']}")
    calc = calculate_all(cfg, log)
    digest = canonical_digest(cfg)
    log(f"canonical source sha256={digest}")
    calibration_path = workspace / CALIBRATION_REL
    before = read_calibration(calibration_path)
    before_bytes = calibration_path.read_bytes() if calibration_path.is_file() else None
    diffs = compare_calibration(before, cfg, calc, digest)
    log("freshness: expected current calibration matching source; observed " +
        ("STALE: " + "; ".join(diffs) if diffs else "current"))

    status = assess_limit(calc["worst_case_adc_v"], cfg["adc_max_v"])
    log(f"limit: expected worst_case_adc_v <= {cfg['adc_max_v']!r} V; observed "
        f"{calc['worst_case_adc_v']!r} V margin {calc['adc_margin_v']!r} V -> {status}")

    rc, output = run_generator(workspace, log)
    verify = []
    if rc != 0:
        verify.append(f"generator failed rc={rc}: {output}")
    else:
        after = read_calibration(calibration_path)
        verify = compare_calibration(after, cfg, calc, digest)
    if verify:
        log("BLOCKED: expected regenerated calibration to match source; observed: " + "; ".join(verify))
        return block(workspace, cfg, ["generator/verification: " + "; ".join(verify)], log, prior_text)
    log("verification: regenerated calibration matches source board, revision, inverse_gain and digest")
    changed_now = before_bytes != calibration_path.read_bytes()
    log(f"calibration bytes changed this run: {changed_now}")

    try:
        prior = json.loads(prior_text) if prior_text is not None else None
    except ValueError:
        prior = None
    findings, changed, assumptions = [], [], None
    if prior_report_matches(prior, cfg, calc, digest):
        log("prior report matches current source; retaining its cumulative audit")
        findings = [f for f in prior["findings"] if f.get("code") != "adc_limit_exceeded"]
        changed = [c for c in prior.get("changed_files", []) if c == CALIBRATION_REL]
        assumptions = [a for a in prior["assumptions"] if isinstance(a, str)]
    elif prior_text is not None:
        archive_prior(workspace, prior_text, log)
        log("prior report does not match current source; starting a new report")
    if diffs and not any(f.get("code") == "stale_calibration" for f in findings):
        findings.insert(0, stale_finding(before, cfg, calc, digest, diffs))
    if (diffs or changed_now) and CALIBRATION_REL not in changed:
        changed.append(CALIBRATION_REL)
    if status == "fail":
        findings.append(limit_finding(cfg, calc))
    if not assumptions:
        verdict = "does not exceed" if status == "pass" else "EXCEEDS"
        assumptions = BASE_ASSUMPTIONS + [
            f"Worst-case ADC voltage {calc['worst_case_adc_v']!r} V {verdict} the {cfg['adc_max_v']!r} V limit. "
            "The result is for the idealized model only, not physical hardware."]
    report = build_report(cfg, calc, status, findings, changed, assumptions)
    log(f"report.json written (changed={write_if_changed(report_path, dump_report(report))}) status={status}")

    after_hashes = {"source": tree_hashes(workspace / "source"), "tools": tree_hashes(workspace / "tools")}
    if after_hashes != before_hashes:
        log("BLOCKED: expected source/ and tools/ unchanged; observed a change")
        return 2
    log("source/ and tools/ unchanged")
    write_evidence(workspace, {"status": status, "source_sha256": digest, "calculations": calc,
                               "stale_mismatches": diffs, "generator_returncode": rc,
                               "calibration_sha256": sha_of_file(calibration_path),
                               "source_tree_sha256": after_hashes["source"],
                               "tools_tree_sha256": after_hashes["tools"]})
    return 0 if status == "pass" else 1


def main(argv=None):
    """CLI entry point."""
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--workspace", required=True, type=Path)
    args = parser.parse_args(argv)
    workspace = args.workspace.resolve()
    log = Logger()
    if not workspace.is_dir():
        print(f"BLOCKED: workspace {workspace} does not exist", file=sys.stderr)
        return 2
    try:
        code = run(workspace, log)
    finally:
        # Append-only log: may grow, not a stable artifact.
        (workspace / "evidence").mkdir(exist_ok=True)
        with (workspace / LOG_REL).open("a", encoding="utf-8") as stream:
            stream.write("--- run ---\n" + "\n".join(log.lines) + "\n")
    return code


if __name__ == "__main__":
    sys.exit(main())
```

</details>


---

<sub>19s</sub>

### `bash` — Failed

**cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && sha256sum source/* tools/* > /tmp/pre.sha; python -m unittest discover -s automation/tests -v 2>&1 | tail -30; echo ==; python automation/guardrails.py --workspace $PWD; echo rc=$?; sha256sum -c /tmp/pre.sha; cat report.json derived/calibration.json**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && sha256sum source/* tools/* > /tmp/pre.sha; python -m unittest discover -s automation/tests -v 2>&1 | tail -30; echo ==; python automation/guardrails.py --workspace $PWD; echo rc=$?; sha256sum -c /tmp/pre.sha; cat report.json derived/calibration.json

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>21s</sub>

### Copilot

Retrying as separate commands.

---

<sub>22s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && python -m unittest discover -s automation/tests -v 2>&1 | tail -30**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && python -m unittest discover -s automation/tests -v 2>&1 | tail -30

<details>
<summary>28 lines</summary>

```
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/automation/tests/test_guardrails.py", line 62, in test_valid_demo_passes_and_regenerates
    self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
AssertionError: 1 != 0 : lab inferred: hw2
source revision=D3 board=DIVIDER-BETA
inputs: Rt=82000 ohm, Rb=10000 ohm, t=0.01, C=1e-07 F, Vin_max=30.0 V, ADC_max=3.3 V
nominal_gain = 10000/(82000+10000) = 0.10869565217391304
worst_case_gain: Rt_min=81180.0 ohm, Rb_max=10100.0 ohm -> 0.11064855390008764
nominal_adc_v = 30.0 V * 0.10869565217391304 = 3.260869565217391 V
worst_case_adc_v = 30.0 V * 0.11064855390008764 = 3.319456617002629 V
r_th_ohm = 82000*10000/(82000+10000) = 8913.04347826087 ohm
cutoff_hz = 1/(2*pi*8913.04347826087*1e-07) = 178.56408249334598 Hz
inverse_gain = (82000+10000)/10000 = 9.2
adc_margin_v = 3.3 - 3.319456617002629 = -0.01945661700262935 V
canonical source sha256=a2f75a5af8021ae7feecc11f85025919b81774f51cd83f79732ecd4b75ed2fd8
freshness: expected current calibration matching source; observed STALE: board_id 'DIVIDER-ALPHA' != 'DIVIDER-BETA'; source_revision 'D2' != 'D3'; inverse_gain 10.0 != 9.2; source_sha256 '0000000000000000000000000000000000000000000000000000000000000000' != 'a2f75a5af8021ae7feecc11f85025919b81774f51cd83f79732ecd4b75ed2fd8'
limit: expected worst_case_adc_v <= 3.3 V; observed 3.319456617002629 V margin -0.01945661700262935 V -> fail
generator command: python tools/generate_calibration.py --config source/circuit.json --output derived/calibration.json --replace
generator returncode=0 output='Wrote nominal calibration to /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/automation/tests/fixture-00yjwwdo/derived/calibration.json'
verification: regenerated calibration matches source board, revision, inverse_gain and digest
calibration bytes changed this run: True
report.json written (changed=True) status=fail
source/ and tools/ unchanged


----------------------------------------------------------------------
Ran 13 tests in 0.790s

FAILED (failures=6)
<shellId: 6 completed with exit code 0>
```

</details>


---

<sub>24s</sub>

### `view`

**view the file at /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/automation/tests/test_guardrails.py.**

/home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/automation/tests/test_guardrails.py

<details>
<summary>167 lines</summary>

```
"""Checks for automation/guardrails.py using disposable fixtures under automation/tests/.

Run: python -m unittest discover -s automation/tests -v   (from the workspace)
The real source/, tools/ and derived/ are only read (to copy into fixtures).
"""
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
WORKSPACE = TESTS_DIR.parent.parent
GUARDRAILS = WORKSPACE / "automation" / "guardrails.py"
sys.path.insert(0, str(WORKSPACE / "automation"))
import guardrails  # noqa: E402

STALE_CALIBRATION = {"schema_version": 1, "board_id": "DIVIDER-ALPHA", "source_revision": "D2",
                     "inverse_gain": 10.0, "source_sha256": "0" * 64}


class GuardrailsCase(unittest.TestCase):
    """Base class building a throwaway workspace per test."""

    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="fixture-", dir=TESTS_DIR))
        self.addCleanup(shutil.rmtree, self.root, True)
        for name in ("source", "tools"):
            shutil.copytree(WORKSPACE / name, self.root / name)
        shutil.copy(WORKSPACE / "REPORT_CONTRACT.md", self.root)
        (self.root / "derived").mkdir()
        self.write_calibration(STALE_CALIBRATION)

    def write_calibration(self, data):
        (self.root / "derived" / "calibration.json").write_text(json.dumps(data, indent=2) + "\n")

    def edit_source(self, **changes):
        path = self.root / "source" / "circuit.json"
        cfg = json.loads(path.read_text())
        cfg.update(changes)
        path.write_text(json.dumps(cfg, indent=2) + "\n")
        return cfg

    def run_helper(self):
        return subprocess.run([sys.executable, str(GUARDRAILS), "--workspace", str(self.root)],
                              capture_output=True, text=True)

    def report(self):
        return json.loads((self.root / "report.json").read_text())

    def digest(self, rel):
        return hashlib.sha256((self.root / rel).read_bytes()).hexdigest()


class ValidDemo(GuardrailsCase):
    def test_valid_demo_passes_and_regenerates(self):
        source_before = self.digest("source/circuit.json")
        proc = self.run_helper()
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        report = self.report()
        self.assertEqual(report["status"], "pass")
        self.assertEqual(report["case"], "demo")
        self.assertEqual(report["changed_files"], ["derived/calibration.json"])
        self.assertEqual([f["code"] for f in report["findings"]], ["stale_calibration"])
        self.assertIn("source_revision=D2", report["findings"][0]["evidence"])
        self.assertAlmostEqual(report["calculations"]["worst_case_adc_v"], 2.777268560953254, places=12)
        self.assertAlmostEqual(report["calculations"]["cutoff_hz"], 175.0704374010849, places=9)
        cal = json.loads((self.root / "derived" / "calibration.json").read_text())
        self.assertEqual(cal["source_revision"], "D3")
        self.assertEqual(cal["inverse_gain"], 11.0)
        self.assertEqual(self.digest("source/circuit.json"), source_before)

    def test_repeat_run_is_byte_stable_and_keeps_audit(self):
        self.assertEqual(self.run_helper().returncode, 0)
        first = (self.digest("report.json"), self.digest("derived/calibration.json"))
        self.assertEqual(self.run_helper().returncode, 0)
        self.assertEqual((self.digest("report.json"), self.digest("derived/calibration.json")), first)
        report = self.report()
        self.assertEqual(report["changed_files"], ["derived/calibration.json"])
        self.assertEqual(report["findings"][0]["code"], "stale_calibration")


class LimitBranches(GuardrailsCase):
    def test_worst_case_violation_fails_visibly(self):
        # Nominal 2.727 V passes a 2.75 V limit but the 2.777 V worst case does not.
        self.edit_source(adc_max_v=2.75)
        proc = self.run_helper()
        self.assertEqual(proc.returncode, 1, proc.stdout)
        report = self.report()
        self.assertEqual(report["status"], "fail")
        codes = [f["code"] for f in report["findings"]]
        self.assertIn("adc_limit_exceeded", codes)
        self.assertIn("stale_calibration", codes)
        self.assertLess(report["calculations"]["adc_margin_v"], 0)
        self.assertLess(report["calculations"]["nominal_adc_v"], 2.75)
        self.assertEqual(report["changed_files"], ["derived/calibration.json"])

    def test_equality_with_limit_passes(self):
        cfg = json.loads((self.root / "source" / "circuit.json").read_text())
        exact = guardrails.adc_voltage(cfg["vin_max_v"], guardrails.worst_case_gain(
            cfg["r_top_ohm"], cfg["r_bottom_ohm"], cfg["resistor_tolerance_fraction"]))
        self.edit_source(adc_max_v=exact)
        proc = self.run_helper()
        self.assertEqual(proc.returncode, 0, proc.stdout)
        self.assertEqual(self.report()["calculations"]["adc_margin_v"], 0.0)


class InvalidInput(GuardrailsCase):
    def assert_blocked_untouched(self, proc):
        self.assertEqual(proc.returncode, 2, proc.stdout)
        report = self.report()
        self.assertEqual(report["status"], "blocked")
        self.assertEqual(report["changed_files"], [])
        self.assertNotIn("calculations", report)
        cal = json.loads((self.root / "derived" / "calibration.json").read_text())
        self.assertEqual(cal, STALE_CALIBRATION)

    def test_nonpositive_resistor_blocks(self):
        self.edit_source(r_bottom_ohm=0)
        proc = self.run_helper()
        self.assert_blocked_untouched(proc)
        self.assertIn("r_bottom_ohm", self.report()["findings"][0]["evidence"])

    def test_tolerance_of_one_blocks(self):
        self.edit_source(resistor_tolerance_fraction=1)
        self.assert_blocked_untouched(self.run_helper())

    def test_missing_field_blocks(self):
        path = self.root / "source" / "circuit.json"
        cfg = json.loads(path.read_text())
        del cfg["vin_max_v"]
        path.write_text(json.dumps(cfg))
        proc = self.run_helper()
        self.assert_blocked_untouched(proc)
        self.assertIn("vin_max_v", self.report()["findings"][0]["evidence"])

    def test_missing_source_file_blocks_without_report(self):
        (self.root / "source" / "circuit.json").unlink()
        proc = self.run_helper()
        self.assertEqual(proc.returncode, 2)
        self.assertFalse((self.root / "report.json").exists())

    def test_generator_failure_blocks(self):
        (self.root / "tools" / "generate_calibration.py").write_text("import sys; sys.exit(3)\n")
        proc = self.run_helper()
        self.assertEqual(proc.returncode, 2)
        self.assertEqual(self.report()["status"], "blocked")


class Provenance(GuardrailsCase):
    def test_changed_input_invalidates_old_calibration(self):
        self.assertEqual(self.run_helper().returncode, 0)
        cfg = json.loads((self.root / "source" / "circuit.json").read_text())
        old_cal = json.loads((self.root / "derived" / "calibration.json").read_text())
        self.assertEqual(old_cal["source_sha256"], guardrails.canonical_digest(cfg))
        cfg["r_top_ohm"] = 120000
        calc = guardrails.calculate_all(cfg, lambda _m: None)
        diffs = guardrails.compare_calibration(old_cal, cfg, calc, guardrails.canonical_digest(cfg))
        self.assertTrue(any("source_sha256" in d for d in diffs))
        self.assertTrue(any("inverse_gain" in d for d in diffs))

    def test_changed_source_starts_new_report_and_archives_old(self):
        self.assertEqual(self.run_helper().returncode, 0)
        old_report = (self.root / "report.json").read_text()
        self.edit_source(r_top_ohm=120000, adc_max_v=2.3)
        proc = self.run_helper()
        self.assertEqual(proc.returncode, 1)
        report = self.report()
        stale = [f for f in report["findings"] if f["code"] == "stale_calibration"]
        self.assertEqual(len(stale), 1)
        self.assertIn("source_sha256", stale[0]["evidence"])
        self.assertNotIn(old_report, json.dumps(report))
        archived = list((self.root / "evidence").glob("report.superseded-*.json"))
        self.assertEqual(len(archived), 1)
        self.assertEqual(archived[0].read_text(), old_report)

    def test_numeric_representation_changes_digest(self):
        cfg = json.loads((self.root / "source" / "circuit.json").read_text())
        other = dict(cfg, vin_max_v=int(cfg["vin_max_v"]))
        self.assertNotEqual(guardrails.canonical_digest(cfg), guardrails.canonical_digest(other))

    def test_current_calibration_is_not_reported_stale(self):
        cfg = json.loads((self.root / "source" / "circuit.json").read_text())
        subprocess.run([sys.executable, str(self.root / "tools" / "generate_calibration.py"),
                        "--config", str(self.root / "source" / "circuit.json"),
                        "--output", str(self.root / "derived" / "calibration.json"), "--replace"], check=True)
        self.assertEqual(self.run_helper().returncode, 0)
        report = self.report()
        self.assertEqual(report["findings"], [])
        self.assertEqual(report["changed_files"], [])
        self.assertEqual(cfg["board_id"], report["board_id"])


if __name__ == "__main__":
    unittest.main()
```

</details>


---

<sub>34s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && python - <<'E'
import re
p='automation/tests/test_guardrails.py'
s=open(p).read()
s=s.replace('''        for name in ("source", "tools"):
            shutil.copytree(WORKSPACE / name, self.root / name)
''','''        shutil.copytree(WORKSPACE / "tools", self.root / "tools")
        (self.root / "source").mkdir()
        (self.root / "source" / "circuit.json").write_text(json.dumps(BASELINE_SOURCE, indent=2) + "\\n")
''')
s=s.replace('''class GuardrailsCase''','''# Self-contained passing fixture so the branch tests do not depend on the prepared workspace values.
BASELINE_SOURCE = {"schema_version": 1, "board_id": "DIVIDER-ALPHA", "source_revision": "D3",
                   "r_top_ohm": 100000, "r_bottom_ohm": 10000, "resistor_tolerance_fraction": 0.01,
                   "c_farad": 1e-07, "vin_max_v": 30.0, "adc_max_v": 3.3, "model": "ideal"}


class GuardrailsCase''',1)
s=s.replace('''class LimitBranches''','''class PreparedWorkspace(GuardrailsCase):
    def test_prepared_source_values_drive_the_assessment(self):
        # Reads the real prepared source (read-only) and checks against independently derived expectations.
        cfg = json.loads((WORKSPACE / "source" / "circuit.json").read_text())
        (self.root / "source" / "circuit.json").write_text(json.dumps(cfg, indent=2) + "\\n")
        rt, rb, t = cfg["r_top_ohm"], cfg["r_bottom_ohm"], cfg["resistor_tolerance_fraction"]
        worst_v = cfg["vin_max_v"] * rb * (1 + t) / (rt * (1 - t) + rb * (1 + t))
        proc = self.run_helper()
        self.assertEqual(proc.returncode, 1 if worst_v > cfg["adc_max_v"] else 0, proc.stdout)
        report = self.report()
        self.assertEqual(report["board_id"], cfg["board_id"])
        self.assertAlmostEqual(report["calculations"]["worst_case_adc_v"], worst_v, places=12)
        self.assertEqual(report["status"], "fail" if worst_v > cfg["adc_max_v"] else "pass")


class LimitBranches''',1)
s=s.replace('self.assertEqual(report["case"], "demo")\n','self.assertEqual(report["case"], "demo")\n',1)
open(p,'w').write(s)
E
python -m unittest discover -s automation/tests 2>&1 | tail -15**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && python - <<'E'
import re
p='automation/tests/test_guardrails.py'
s=open(p).read()
s=s.replace('''        for name in ("source", "tools"):
            shutil.copytree(WORKSPACE / name, self.root / name)
''','''        shutil.copytree(WORKSPACE / "tools", self.root / "tools")
        (self.root / "source").mkdir()
        (self.root / "source" / "circuit.json").write_text(json.dumps(BASELINE_SOURCE, indent=2) + "\\n")
''')
s=s.replace('''class GuardrailsCase''','''# Self-contained passing fixture so the branch tests do not depend on the prepared workspace values.
BASELINE_SOURCE = {"schema_version": 1, "board_id": "DIVIDER-ALPHA", "source_revision": "D3",
                   "r_top_ohm": 100000, "r_bottom_ohm": 10000, "resistor_tolerance_fraction": 0.01,
                   "c_farad": 1e-07, "vin_max_v": 30.0, "adc_max_v": 3.3, "model": "ideal"}


class GuardrailsCase''',1)
s=s.replace('''class LimitBranches''','''class PreparedWorkspace(GuardrailsCase):
    def test_prepared_source_values_drive_the_assessment(self):
        # Reads the real prepared source (read-only) and checks against independently derived expectations.
        cfg = json.loads((WORKSPACE / "source" / "circuit.json").read_text())
        (self.root / "source" / "circuit.json").write_text(json.dumps(cfg, indent=2) + "\\n")
        rt, rb, t = cfg["r_top_ohm"], cfg["r_bottom_ohm"], cfg["resistor_tolerance_fraction"]
        worst_v = cfg["vin_max_v"] * rb * (1 + t) / (rt * (1 - t) + rb * (1 + t))
        proc = self.run_helper()
        self.assertEqual(proc.returncode, 1 if worst_v > cfg["adc_max_v"] else 0, proc.stdout)
        report = self.report()
        self.assertEqual(report["board_id"], cfg["board_id"])
        self.assertAlmostEqual(report["calculations"]["worst_case_adc_v"], worst_v, places=12)
        self.assertEqual(report["status"], "fail" if worst_v > cfg["adc_max_v"] else "pass")


class LimitBranches''',1)
s=s.replace('self.assertEqual(report["case"], "demo")\n','self.assertEqual(report["case"], "demo")\n',1)
open(p,'w').write(s)
E
python -m unittest discover -s automation/tests 2>&1 | tail -15

<details>
<summary>6 lines</summary>

```
..........Wrote nominal calibration to /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/automation/tests/fixture-vuayv2tn/derived/calibration.json
....
----------------------------------------------------------------------
Ran 14 tests in 0.999s

OK
<shellId: 7 completed with exit code 0>
```

</details>


---

<sub>38s</sub>

### `bash` — Failed

**cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && git stash list >/dev/null; sha256sum source/circuit.json tools/generate_calibration.py REPORT_CONTRACT.md > /tmp/pre.sha; python automation/guardrails.py --workspace $PWD > /tmp/run1.txt; echo rc=$?; cp report.json /tmp/r1; cp derived/calibration.json /tmp/c1; python automation/guardrails.py --workspace $PWD >/dev/null; echo rc2=$?; cmp report.json /tmp/r1 && cmp derived/calibration.json /tmp/c1 && echo stable; sha256sum -c /tmp/pre.sha; cat report.json derived/calibration.json; ls evidence automation/tests**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && git stash list >/dev/null; sha256sum source/circuit.json tools/generate_calibration.py REPORT_CONTRACT.md > /tmp/pre.sha; python automation/guardrails.py --workspace $PWD > /tmp/run1.txt; echo rc=$?; cp report.json /tmp/r1; cp derived/calibration.json /tmp/c1; python automation/guardrails.py --workspace $PWD >/dev/null; echo rc2=$?; cmp report.json /tmp/r1 && cmp derived/calibration.json /tmp/c1 && echo stable; sha256sum -c /tmp/pre.sha; cat report.json derived/calibration.json; ls evidence automation/tests

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>40s</sub>

### Copilot

Chained commands seem blocked; running separately.

---

<sub>40s</sub>

### `bash` — Failed

**cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && sha256sum source/circuit.json tools/generate_calibration.py REPORT_CONTRACT.md > /tmp/pre.sha; python automation/guardrails.py --workspace $PWD; echo rc=$?**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && sha256sum source/circuit.json tools/generate_calibration.py REPORT_CONTRACT.md > /tmp/pre.sha; python automation/guardrails.py --workspace $PWD; echo rc=$?

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>42s</sub>

### `bash`

**cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && python automation/guardrails.py --workspace /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && python automation/guardrails.py --workspace /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code

<details>
<summary>21 lines</summary>

```
lab inferred: hw2
source revision=D3 board=DIVIDER-BETA
inputs: Rt=82000 ohm, Rb=10000 ohm, t=0.01, C=1e-07 F, Vin_max=30.0 V, ADC_max=3.3 V
nominal_gain = 10000/(82000+10000) = 0.10869565217391304
worst_case_gain: Rt_min=81180.0 ohm, Rb_max=10100.0 ohm -> 0.11064855390008764
nominal_adc_v = 30.0 V * 0.10869565217391304 = 3.260869565217391 V
worst_case_adc_v = 30.0 V * 0.11064855390008764 = 3.319456617002629 V
r_th_ohm = 82000*10000/(82000+10000) = 8913.04347826087 ohm
cutoff_hz = 1/(2*pi*8913.04347826087*1e-07) = 178.56408249334598 Hz
inverse_gain = (82000+10000)/10000 = 9.2
adc_margin_v = 3.3 - 3.319456617002629 = -0.01945661700262935 V
canonical source sha256=a2f75a5af8021ae7feecc11f85025919b81774f51cd83f79732ecd4b75ed2fd8
freshness: expected current calibration matching source; observed STALE: source_revision 'D2' != 'D3'; inverse_gain 10.0 != 9.2; source_sha256 '0000000000000000000000000000000000000000000000000000000000000000' != 'a2f75a5af8021ae7feecc11f85025919b81774f51cd83f79732ecd4b75ed2fd8'
limit: expected worst_case_adc_v <= 3.3 V; observed 3.319456617002629 V margin -0.01945661700262935 V -> fail
generator command: python tools/generate_calibration.py --config source/circuit.json --output derived/calibration.json --replace
generator returncode=0 output='Wrote nominal calibration to /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/derived/calibration.json'
verification: regenerated calibration matches source board, revision, inverse_gain and digest
calibration bytes changed this run: True
report.json written (changed=True) status=fail
source/ and tools/ unchanged
<shellId: 10 completed with exit code 1>
```

</details>


---

<sub>45s</sub>

### `bash` — Failed

**cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && sha256sum report.json derived/calibration.json; python automation/guardrails.py --workspace $PWD >/dev/null; echo rc2=$?; sha256sum report.json derived/calibration.json; git status --short . ; cat report.json**

$ cd /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code && sha256sum report.json derived/calibration.json; python automation/guardrails.py --workspace $PWD >/dev/null; echo rc2=$?; sha256sum report.json derived/calibration.json; git status --short . ; cat report.json

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>47s</sub>

### `bash` — Failed

**sha256sum report.json derived/calibration.json**

$ sha256sum report.json derived/calibration.json

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>47s</sub>

### `view`

**view the file at /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/report.json.**

/home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/report.json

<details>
<summary>39 lines</summary>

```
{
  "schema_version": 1,
  "lab": "hw2",
  "case": "transfer",
  "board_id": "DIVIDER-BETA",
  "status": "fail",
  "findings": [
    {
      "code": "stale_calibration",
      "evidence": "derived/calibration.json before regeneration: source_revision=D2, inverse_gain=10.0, source_sha256=0000000000000000000000000000000000000000000000000000000000000000. source/circuit.json: source_revision=D3, (r_top_ohm+r_bottom_ohm)/r_bottom_ohm=9.2, canonical sha256=a2f75a5af8021ae7feecc11f85025919b81774f51cd83f79732ecd4b75ed2fd8. Mismatches: source_revision 'D2' != 'D3'; inverse_gain 10.0 != 9.2; source_sha256 '0000000000000000000000000000000000000000000000000000000000000000' != 'a2f75a5af8021ae7feecc11f85025919b81774f51cd83f79732ecd4b75ed2fd8'. After regeneration: D3, 9.2, matching digest.",
      "explanation": "The existing calibration did not describe the current source (revision, coefficient or digest differed). It was regenerated with tools/generate_calibration.py."
    },
    {
      "code": "adc_limit_exceeded",
      "evidence": "source/circuit.json:vin_max_v=30.0, adc_max_v=3.3; worst_case_adc_v=3.319456617002629 V exceeds the limit, adc_margin_v=-0.01945661700262935 V.",
      "explanation": "Worst-case divider output (upper resistor at minimum, lower at maximum) exceeds the ADC limit. The design is reported as failing; it was not modified to force a pass."
    }
  ],
  "changed_files": [
    "derived/calibration.json"
  ],
  "assumptions": [
    "source/circuit.json is the authority; values are SI units.",
    "Ideal source, unloaded divider, ideal high-impedance ADC, nominal capacitor from ADC node to ground.",
    "Independent resistor tolerances of +/-t; worst case uses minimum upper resistor and maximum lower resistor.",
    "No ADC loading, sampling transient, leakage, temperature drift, or capacitor tolerance is modeled.",
    "Worst-case ADC voltage 3.319456617002629 V EXCEEDS the 3.3 V limit. The result is for the idealized model only, not physical hardware."
  ],
  "calculations": {
    "nominal_gain": 0.10869565217391304,
    "worst_case_gain": 0.11064855390008764,
    "nominal_adc_v": 3.260869565217391,
    "worst_case_adc_v": 3.319456617002629,
    "r_th_ohm": 8913.04347826087,
    "cutoff_hz": 178.56408249334598,
    "inverse_gain": 9.2,
    "adc_margin_v": -0.01945661700262935
  }
}
```

</details>


---

<sub>50s</sub>

### `bash` — Failed

**cp report.json /tmp/r1.json && cp derived/calibration.json /tmp/c1.json && python automation/guardrails.py --workspace /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code > /dev/null; echo rc=$?; cmp report.json /tmp/r1.json && cmp derived/calibration.json /tmp/c1.json && echo STABLE**

$ cp report.json /tmp/r1.json && cp derived/calibration.json /tmp/c1.json && python automation/guardrails.py --workspace /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code > /dev/null; echo rc=$?; cmp report.json /tmp/r1.json && cmp derived/calibration.json /tmp/c1.json && echo STABLE

```
Permission denied because no interactive user response was available. Retry in an interactive session so the user can approve it, or try an alternative that does not require this permission.
```


---

<sub>52s</sub>

### `bash`

**python automation/guardrails.py --workspace /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code**

$ python automation/guardrails.py --workspace /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code

<details>
<summary>22 lines</summary>

```
lab inferred: hw2
source revision=D3 board=DIVIDER-BETA
inputs: Rt=82000 ohm, Rb=10000 ohm, t=0.01, C=1e-07 F, Vin_max=30.0 V, ADC_max=3.3 V
nominal_gain = 10000/(82000+10000) = 0.10869565217391304
worst_case_gain: Rt_min=81180.0 ohm, Rb_max=10100.0 ohm -> 0.11064855390008764
nominal_adc_v = 30.0 V * 0.10869565217391304 = 3.260869565217391 V
worst_case_adc_v = 30.0 V * 0.11064855390008764 = 3.319456617002629 V
r_th_ohm = 82000*10000/(82000+10000) = 8913.04347826087 ohm
cutoff_hz = 1/(2*pi*8913.04347826087*1e-07) = 178.56408249334598 Hz
inverse_gain = (82000+10000)/10000 = 9.2
adc_margin_v = 3.3 - 3.319456617002629 = -0.01945661700262935 V
canonical source sha256=a2f75a5af8021ae7feecc11f85025919b81774f51cd83f79732ecd4b75ed2fd8
freshness: expected current calibration matching source; observed current
limit: expected worst_case_adc_v <= 3.3 V; observed 3.319456617002629 V margin -0.01945661700262935 V -> fail
generator command: python tools/generate_calibration.py --config source/circuit.json --output derived/calibration.json --replace
generator returncode=0 output='Wrote nominal calibration to /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/derived/calibration.json'
verification: regenerated calibration matches source board, revision, inverse_gain and digest
calibration bytes changed this run: False
prior report matches current source; retaining its cumulative audit
report.json written (changed=False) status=fail
source/ and tools/ unchanged
<shellId: 14 completed with exit code 1>
```

</details>


---

<sub>1m 4s</sub>

### Copilot

Second run: rc 1, report unchanged (`changed=False`), audit retained. Now the session evidence file.

---

<sub>1m 4s</sub>

### `create`

**create a new file at /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/evidence/session.md.**

/home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/evidence/session.md

```
Created file /home/runner/work/ABB-Training/ABB-Training/runs/hw2/transfer-code/evidence/session.md with 3672 characters
```


---

<sub>1m 8s</sub>

### Copilot

The HW2 transfer assessment is **fail**. The nominal ADC voltage is 3.2609 V, but the worst case is 3.3195 V against the 3.3 V limit, a margin of −0.01946 V. The design was not modified.

- **Test repair:** 6 of the 13 supplied tests failed at first because they asserted demo values against the transfer source. I changed only the test file. The fixtures now use a self-contained passing baseline, and I added one test that checks the real source's result independently. All 14 tests pass.
- **Supplied helper:** `automation/guardrails.py` returned exit code 1, which is the expected design fail. I ran it a second time and the report stayed unchanged.
- **Report:** `report.json` records `stale_calibration` and `adc_limit_exceeded`, with `changed_files` set to `["derived/calibration.json"]`.
- **Calibration:** `derived/calibration.json` was regenerated with the supplied tool and now matches revision D3 (inverse gain 9.2). It carries the nominal coefficient only.
- **Checks not run:** the instructor checker and external grader were not run. Byte-level comparison of the two runs was also not done, because `sha256sum` and `cmp` were refused in this environment. The helper's own "unchanged" log lines are the evidence for stability.

The commands, observations and decisions are in `evidence/session.md`.

---

<sub>Generated by [GitHub Copilot CLI](https://github.com/features/copilot/cli)</sub>
