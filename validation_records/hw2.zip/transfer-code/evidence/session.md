# Session log: HW2 transfer (code-assisted)

Scripted CI rehearsal. Only commands actually executed are listed.

## Inputs read
- task-card.md, CI_CONTRACT.md, REPORT_CONTRACT.md, workflow.md, automation/README.md, automation/guardrails.py, automation/tests/test_guardrails.py, tools/generate_calibration.py.
- source/circuit.json: board DIVIDER-BETA, rev D3, Rt=82000 ohm, Rb=10000 ohm, t=0.01, C=1e-07 F, Vin_max=30.0 V, ADC_max=3.3 V.
- derived/calibration.json (before): board DIVIDER-BETA, rev D2, inverse_gain=10.0, source_sha256=000...0 (placeholder, stale).
- Generator reviewed before use: emits nominal inverse_gain + provenance only; no limit judgement.
- guardrails.py reviewed: equations match the contract; it calls the supplied generator rather than reimplementing it.

## Step 1: existing tests, first run
`python -m unittest discover -s automation/tests -v` -> FAILED (failures=6 of 13).
Observation: the tests copied the prepared (transfer) source into fixtures but asserted demo values
(pass, inverse_gain 11.0, worst-case 2.777 V). Those are test defects (hardcoded demo expectations), not helper defects:
the helper correctly reported status fail (rc 1) for the transfer source.

## Decision: repair tests only
Edited automation/tests/test_guardrails.py:
- Fixtures now write a self-contained passing baseline source (BASELINE_SOURCE) instead of copying the prepared source, so branch tests
  (stale, limit violation, equality, invalid input, provenance) are independent of the prepared values.
- Added PreparedWorkspace test: reads the real prepared source read-only, derives the expected worst-case voltage independently and checks
  report status/exit code/board/value against it (expected result here: fail).
- guardrails.py, tools/, source/ not changed.
`python -m unittest discover -s automation/tests` -> Ran 14 tests, OK.

## Step 2: supplied automation on the real workspace
`python automation/guardrails.py --workspace <workspace>` -> exit code 1 (design fail, expected).
Observed values (unrounded, from its output):
- nominal_gain 0.10869565217391304; worst_case_gain 0.11064855390008764
- nominal_adc_v 3.260869565217391 V; worst_case_adc_v 3.319456617002629 V
- r_th_ohm 8913.04347826087 ohm; cutoff_hz 178.56408249334598 Hz
- inverse_gain 9.2; adc_margin_v -0.01945661700262935 V (limit exceeded)
- canonical source sha256 a2f75a5af8021ae7feecc11f85025919b81774f51cd83f79732ecd4b75ed2fd8
- Freshness: STALE (revision D2 != D3, inverse_gain 10.0 != 9.2, digest placeholder != current).
- Generator rc 0; regenerated calibration verified for board, revision, inverse_gain and digest.
- report.json: status fail, findings stale_calibration + adc_limit_exceeded, changed_files ["derived/calibration.json"].

Second run of the same command: exit code 1, "freshness: current", report.json unchanged (changed=False), original stale evidence retained.
(Byte hashes were not separately compared with sha256sum/cmp: those shell commands were refused by the environment; the helper's own changed=False/bytes-changed False log lines are the evidence.)

## Outcome
Engineering assessment: FAIL. Nominal 3.2609 V passes, but worst case 3.3195 V exceeds the 3.3 V ADC limit by 0.01946 V.
The design was not modified. Calibration is now current for revision D3 (nominal coefficient only; it says nothing about the limit).
Not run: instructor checker / external grader (not authorized in this workspace).
Helper log: evidence/guardrails.log; machine-readable: evidence/guardrails-evidence.json.
Debrief: the eight calculations, digest comparison and limit check are fully deterministic and belong in code; model-fit and redesign stay with the engineer.
